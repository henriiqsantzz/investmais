-- Set specific emails as admin
-- Replace 'your-admin-email@example.com' with the actual admin email

UPDATE profiles
SET role = 'admin'
WHERE email IN (
  'admin@investimentoalto.com',
  'contato@investimentoalto.com'
  -- Add more admin emails here as needed
);

-- Verify admin users
SELECT id, email, role, created_at
FROM profiles
WHERE role = 'admin';
