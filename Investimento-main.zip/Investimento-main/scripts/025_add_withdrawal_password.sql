-- Add withdrawal_password column to profiles table
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS withdrawal_password TEXT;

-- Add comment to column
COMMENT ON COLUMN profiles.withdrawal_password IS 'Hashed 4-digit PIN for withdrawal verification';
