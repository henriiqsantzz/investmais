-- INSTRUÇÕES:
-- 1. Acesse /debug-profile no seu app
-- 2. Copie o ID que aparece lá
-- 3. Substitua 'COLE-SEU-ID-AQUI' abaixo pelo ID copiado
-- 4. Execute este script

UPDATE profiles 
SET role = 'admin'
WHERE id = '4c7fe55c-9530-44e6-92a2-1510bb608ab4';

-- Verificar se funcionou
SELECT id, email, role 
FROM profiles 
WHERE id = '4c7fe55c-9530-44e6-92a2-1510bb608ab4';
