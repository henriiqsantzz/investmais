-- Create site_settings table for whitelabel configuration
CREATE TABLE IF NOT EXISTS site_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key VARCHAR(255) UNIQUE NOT NULL,
  value TEXT,
  type VARCHAR(50) NOT NULL, -- 'text', 'number', 'image', 'percentage'
  category VARCHAR(100) NOT NULL, -- 'branding', 'investment', 'general'
  description TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Insert default settings
INSERT INTO site_settings (key, value, type, category, description) VALUES
  ('site_logo', '/logo.png', 'image', 'branding', 'Logo principal do site'),
  ('login_logo', '/logo.png', 'image', 'branding', 'Logo da página de login'),
  ('signup_logo', '/logo.png', 'image', 'branding', 'Logo da página de cadastro'),
  ('site_name', 'ZIPRAPAY', 'text', 'branding', 'Nome do site'),
  ('bronze_daily_return', '0.5', 'percentage', 'investment', 'Retorno diário Bronze (%)'),
  ('silver_daily_return', '0.8', 'percentage', 'investment', 'Retorno diário Prata (%)'),
  ('gold_daily_return', '1.2', 'percentage', 'investment', 'Retorno diário Ouro (%)'),
  ('min_deposit', '50', 'number', 'investment', 'Depósito mínimo (BRL)')
ON CONFLICT (key) DO NOTHING;

-- Enable RLS
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;

-- Policy: Everyone can read settings
CREATE POLICY "Anyone can view site settings"
  ON site_settings FOR SELECT
  USING (true);

-- Policy: Only admins can update settings
CREATE POLICY "Only admins can update site settings"
  ON site_settings FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );
