-- Criar tabela site_settings se não existir
CREATE TABLE IF NOT EXISTS site_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key VARCHAR(255) UNIQUE NOT NULL,
  value TEXT,
  type VARCHAR(50) NOT NULL,
  category VARCHAR(100) NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Atualizando keys para corresponder ao código e adicionando porcentagens por produto
-- Deletar configurações antigas se existirem
DELETE FROM site_settings WHERE key IN (
  'logo_url', 'logo_login', 'logo_signup', 'investment_return_percentage'
);

-- Inserir configurações padrão com keys corretas
INSERT INTO site_settings (key, value, type, category, description)
VALUES
  ('site_name', 'InvestAlto', 'text', 'branding', 'Nome do Site'),
  ('site_logo', '', 'image', 'branding', 'Logo principal do site'),
  ('login_logo', '', 'image', 'branding', 'Logo da página de login'),
  ('signup_logo', '', 'image', 'branding', 'Logo da página de cadastro'),
  ('favicon_url', '/favicon.ico', 'image', 'branding', 'Favicon do Site'),
  ('primary_color', '#0A3C3C', 'color', 'branding', 'Cor Primária'),
  ('secondary_color', '#C1D7D7', 'color', 'branding', 'Cor Secundária'),
  
  -- Porcentagens de retorno por tipo de produto
  ('petroliferos_return_percentage', '0.8', 'percentage', 'investment', 'Retorno Diário - Produtos Petrolíferos (%)'),
  ('gas_natural_return_percentage', '0.6', 'percentage', 'investment', 'Retorno Diário - Gás Natural (%)'),
  ('eventos_return_percentage', '1.2', 'percentage', 'investment', 'Retorno Diário - Eventos (%)'),
  
  -- Configurações gerais de investimento
  ('min_investment', '50', 'number', 'investment', 'Valor Mínimo de Investimento (R$)'),
  ('max_investment', '100000', 'number', 'investment', 'Valor Máximo de Investimento (R$)'),
  ('investment_duration_days', '30', 'number', 'investment', 'Duração do Investimento (dias)')
ON CONFLICT (key) DO UPDATE SET
  value = EXCLUDED.value,
  type = EXCLUDED.type,
  category = EXCLUDED.category,
  description = EXCLUDED.description,
  updated_at = NOW();

-- Habilitar RLS
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;

-- Remover políticas antigas se existirem
DROP POLICY IF EXISTS "Admins can view all settings" ON site_settings;
DROP POLICY IF EXISTS "Admins can update settings" ON site_settings;
DROP POLICY IF EXISTS "Anyone can view public settings" ON site_settings;
DROP POLICY IF EXISTS "Only admins can update site settings" ON site_settings;
DROP POLICY IF EXISTS "Anyone can view site settings" ON site_settings;

-- Política para todos visualizarem todas as configurações (necessário para whitelabel)
CREATE POLICY "Anyone can view site settings"
ON site_settings FOR SELECT
TO public
USING (true);

-- Política para admins atualizarem configurações
CREATE POLICY "Only admins can update site settings"
ON site_settings FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);
