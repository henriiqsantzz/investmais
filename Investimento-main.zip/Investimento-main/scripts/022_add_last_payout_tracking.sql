-- Add field to track last payout date for investments
ALTER TABLE investments ADD COLUMN IF NOT EXISTS last_payout_date TIMESTAMP;

-- Add index for faster queries on active investments
CREATE INDEX IF NOT EXISTS idx_investments_status_created ON investments(status, created_at);

-- Update existing active investments to set last_payout_date to created_at
UPDATE investments 
SET last_payout_date = created_at 
WHERE status = 'active' AND last_payout_date IS NULL;
