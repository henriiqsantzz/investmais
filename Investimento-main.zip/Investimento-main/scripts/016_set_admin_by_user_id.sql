-- Script alternativo: Definir admin pelo ID do usuário
-- Primeiro, veja todos os usuários e seus IDs:
SELECT id, email, role, created_at
FROM auth.users
ORDER BY created_at DESC;

-- Depois, copie o ID do seu usuário e execute:
-- SUBSTITUA 'SEU-USER-ID-AQUI' pelo ID que você copiou acima
UPDATE profiles
SET role = 'admin'
WHERE id = '4c7fe55c-9530-44e6-92a2-1510bb608ab4';

-- Verificar se funcionou:
SELECT p.id, p.email, p.role, au.email as auth_email
FROM profiles p
LEFT JOIN auth.users au ON p.id = au.id
WHERE p.role = 'admin';
