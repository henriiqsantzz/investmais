-- Script para corrigir todos os problemas de autenticação
-- Execute este script no Supabase SQL Editor

-- 1. Confirmar todos os usuários existentes (remove necessidade de confirmação de email)
UPDATE auth.users 
SET email_confirmed_at = NOW() 
WHERE email_confirmed_at IS NULL;

-- 2. Criar perfis para todos os usuários que não têm perfil
INSERT INTO profiles (id, role, created_at)
SELECT 
  id,
  'user' as role,
  NOW() as created_at
FROM auth.users
WHERE id NOT IN (SELECT id FROM profiles)
ON CONFLICT (id) DO NOTHING;

-- 3. Garantir que a política de INSERT existe na tabela profiles
DROP POLICY IF EXISTS "Users can insert their own profile" ON profiles;
CREATE POLICY "Users can insert their own profile" 
ON profiles FOR INSERT 
WITH CHECK (auth.uid() = id);

-- 4. Garantir que a política de SELECT existe
DROP POLICY IF EXISTS "Users can view their own profile" ON profiles;
CREATE POLICY "Users can view their own profile" 
ON profiles FOR SELECT 
USING (auth.uid() = id OR EXISTS (
  SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
));

-- 5. Garantir que a política de UPDATE existe
DROP POLICY IF EXISTS "Users can update their own profile" ON profiles;
CREATE POLICY "Users can update their own profile" 
ON profiles FOR UPDATE 
USING (auth.uid() = id);
