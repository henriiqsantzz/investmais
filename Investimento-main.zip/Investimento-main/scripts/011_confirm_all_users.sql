-- Script para confirmar todos os usuários existentes
-- Execute este script no Supabase SQL Editor se você desabilitou
-- a confirmação de email mas tem usuários antigos não confirmados

UPDATE auth.users
SET email_confirmed_at = NOW()
WHERE email_confirmed_at IS NULL;

-- Verificar quantos usuários foram confirmados
SELECT 
  COUNT(*) as total_users,
  COUNT(email_confirmed_at) as confirmed_users
FROM auth.users;
