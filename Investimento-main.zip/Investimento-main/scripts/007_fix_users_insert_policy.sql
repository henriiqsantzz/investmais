-- Adicionar política de INSERT para permitir que novos usuários se cadastrem
-- Esta política permite que um usuário crie seu próprio registro na tabela users
-- quando o ID corresponde ao auth.uid() do Supabase Auth

-- Remover política antiga se existir
DROP POLICY IF EXISTS "Users can insert their own data" ON users;

-- Criar nova política de INSERT
CREATE POLICY "Users can insert their own data" ON users
  FOR INSERT 
  WITH CHECK (auth.uid()::text = id::text);

-- Adicionar políticas de admin para gerenciar usuários
DROP POLICY IF EXISTS "Admins can view all users" ON users;
DROP POLICY IF EXISTS "Admins can update all users" ON users;

CREATE POLICY "Admins can view all users" ON users
  FOR SELECT 
  USING ((SELECT role FROM users WHERE id = auth.uid()::uuid) = 'admin');

CREATE POLICY "Admins can update all users" ON users
  FOR UPDATE 
  USING ((SELECT role FROM users WHERE id = auth.uid()::uuid) = 'admin');
