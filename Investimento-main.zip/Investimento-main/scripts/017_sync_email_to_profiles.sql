-- Sincronizar emails da tabela auth.users para profiles
-- Isso garante que o email esteja na tabela profiles
UPDATE profiles p
SET email = au.email
FROM auth.users au
WHERE p.id = au.id
AND (p.email IS NULL OR p.email = '');

-- Verificar a sincronização:
SELECT p.id, p.email, p.role, au.email as auth_email
FROM profiles p
LEFT JOIN auth.users au ON p.id = au.id
LIMIT 10;
