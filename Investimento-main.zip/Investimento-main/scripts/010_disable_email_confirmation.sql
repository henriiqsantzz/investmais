-- Este script DESABILITA a confirmação de email no Supabase
-- Use apenas para TESTES/DESENVOLVIMENTO
-- Para produção, mantenha a confirmação de email ativada

-- IMPORTANTE: Este script não pode ser executado via SQL Editor
-- Você precisa desabilitar a confirmação de email nas configurações do Supabase:
-- 
-- 1. Acesse: https://supabase.com/dashboard
-- 2. Selecione seu projeto
-- 3. Vá em "Authentication" > "Providers" > "Email"
-- 4. Desmarque a opção "Confirm email"
-- 5. Clique em "Save"
--
-- Alternativamente, você pode usar a Supabase CLI:
-- supabase settings update auth.enable_signup_email_confirmation=false

-- Este arquivo serve apenas como documentação do processo
