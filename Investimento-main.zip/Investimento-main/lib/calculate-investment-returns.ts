// Utility function to calculate investment returns based on admin-configured percentages
export function calculateInvestmentReturns(
  amount: number,
  days: number,
  dailyReturnPercentage: number,
): {
  dailyIncome: number
  totalIncome: number
} {
  const dailyIncome = (amount * dailyReturnPercentage) / 100
  const totalIncome = dailyIncome * days

  return {
    dailyIncome: Number.parseFloat(dailyIncome.toFixed(2)),
    totalIncome: Number.parseFloat(totalIncome.toFixed(2)),
  }
}
