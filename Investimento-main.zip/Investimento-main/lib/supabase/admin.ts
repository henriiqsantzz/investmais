import { createClient } from "@supabase/supabase-js"

// Create admin client with service role key to bypass RLS
export function createAdminClient() {
  // Usa NEXT_PUBLIC_SUPABASE_URL se SUPABASE_URL não estiver definida (compatibilidade)
  const supabaseUrl = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL!
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!

  return createClient(supabaseUrl, supabaseServiceKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  })
}

// Check if a user is admin using service role (bypasses RLS)
export async function isUserAdmin(userId: string): Promise<boolean> {
  const adminClient = createAdminClient()

  const { data, error } = await adminClient.from("profiles").select("role").eq("id", userId).maybeSingle()

  if (error || !data) {
    return false
  }

  return data.role === "admin"
}
