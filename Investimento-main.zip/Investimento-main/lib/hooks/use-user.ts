"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import type { User } from "@supabase/supabase-js"

interface UserDetails {
  id: string
  email: string
  name: string
  phone?: string
  balance: number
  withdrawal_balance: number
  role: string
  pix_key?: string
  pix_key_type?: string
}

export function useUser() {
  const [user, setUser] = useState<User | null>(null)
  const [userDetails, setUserDetails] = useState<UserDetails | null>(null)
  const [loading, setLoading] = useState(true)
  const [supabaseConfigured, setSupabaseConfigured] = useState(false)

  useEffect(() => {
    const supabase = createClient()

    if (!supabase) {
      setSupabaseConfigured(false)
      setLoading(false)
      return
    }

    setSupabaseConfigured(true)

    const fetchUser = async () => {
      try {
        const {
          data: { user: authUser },
        } = await supabase.auth.getUser()

        if (authUser) {
          setUser(authUser)

          const { data: userData } = await supabase.from("profiles").select("*").eq("id", authUser.id).single()

          if (userData) {
            setUserDetails(userData as UserDetails)
          }
        }
      } catch (error) {
        console.error("[v0] Error fetching user:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchUser()

    // Subscribe to auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        setUser(session.user)
        fetchUser()
      } else {
        setUser(null)
        setUserDetails(null)
      }
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [])

  return {
    user,
    userDetails,
    loading,
    supabaseConfigured,
    refetch: async () => {
      const supabase = createClient()
      if (!supabase || !user?.id) return

      const { data: userData } = await supabase.from("profiles").select("*").eq("id", user.id).single()
      if (userData) {
        setUserDetails(userData as UserDetails)
      }
    },
  }
}
