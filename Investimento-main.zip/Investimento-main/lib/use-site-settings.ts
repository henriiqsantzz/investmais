"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"

interface SiteSettings {
  site_logo: string
  login_logo: string
  signup_logo: string
  site_name: string
  petroliferos_return_percentage: number
  gas_natural_return_percentage: number
  eventos_return_percentage: number
  min_investment: number
  max_investment: number
  investment_duration_days: number
  [key: string]: string | number
}

const defaultSettings: SiteSettings = {
  site_logo: "",
  login_logo: "",
  signup_logo: "",
  site_name: "InvestAlto",
  petroliferos_return_percentage: 0.8,
  gas_natural_return_percentage: 0.6,
  eventos_return_percentage: 1.2,
  min_investment: 50,
  max_investment: 100000,
  investment_duration_days: 30,
}

export function useSiteSettings() {
  const [settings, setSettings] = useState<SiteSettings>(defaultSettings)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchSettings()
  }, [])

  const fetchSettings = async () => {
    try {
      const supabase = createClient()
      const { data, error } = await supabase.from("site_settings").select("key, value, type")

      if (error) {
        console.error("[v0] Erro ao buscar configurações:", error)
        setSettings(defaultSettings)
        return
      }

      if (data && data.length > 0) {
        const settingsObj: any = { ...defaultSettings }
        data.forEach((setting) => {
          if (setting.type === "number" || setting.type === "percentage") {
            settingsObj[setting.key] = Number.parseFloat(setting.value) || 0
          } else {
            settingsObj[setting.key] = setting.value
          }
        })
        console.log("[v0] Configurações carregadas:", settingsObj)
        setSettings(settingsObj)
      }
    } catch (error) {
      console.error("[v0] Erro ao carregar configurações:", error)
      setSettings(defaultSettings)
    } finally {
      setLoading(false)
    }
  }

  return { settings, loading, refetch: fetchSettings }
}
