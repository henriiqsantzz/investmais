"use client"

import { useState } from "react"
import { X, Lock, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface WithdrawalPasswordModalProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
}

export function WithdrawalPasswordModal({ isOpen, onClose, onSuccess }: WithdrawalPasswordModalProps) {
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  if (!isOpen) return null

  const handlePasswordChange = (value: string) => {
    const numericValue = value.replace(/\D/g, "").slice(0, 4)
    setPassword(numericValue)
  }

  const handleConfirmPasswordChange = (value: string) => {
    const numericValue = value.replace(/\D/g, "").slice(0, 4)
    setConfirmPassword(numericValue)
  }

  const handleSubmit = async () => {
    setError("")

    if (password.length !== 4) {
      setError("A senha deve ter exatamente 4 dígitos")
      return
    }

    if (password !== confirmPassword) {
      setError("As senhas não coincidem")
      return
    }

    setLoading(true)

    try {
      const response = await fetch("/api/user/set-withdrawal-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      })

      const data = await response.json()

      if (!response.ok) {
        if (data.error?.includes("withdrawal_password") && data.error?.includes("schema cache")) {
          setError(
            "ERRO DE CONFIGURAÇÃO: A coluna 'withdrawal_password' não existe no banco de dados. Execute o script SQL: scripts/025_add_withdrawal_password.sql",
          )
        } else {
          setError(data.error || "Erro ao configurar senha")
        }
        setLoading(false)
        return
      }

      alert("Senha de saque configurada com sucesso!")
      onSuccess()
      onClose()
    } catch (err: any) {
      if (err.message?.includes("withdrawal_password")) {
        setError("ERRO DE CONFIGURAÇÃO: Execute o script SQL scripts/025_add_withdrawal_password.sql no banco de dados")
      } else {
        setError(err.message || "Erro ao configurar senha")
      }
    } finally {
      setLoading(false)
    }
  }

  const isDatabaseConfigError = error.includes("ERRO DE CONFIGURAÇÃO")

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="bg-white rounded-2xl p-6 w-full max-w-md">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Lock className="w-5 h-5 text-[#0A3C3C]" />
            <h3 className="text-lg font-semibold text-[#1E1E1E]">Configurar Senha de Saque</h3>
          </div>
          <button onClick={onClose}>
            <X className="w-5 h-5 text-[#5E6B6B]" />
          </button>
        </div>

        <p className="text-sm text-[#5E6B6B] mb-4">Crie uma senha de 4 dígitos numéricos para proteger seus saques</p>

        <div className="space-y-4">
          <div>
            <label className="text-sm text-[#5E6B6B] mb-1 block">Nova Senha</label>
            <input
              type="tel"
              inputMode="numeric"
              pattern="[0-9]*"
              value={password}
              onChange={(e) => handlePasswordChange(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C] text-center text-2xl tracking-widest"
              placeholder="••••"
              maxLength={4}
            />
          </div>

          <div>
            <label className="text-sm text-[#5E6B6B] mb-1 block">Confirmar Senha</label>
            <input
              type="tel"
              inputMode="numeric"
              pattern="[0-9]*"
              value={confirmPassword}
              onChange={(e) => handleConfirmPasswordChange(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C] text-center text-2xl tracking-widest"
              placeholder="••••"
              maxLength={4}
            />
          </div>

          {error && (
            <div
              className={`${isDatabaseConfigError ? "bg-orange-50 border-orange-200" : "bg-red-50 border-red-200"} border rounded-xl p-4`}
            >
              {isDatabaseConfigError && (
                <div className="flex items-start gap-2 mb-2">
                  <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold text-orange-900 mb-1">
                      Configuração do Banco de Dados Necessária
                    </p>
                    <p className="text-sm text-orange-700 mb-2">A tabela do banco de dados precisa ser atualizada.</p>
                    <div className="bg-orange-100 rounded p-2 mb-2">
                      <p className="text-xs font-mono text-orange-900">scripts/025_add_withdrawal_password.sql</p>
                    </div>
                    <p className="text-xs text-orange-600">
                      Execute este script SQL no seu banco de dados Supabase para adicionar a coluna necessária.
                    </p>
                  </div>
                </div>
              )}
              {!isDatabaseConfigError && <p className="text-sm text-red-600">{error}</p>}
            </div>
          )}

          <Button
            onClick={handleSubmit}
            disabled={loading || password.length !== 4 || confirmPassword.length !== 4}
            className="w-full bg-[#0A3C3C] hover:bg-[#0C5050] text-white rounded-xl py-3 disabled:opacity-50"
          >
            {loading ? "Configurando..." : "Configurar Senha"}
          </Button>
        </div>
      </Card>
    </div>
  )
}
