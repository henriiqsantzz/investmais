"use client"

import { CheckCircle2, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useEffect } from "react"
import confetti from "canvas-confetti"

interface DepositSuccessModalProps {
  isOpen: boolean
  onClose: () => void
  amount: number
  newBalance: number
}

export function DepositSuccessModal({ isOpen, onClose, amount, newBalance }: DepositSuccessModalProps) {
  useEffect(() => {
    if (isOpen) {
      // Trigger confetti animation
      const duration = 3000
      const animationEnd = Date.now() + duration
      const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 }

      function randomInRange(min: number, max: number) {
        return Math.random() * (max - min) + min
      }

      const interval = setInterval(() => {
        const timeLeft = animationEnd - Date.now()

        if (timeLeft <= 0) {
          return clearInterval(interval)
        }

        const particleCount = 50 * (timeLeft / duration)
        confetti({
          ...defaults,
          particleCount,
          origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
        })
        confetti({
          ...defaults,
          particleCount,
          origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
        })
      }, 250)

      return () => clearInterval(interval)
    }
  }, [isOpen])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[9998] p-4" onClick={onClose}>
      <div
        className="bg-white rounded-[24px] max-w-md w-full p-8 relative animate-in zoom-in-95 duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#5E6B6B] hover:text-[#1E1E1E] transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Success icon */}
        <div className="flex justify-center mb-6">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center animate-in zoom-in duration-500">
            <CheckCircle2 className="w-16 h-16 text-white" />
          </div>
        </div>

        {/* Title */}
        <h2 className="text-2xl font-bold text-center text-[#1E1E1E] mb-2">Depósito Concluído!</h2>

        {/* Description */}
        <p className="text-center text-[#5E6B6B] mb-6">Seu pagamento foi processado com sucesso</p>

        {/* Amount details */}
        <div className="bg-gradient-to-br from-[#0A3C3C]/5 to-[#0A3C3C]/10 rounded-2xl p-6 mb-6 space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-sm text-[#5E6B6B]">Valor depositado</span>
            <span className="text-lg font-bold text-[#0A3C3C]">R$ {amount.toFixed(2)}</span>
          </div>
          <div className="h-px bg-[#8BA3A3]/20"></div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-[#5E6B6B]">Novo saldo</span>
            <span className="text-xl font-bold text-green-600">R$ {newBalance.toFixed(2)}</span>
          </div>
        </div>

        {/* Success message */}
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
          <p className="text-sm text-green-800 text-center">
            ✓ O valor foi creditado em sua carteira de depósito e já está disponível para investimentos!
          </p>
        </div>

        {/* Action button */}
        <Button
          onClick={onClose}
          className="w-full bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] hover:from-[#0C5050] hover:to-[#0A3C3C] text-white py-3 rounded-xl font-semibold transition-all"
        >
          Continuar
        </Button>
      </div>
    </div>
  )
}
