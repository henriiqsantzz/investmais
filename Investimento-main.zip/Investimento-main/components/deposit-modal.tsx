"use client"

import { useState } from "react"
import { X } from "lucide-react"
import QRCode from "qrcode"
import { Button } from "@/components/ui/button"

interface DepositModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: (amount: number) => void
  onPixGenerated?: (pixData: {
    qrCode: string
    pixCode: string
    pixKey: string
    amount: number
    transactionId: string
    expiresAt: string
  }) => void
}

const PRESET_AMOUNTS = [5, 10, 20, 50, 100, 200, 500, 1000, 2000, 3000, 5000, 10000, 20000, 50000] // Adicionado valores menores começando em R$ 5
const MIN_DEPOSIT = 5 // Alterado de 50 para 5 reais
const MAX_DEPOSIT = 50000

export function DepositModal({ isOpen, onClose, onConfirm, onPixGenerated }: DepositModalProps) {
  const [amount, setAmount] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  if (!isOpen) return null

  const handleAmountChange = (value: string) => {
    setAmount(value)
    setError("")
  }

  const handlePresetAmount = (presetAmount: number) => {
    setAmount(presetAmount.toString())
    setError("")
  }

  const validateAmount = (): boolean => {
    const numAmount = Number.parseFloat(amount)

    if (!amount || isNaN(numAmount)) {
      setError("Digite um valor válido")
      return false
    }

    if (numAmount < MIN_DEPOSIT) {
      setError(`Valor mínimo é R$ ${MIN_DEPOSIT}.00`)
      return false
    }

    if (numAmount > MAX_DEPOSIT) {
      setError(`Valor máximo é R$ ${MAX_DEPOSIT}.00`)
      return false
    }

    return true
  }

  const generateQRCode = async () => {
    if (!validateAmount()) return

    setLoading(true)
    setError("")
    try {
      const numAmount = Number.parseFloat(amount)

      console.log("[v0] Gerando QR code para valor:", numAmount)

      const response = await fetch("/api/payments/deposit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          quantia: numAmount,
          metodoDePagamento: "PIX",
          dadosDoCliente: {
            nome: "Usuário",
            email: "usuario@email.com",
            documento: "00000000000",
            telefone: "+5511999999999",
          },
          metadados: {
            ordenarId: `ORDER_${Date.now()}`,
            descrição: "Depósito via PIX",
          },
        }),
      })

      console.log("[v0] Status da resposta:", response.status)

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: "Erro ao processar depósito" }))
        console.error("[v0] Erro na resposta:", errorData)
        setError(errorData.message || errorData.error || "Erro ao processar depósito")
        return
      }

      const result = await response.json()
      console.log("[v0] Resposta da API:", result)

      const responseData = result.data || result

      const apiPixKey = responseData.pixKey || responseData.chavePix || responseData.chave || ""
      const apiPixCode =
        responseData.pixCode ||
        responseData.codigoPix ||
        responseData.qrCode ||
        responseData.emv ||
        responseData.brcode ||
        ""
      const txnId = responseData.transactionId || responseData.id || responseData.cobrancaId || `txn_${Date.now()}`
      const expiresAt = responseData.expiresAt || new Date(Date.now() + 5 * 60 * 1000).toISOString()

      console.log("[v0] Dados extraídos - PIX Key:", apiPixKey, "PIX Code:", apiPixCode, "Transaction ID:", txnId)

      if (!apiPixCode && !apiPixKey) {
        console.error("[v0] Resposta não contém dados PIX válidos:", result)
        setError("Resposta da API não contém dados PIX válidos")
        return
      }

      const codeToEncode = apiPixCode || apiPixKey
      const qrCodeUrl = await QRCode.toDataURL(codeToEncode)

      if (onPixGenerated) {
        onPixGenerated({
          qrCode: qrCodeUrl,
          pixCode: apiPixCode,
          pixKey: apiPixKey,
          amount: numAmount,
          transactionId: txnId,
          expiresAt,
        })
      }

      onConfirm(numAmount)
      onClose()
    } catch (err) {
      console.error("[v0] Erro ao gerar QR code:", err)
      setError(err instanceof Error ? err.message : "Erro ao processar depósito")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div
        className="bg-white rounded-[20px] max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-[#8BA3A3]/20 px-6 py-4 flex items-center justify-between rounded-t-[20px]">
          <h2 className="text-xl font-semibold text-[#1E1E1E]">Depósito</h2>
          <button onClick={onClose} className="text-[#5E6B6B] hover:text-[#1E1E1E] transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Valor do depósito */}
          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-2">Valor do depósito</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => handleAmountChange(e.target.value)}
              placeholder="Valor do depósito"
              className="w-full px-4 py-2.5 rounded-lg border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C] transition-colors"
            />
            {error && <p className="text-sm text-red-600 mt-1">{error}</p>}
          </div>

          {/* Valores pré-definidos */}
          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-3">Valores sugeridos</label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {PRESET_AMOUNTS.map((presetAmount) => (
                <button
                  key={presetAmount}
                  onClick={() => handlePresetAmount(presetAmount)}
                  className={`py-2 px-3 rounded-lg border-2 transition-all ${
                    amount === presetAmount.toString()
                      ? "border-[#0A3C3C] bg-[#0A3C3C]/10 text-[#0A3C3C] font-medium"
                      : "border-[#8BA3A3]/20 text-[#5E6B6B] hover:border-[#0A3C3C]/30"
                  }`}
                >
                  R$ {presetAmount}
                </button>
              ))}
            </div>
          </div>

          {/* Método de depósito */}
          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-3">Método de depósito</label>
            <div className="border border-[#8BA3A3]/20 rounded-lg p-4 bg-[#F5F5F5]">
              <p className="font-semibold text-[#1E1E1E] mb-3">ZIPRAPAY (PIX)</p>
              <p className="text-sm text-[#5E6B6B] mb-3">
                Intervalo de valores: R$ {MIN_DEPOSIT} - R$ {MAX_DEPOSIT}
              </p>
            </div>
          </div>

          {/* Descrição da regra */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
            <p className="text-sm font-semibold text-blue-900">Descrição da regra</p>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>
                • Não altere o valor da recarga e certifique-se de transferir de acordo com o valor que iniciou a
                recarga.
              </li>
              <li>• Inicie cada recarga por meio desta página e não salve a conta de transferência.</li>
              <li>
                • Valor de recarga única entre R$ {MIN_DEPOSIT} e R$ {MAX_DEPOSIT}.
              </li>
              <li>
                • Se a recarga for iniciada há mais de 5 minutos, mas não for recebida, envie um problema de recarga não
                recebido por meio da central de ajuda de autoatendimento.
              </li>
              <li>
                • Devido à popularidade da plataforma, a inicialização da recarga pode falhar. Tente algumas vezes.
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-[#8BA3A3]/20 p-6 space-y-3">
          <Button
            onClick={generateQRCode}
            disabled={!amount || loading}
            className="w-full bg-[#0A3C3C] hover:bg-[#0C5050] text-white py-2.5 rounded-lg font-medium transition-colors disabled:opacity-50"
          >
            {loading ? "Gerando QR Code..." : "Gerar QR Code"}
          </Button>
          <Button
            onClick={onClose}
            className="w-full bg-[#8BA3A3] hover:bg-[#7A9292] text-white py-2.5 rounded-lg font-medium transition-colors"
          >
            Cancelar
          </Button>
        </div>
      </div>
    </div>
  )
}
