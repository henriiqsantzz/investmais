"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, TrendingUp, Calendar, DollarSign } from "lucide-react"

interface InvestmentSuccessModalProps {
  isOpen: boolean
  onClose: () => void
  investment: {
    amount: number
    productName: string
    dailyReturn: number
    totalDays: number
    totalReturn: number
  }
}

export function InvestmentSuccessModal({ isOpen, onClose, investment }: InvestmentSuccessModalProps) {
  const [show, setShow] = useState(false)

  useEffect(() => {
    if (isOpen) {
      setShow(true)
      if ("Notification" in window && Notification.permission === "granted") {
        new Notification("Investimento Realizado! 🎉", {
          body: `Você investiu R$ ${investment.amount.toFixed(2)} com sucesso!`,
          icon: "/logo.png",
          badge: "/logo.png",
        })
      } else if ("Notification" in window && Notification.permission !== "denied") {
        Notification.requestPermission().then((permission) => {
          if (permission === "granted") {
            new Notification("Investimento Realizado! 🎉", {
              body: `Você investiu R$ ${investment.amount.toFixed(2)} com sucesso!`,
              icon: "/logo.png",
              badge: "/logo.png",
            })
          }
        })
      }
    } else {
      setShow(false)
    }
  }, [isOpen, investment.amount])

  if (!show) return null

  return (
    <>
      <style jsx global>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes zoomIn {
          from {
            transform: scale(0.95);
            opacity: 0;
          }
          to {
            transform: scale(1);
            opacity: 1;
          }
        }

        .animate-fadeIn {
          animation: fadeIn 0.3s ease-in-out forwards;
        }

        .animate-zoomIn {
          animation: zoomIn 0.3s ease-in-out forwards;
        }

        .animate-zoomIn-slow {
          animation: zoomIn 0.5s ease-in-out forwards;
        }
      `}</style>

      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn"
        onClick={onClose}
      >
        <Card
          className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl animate-zoomIn"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="text-center space-y-6">
            {/* Success Icon */}
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center mx-auto animate-zoomIn-slow">
                <CheckCircle className="w-12 h-12 text-white" />
              </div>
              <div className="absolute inset-0 w-20 h-20 rounded-full bg-green-400/20 animate-ping mx-auto" />
            </div>

            {/* Title */}
            <div>
              <h2 className="text-2xl font-bold text-[#1E1E1E] mb-2">Investimento Realizado!</h2>
              <p className="text-sm text-[#5E6B6B]">Seu investimento foi processado com sucesso</p>
            </div>

            {/* Investment Details */}
            <div className="space-y-3 bg-[#F5F5F5] rounded-xl p-4">
              <div className="flex items-center justify-between py-2 border-b border-[#8BA3A3]/20">
                <div className="flex items-center gap-2 text-[#5E6B6B]">
                  <DollarSign className="w-4 h-4" />
                  <span className="text-sm">Valor Investido</span>
                </div>
                <span className="text-base font-bold text-[#0A3C3C]">R$ {investment.amount.toFixed(2)}</span>
              </div>

              <div className="flex items-center justify-between py-2 border-b border-[#8BA3A3]/20">
                <div className="flex items-center gap-2 text-[#5E6B6B]">
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-sm">Retorno Diário</span>
                </div>
                <span className="text-base font-semibold text-green-600">R$ {investment.dailyReturn.toFixed(2)}</span>
              </div>

              <div className="flex items-center justify-between py-2 border-b border-[#8BA3A3]/20">
                <div className="flex items-center gap-2 text-[#5E6B6B]">
                  <Calendar className="w-4 h-4" />
                  <span className="text-sm">Período</span>
                </div>
                <span className="text-base font-semibold text-[#1E1E1E]">{investment.totalDays} dias</span>
              </div>

              <div className="flex items-center justify-between py-2">
                <div className="flex items-center gap-2 text-[#5E6B6B]">
                  <DollarSign className="w-4 h-4" />
                  <span className="text-sm">Retorno Total Estimado</span>
                </div>
                <span className="text-base font-bold text-[#0A3C3C]">R$ {investment.totalReturn.toFixed(2)}</span>
              </div>
            </div>

            {/* Product Name */}
            <div className="bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] rounded-xl p-3">
              <p className="text-xs text-white/70 mb-1">Produto</p>
              <p className="text-sm font-semibold text-white">{investment.productName}</p>
            </div>

            {/* Action Button */}
            <Button onClick={onClose} className="w-full bg-[#0A3C3C] hover:bg-[#0C5050] text-white rounded-xl py-3">
              Continuar Investindo
            </Button>
          </div>
        </Card>
      </div>
    </>
  )
}
