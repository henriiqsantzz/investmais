"use client"

import { useState, useEffect } from "react"
import { X, Copy, Check, Clock, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

interface PixDisplayModalProps {
  isOpen: boolean
  onClose: () => void
  qrCode: string
  pixCode: string
  pixKey: string
  amount: number
  transactionId: string
  expiresAt?: string
  onPaymentCompleted?: (amount: number, newBalance: number) => void
}

export function PixDisplayModal({
  isOpen,
  onClose,
  qrCode,
  pixCode,
  pixKey,
  amount,
  transactionId,
  expiresAt,
  onPaymentCompleted,
}: PixDisplayModalProps) {
  const [copied, setCopied] = useState(false)
  const [timeRemaining, setTimeRemaining] = useState<number>(300)
  const [isExpired, setIsExpired] = useState(false)
  const [isChecking, setIsChecking] = useState(false)
  const [paymentConfirmed, setPaymentConfirmed] = useState(false)
  const [hasError, setHasError] = useState(false)

  useEffect(() => {
    if (!isOpen || !transactionId || isExpired || paymentConfirmed || hasError) return

    const checkPaymentStatus = async () => {
      if (isChecking) return

      setIsChecking(true)
      try {
        const response = await fetch(`/api/status/${transactionId}`)
        
        if (!response.ok) {
          if (response.status === 404) {
            console.error("[PIX] Depósito não encontrado (404). Parando polling.")
            setHasError(true)
            return
          }
          throw new Error(`HTTP ${response.status}`)
        }

        const result = await response.json()

        if (!result.success) {
          if (result.message === "Depósito não encontrado") {
            console.error("[PIX] Depósito não encontrado. Parando polling.")
            setHasError(true)
            return
          }
          console.error("[PIX] Erro na resposta:", result.message)
          return
        }

        // Verifica se o pagamento foi confirmado (completed ou paid)
        if (result.data.status === "completed" || result.data.status === "paid") {
          console.log("[PIX] ✅ Pagamento confirmado! Saldo: R$", result.data.updatedBalance || "N/A")
          setPaymentConfirmed(true)

          if (onPaymentCompleted) {
            const newBalance = result.data.updatedBalance !== null ? result.data.updatedBalance : 0
            onPaymentCompleted(amount, newBalance)
          }
        }
      } catch (error) {
        console.error("[PIX] Erro ao verificar status:", error)
        // Não para o polling em caso de erro de rede, apenas loga
      } finally {
        setIsChecking(false)
      }
    }

    const statusInterval = setInterval(checkPaymentStatus, 3000)
    checkPaymentStatus()

    return () => clearInterval(statusInterval)
  }, [isOpen, transactionId, isExpired, paymentConfirmed, hasError, amount, onPaymentCompleted, isChecking])

  useEffect(() => {
    if (!isOpen || !expiresAt) return

    const calculateTimeRemaining = () => {
      const now = Date.now()
      const expirationTime = new Date(expiresAt).getTime()
      const remaining = Math.max(0, Math.floor((expirationTime - now) / 1000))

      setTimeRemaining(remaining)

      if (remaining === 0) {
        setIsExpired(true)
      }
    }

    calculateTimeRemaining()
    const interval = setInterval(calculateTimeRemaining, 1000)

    return () => clearInterval(interval)
  }, [isOpen, expiresAt])

  if (!isOpen) return null

  const handleCopy = async () => {
    try {
      const textToCopy = pixCode || pixKey
      await navigator.clipboard.writeText(textToCopy)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("[v0] Erro ao copiar código PIX:", err)
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const getTimerColor = () => {
    if (timeRemaining <= 60) return "text-red-600"
    if (timeRemaining <= 120) return "text-orange-600"
    return "text-green-600"
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div
        className="bg-white rounded-[20px] max-w-md w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-[#8BA3A3]/20 px-6 py-4 flex items-center justify-between rounded-t-[20px]">
          <h2 className="text-xl font-semibold text-[#1E1E1E]">Pagamento PIX</h2>
          <button onClick={onClose} className="text-[#5E6B6B] hover:text-[#1E1E1E] transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Amount */}
          <div className="text-center">
            <p className="text-sm text-[#5E6B6B] mb-1">Valor do depósito</p>
            <p className="text-3xl font-bold text-[#0A3C3C]">R$ {amount.toFixed(2)}</p>
          </div>

          {paymentConfirmed ? (
            <div className="flex items-center justify-center gap-2 p-4 rounded-lg bg-green-50 border-2 border-green-500">
              <CheckCircle className="w-6 h-6 text-green-600" />
              <p className="text-base font-semibold text-green-800">✅ Pagamento Confirmado!</p>
            </div>
          ) : hasError ? (
            <div className="flex items-center justify-center gap-2 p-3 rounded-lg bg-red-50 border border-red-200">
              <p className="text-sm text-red-800">Erro ao verificar depósito. Por favor, recarregue a página.</p>
            </div>
          ) : !isExpired ? (
            <div className="flex items-center justify-center gap-2 p-3 rounded-lg bg-blue-50 border border-blue-200">
              <div className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></div>
              <p className="text-sm text-blue-800">Aguardando pagamento...</p>
            </div>
          ) : null}

          {expiresAt && !paymentConfirmed && (
            <div
              className={`flex items-center justify-center gap-2 p-3 rounded-lg ${
                isExpired
                  ? "bg-red-50 border border-red-200"
                  : timeRemaining <= 60
                    ? "bg-red-50 border border-red-200"
                    : "bg-blue-50 border border-blue-200"
              }`}
            >
              <Clock className={`w-5 h-5 ${isExpired ? "text-red-600" : getTimerColor()}`} />
              <div className="text-center">
                {isExpired ? (
                  <p className="text-sm font-semibold text-red-600">QR Code expirado</p>
                ) : (
                  <>
                    <p className="text-xs text-[#5E6B6B]">Tempo restante</p>
                    <p className={`text-lg font-bold ${getTimerColor()}`}>{formatTime(timeRemaining)}</p>
                  </>
                )}
              </div>
            </div>
          )}

          {!paymentConfirmed && (
            <div className="flex flex-col items-center gap-4">
              <div
                className={`bg-white border-2 rounded-xl p-4 ${
                  isExpired ? "border-red-300 opacity-50" : "border-[#8BA3A3]/20"
                }`}
              >
                <img src={qrCode || "/placeholder.svg"} alt="QR Code PIX" className="w-64 h-64" />
              </div>
              {transactionId && <p className="text-xs text-[#5E6B6B] text-center">ID da transação: {transactionId}</p>}
            </div>
          )}

          {isExpired && !paymentConfirmed && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-sm font-semibold text-red-900 mb-2">QR Code expirado</p>
              <p className="text-sm text-red-800">
                Este QR Code expirou. Por favor, feche esta janela e gere um novo código PIX.
              </p>
            </div>
          )}

          {!isExpired && !paymentConfirmed && (
            <div>
              <label className="block text-sm font-medium text-[#1E1E1E] mb-2 text-center">
                Ou copie o código PIX Copia e Cola
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={pixCode || pixKey}
                  readOnly
                  className="flex-1 px-4 py-2.5 rounded-lg border border-[#8BA3A3]/20 bg-[#F5F5F5] text-[#5E6B6B] text-sm"
                />
                <Button
                  onClick={handleCopy}
                  className={`px-4 py-2.5 rounded-lg font-medium transition-all ${
                    copied ? "bg-green-600 hover:bg-green-700 text-white" : "bg-[#0A3C3C] hover:bg-[#0C5050] text-white"
                  }`}
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 mr-1" />
                      Copiado
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-1" />
                      Copiar
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}

          {!isExpired && !paymentConfirmed && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
              <p className="text-sm font-semibold text-blue-900">Instruções de pagamento</p>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Escaneie o QR Code com o app do seu banco</li>
                <li>• Ou copie e cole o código PIX no seu app</li>
                <li>• O pagamento será confirmado automaticamente</li>
                <li>• Este código expira em 5 minutos</li>
              </ul>
            </div>
          )}

          {paymentConfirmed && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 space-y-2">
              <p className="text-sm font-semibold text-green-900">Pagamento confirmado com sucesso!</p>
              <p className="text-sm text-green-800">
                Seu depósito de R$ {amount.toFixed(2)} foi confirmado e seu saldo foi atualizado automaticamente.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-[#8BA3A3]/20 p-6">
          <Button
            onClick={onClose}
            className="w-full bg-[#0A3C3C] hover:bg-[#0C5050] text-white py-2.5 rounded-lg font-medium transition-colors"
          >
            {paymentConfirmed ? "Concluir" : isExpired ? "Gerar novo código" : "Fechar"}
          </Button>
        </div>
      </div>
    </div>
  )
}
