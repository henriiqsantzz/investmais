"use client"

import type React from "react"

import { useState } from "react"
import { X, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

interface RechargeModalProps {
  isOpen: boolean
  onClose: () => void
}

const PRESET_AMOUNTS = [50, 100, 200, 500, 1000, 2000, 3000, 5000, 10000, 20000, 50000]
const MIN_DEPOSIT = 50

export function RechargeModal({ isOpen, onClose }: RechargeModalProps) {
  const [amount, setAmount] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  if (!isOpen) return null

  const handleAmountClick = (value: number) => {
    setAmount(value.toString())
    setError("")
  }

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAmount(e.target.value)
    setError("")
  }

  const handleConfirm = async () => {
    setError("")
    setSuccess("")

    const numAmount = Number.parseFloat(amount)

    if (!amount || isNaN(numAmount)) {
      setError("Por favor, insira um valor válido")
      return
    }

    if (numAmount < MIN_DEPOSIT) {
      setError(`Valor mínimo de depósito é R$ ${MIN_DEPOSIT}`)
      return
    }

    try {
      setLoading(true)

      const response = await fetch("/api/payments/deposit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: numAmount,
          paymentMethod: "PIX",
          customerData: {
            name: "João Silva", // TODO: Pegar dados reais do usuário
            email: "joao@email.com",
            document: "12345678901",
            phone: "+5511999999999",
          },
          metadata: {
            orderId: `ORDER_${Date.now()}`,
            description: `Depósito via PIX - R$ ${numAmount}`,
          },
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.message || "Erro ao processar depósito")
        return
      }

      setSuccess("Depósito iniciado com sucesso! Escaneie o QR code PIX para completar o pagamento.")
      setAmount("")

      setTimeout(() => {
        onClose()
        setSuccess("")
      }, 2000)
    } catch (err) {
      setError("Erro ao conectar com o servidor")
      console.error("[v0] Deposit error:", err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="bg-white rounded-3xl w-full max-w-sm overflow-hidden">
        <div className="bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] px-6 py-4 flex items-center justify-between">
          <h3 className="text-lg font-bold text-white">Depósito</h3>
          <button onClick={onClose} className="text-white hover:opacity-80 transition-opacity">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Amount Input */}
          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-2">Valor do depósito</label>
            <Input
              type="number"
              placeholder="Valor do depósito"
              value={amount}
              onChange={handleAmountChange}
              min={MIN_DEPOSIT}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A3C3C]"
            />
          </div>

          {/* Preset Amounts */}
          <div className="grid grid-cols-3 gap-2">
            {PRESET_AMOUNTS.map((value) => (
              <button
                key={value}
                onClick={() => handleAmountClick(value)}
                className={`py-2 px-3 rounded-full font-medium text-sm transition-all ${
                  amount === value.toString()
                    ? "bg-[#0A3C3C] text-white"
                    : "border border-[#0A3C3C] text-[#0A3C3C] hover:bg-[#0A3C3C]/5"
                }`}
              >
                {value}
              </button>
            ))}
          </div>

          {/* Payment Method */}
          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-2">Método de depósito</label>
            <button className="w-full border-2 border-[#0A3C3C] rounded-full px-4 py-3 text-left font-medium text-[#0A3C3C] hover:bg-[#0A3C3C]/5 transition-colors">
              ZIPRAPAY
              <div className="text-xs text-gray-500 mt-1">Intervalo de valores: R$ {MIN_DEPOSIT} - 50000</div>
            </button>
          </div>

          {/* Error Message */}
          {error && (
            <div className="flex items-center gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
              <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          {/* Success Message */}
          {success && (
            <div className="flex items-center gap-2 bg-green-50 border border-green-200 rounded-lg px-3 py-2">
              <div className="w-4 h-4 text-green-600 flex-shrink-0">✓</div>
              <p className="text-sm text-green-600">{success}</p>
            </div>
          )}

          {/* Confirm Button */}
          <Button
            onClick={handleConfirm}
            disabled={loading}
            className="w-full bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] hover:from-[#0C5050] hover:to-[#0A5050] text-white font-semibold py-3 rounded-full transition-all disabled:opacity-50"
          >
            {loading ? "Processando..." : "Confirmar"}
          </Button>

          {/* Rules */}
          <div className="bg-gray-50 rounded-lg p-4 space-y-2">
            <h4 className="font-semibold text-sm text-[#1E1E1E]">Descrição da regra</h4>
            <ul className="text-xs text-[#5E6B6B] space-y-1">
              <li>
                1. Não altere o valor da recarga e certifique-se de transferir de acordo com o valor que iniciou a
                recarga.
              </li>
              <li>2. Inicie cada recarga por meio desta página e não salve a conta de transferência</li>
              <li>3. Valor de recarga única entre {MIN_DEPOSIT} e 50000.</li>
              <li>
                4. Se a recarga for iniciada há mais de 5 minutos, mas não for recebida, envie um problema de recarga
                não recebida por meio da central de ajuda de autoatendimento.
              </li>
              <li>
                5. Devido à popularidade da plataforma, a inicialização da recarga pode falhar. Tente algumas vezes.
              </li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  )
}
