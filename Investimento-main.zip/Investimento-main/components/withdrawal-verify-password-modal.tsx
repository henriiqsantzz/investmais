"use client"

import { useState } from "react"
import { X, Lock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface WithdrawalVerifyPasswordModalProps {
  isOpen: boolean
  onClose: () => void
  onVerified: () => void
}

export function WithdrawalVerifyPasswordModal({ isOpen, onClose, onVerified }: WithdrawalVerifyPasswordModalProps) {
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  if (!isOpen) return null

  const handlePasswordChange = (value: string) => {
    const numericValue = value.replace(/\D/g, "").slice(0, 4)
    setPassword(numericValue)
  }

  const handleSubmit = async () => {
    setError("")

    if (password.length !== 4) {
      setError("Digite a senha de 4 dígitos")
      return
    }

    setLoading(true)

    try {
      const response = await fetch("/api/user/verify-withdrawal-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Senha incorreta")
      }

      onVerified()
      onClose()
    } catch (err: any) {
      setError(err.message)
      setPassword("")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="bg-white rounded-2xl p-6 w-full max-w-md">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Lock className="w-5 h-5 text-[#0A3C3C]" />
            <h3 className="text-lg font-semibold text-[#1E1E1E]">Verificar Senha de Saque</h3>
          </div>
          <button onClick={onClose}>
            <X className="w-5 h-5 text-[#5E6B6B]" />
          </button>
        </div>

        <p className="text-sm text-[#5E6B6B] mb-4">Digite sua senha de 4 dígitos para confirmar o saque</p>

        <div className="space-y-4">
          <div>
            <label className="text-sm text-[#5E6B6B] mb-1 block">Senha de Saque</label>
            <input
              type="tel"
              inputMode="numeric"
              pattern="[0-9]*"
              value={password}
              onChange={(e) => handlePasswordChange(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C] text-center text-2xl tracking-widest"
              placeholder="••••"
              maxLength={4}
              autoFocus
            />
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-3">
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          <Button
            onClick={handleSubmit}
            disabled={loading || password.length !== 4}
            className="w-full bg-[#0A3C3C] hover:bg-[#0C5050] text-white rounded-xl py-3 disabled:opacity-50"
          >
            {loading ? "Verificando..." : "Confirmar"}
          </Button>
        </div>
      </Card>
    </div>
  )
}
