"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Upload, Save, ImageIcon, Percent, Type, AlertCircle } from "lucide-react"

interface Setting {
  id: string
  key: string
  value: string
  type: string
  category: string
  description: string
}

export function WhitelabelSettings() {
  const [settings, setSettings] = useState<Setting[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [editedSettings, setEditedSettings] = useState<Record<string, string>>({})

  useEffect(() => {
    fetchSettings()
  }, [])

  const fetchSettings = async () => {
    try {
      setError(null)
      const supabase = createClient()

      console.log("[v0] Buscando configurações do site...")
      const { data, error } = await supabase.from("site_settings").select("*").order("category", { ascending: true })

      if (error) {
        console.error("[v0] Erro ao buscar configurações:", error)
        throw error
      }

      console.log("[v0] Configurações carregadas:", data)

      if (!data || data.length === 0) {
        setError(
          "Nenhuma configuração encontrada. Execute o script 023_create_site_settings.sql e 024_initialize_site_settings.sql para inicializar.",
        )
      } else {
        setSettings(data)
      }
    } catch (error: any) {
      console.error("[v0] Erro ao carregar configurações:", error)

      if (error.code === "42P01") {
        setError("Tabela site_settings não existe. Execute o script 023_create_site_settings.sql para criar a tabela.")
      } else if (error.message?.includes("permission denied")) {
        setError("Sem permissão para acessar configurações. Verifique se você é admin.")
      } else {
        setError(`Erro ao carregar configurações: ${error.message || "Erro desconhecido"}`)
      }
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const supabase = createClient()

      // Update each edited setting
      for (const [key, value] of Object.entries(editedSettings)) {
        const { error } = await supabase
          .from("site_settings")
          .update({ value, updated_at: new Date().toISOString() })
          .eq("key", key)

        if (error) throw error
      }

      alert("Configurações salvas com sucesso!")
      setEditedSettings({})
      await fetchSettings()
    } catch (error) {
      console.error("Erro ao salvar configurações:", error)
      alert("Erro ao salvar configurações")
    } finally {
      setSaving(false)
    }
  }

  const handleChange = (key: string, value: string) => {
    setEditedSettings((prev) => ({ ...prev, [key]: value }))
  }

  const handleImageUpload = async (key: string, file: File) => {
    try {
      // In a real implementation, you would upload to Vercel Blob or similar
      // For now, we'll just use a placeholder
      const reader = new FileReader()
      reader.onloadend = () => {
        handleChange(key, reader.result as string)
      }
      reader.readAsDataURL(file)
    } catch (error) {
      console.error("Erro ao fazer upload da imagem:", error)
      alert("Erro ao fazer upload da imagem")
    }
  }

  const groupedSettings = settings.reduce(
    (acc, setting) => {
      if (!acc[setting.category]) {
        acc[setting.category] = []
      }
      acc[setting.category].push(setting)
      return acc
    },
    {} as Record<string, Setting[]>,
  )

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-12 h-12 rounded-full border-4 border-[#8BA3A3]/20 border-t-[#0A3C3C] animate-spin mx-auto mb-4"></div>
          <p className="text-sm text-[#5E6B6B]">Carregando configurações...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center py-12">
        <Card className="bg-red-50 border-red-200 p-6 max-w-2xl">
          <div className="flex items-start gap-4">
            <AlertCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-red-900 mb-2">Erro ao Carregar Configurações</h3>
              <p className="text-sm text-red-700 mb-4">{error}</p>
              <div className="bg-white rounded-lg p-4 border border-red-200">
                <p className="text-xs font-mono text-gray-700 mb-2">Para corrigir, execute os seguintes scripts SQL:</p>
                <ol className="text-xs font-mono text-gray-600 space-y-1 list-decimal list-inside">
                  <li>scripts/023_create_site_settings.sql</li>
                  <li>scripts/024_initialize_site_settings.sql</li>
                </ol>
              </div>
              <Button onClick={fetchSettings} className="mt-4 bg-red-600 hover:bg-red-700 text-white">
                Tentar Novamente
              </Button>
            </div>
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-[#1E1E1E]">Configurações Whitelabel</h2>
          <p className="text-sm text-[#5E6B6B] mt-1">Personalize a aparência e configurações do site</p>
        </div>
        <Button
          onClick={handleSave}
          disabled={saving || Object.keys(editedSettings).length === 0}
          className="bg-[#0A3C3C] hover:bg-[#0C5050] text-white"
        >
          <Save className="w-4 h-4 mr-2" />
          {saving ? "Salvando..." : "Salvar Alterações"}
        </Button>
      </div>

      {Object.entries(groupedSettings).map(([category, categorySettings]) => (
        <Card key={category} className="bg-white rounded-xl p-6 border-0 shadow-sm">
          <h3 className="text-lg font-semibold text-[#1E1E1E] mb-4 capitalize">
            {category === "branding"
              ? "Marca e Identidade Visual"
              : category === "investment"
                ? "Configurações de Investimento"
                : category}
          </h3>
          <div className="space-y-4">
            {categorySettings.map((setting) => (
              <div key={setting.key} className="space-y-2">
                <label className="flex items-center gap-2 text-sm font-medium text-[#1E1E1E]">
                  {setting.type === "image" && <ImageIcon className="w-4 h-4" />}
                  {setting.type === "percentage" && <Percent className="w-4 h-4" />}
                  {setting.type === "text" && <Type className="w-4 h-4" />}
                  {setting.description}
                </label>

                {setting.type === "image" ? (
                  <div className="space-y-2">
                    {(editedSettings[setting.key] || setting.value) && (
                      <div className="w-32 h-32 rounded-lg border-2 border-[#8BA3A3]/20 overflow-hidden bg-[#F5F5F5] flex items-center justify-center">
                        <img
                          src={editedSettings[setting.key] || setting.value}
                          alt={setting.description}
                          className="max-w-full max-h-full object-contain"
                        />
                      </div>
                    )}
                    <div className="flex gap-2">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0]
                          if (file) handleImageUpload(setting.key, file)
                        }}
                        className="hidden"
                        id={`upload-${setting.key}`}
                      />
                      <label
                        htmlFor={`upload-${setting.key}`}
                        className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[#8BA3A3]/20 hover:bg-[#F5F5F5] cursor-pointer transition-colors"
                      >
                        <Upload className="w-4 h-4" />
                        <span className="text-sm">Fazer Upload</span>
                      </label>
                      <input
                        type="text"
                        value={editedSettings[setting.key] ?? setting.value}
                        onChange={(e) => handleChange(setting.key, e.target.value)}
                        placeholder="URL da imagem"
                        className="flex-1 px-4 py-2 rounded-lg border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C]"
                      />
                    </div>
                  </div>
                ) : setting.type === "percentage" || setting.type === "number" ? (
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      step={setting.type === "percentage" ? "0.1" : "1"}
                      value={editedSettings[setting.key] ?? setting.value}
                      onChange={(e) => handleChange(setting.key, e.target.value)}
                      className="w-full px-4 py-2 rounded-lg border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C]"
                    />
                    {setting.type === "percentage" && <span className="text-sm text-[#5E6B6B]">%</span>}
                  </div>
                ) : (
                  <input
                    type="text"
                    value={editedSettings[setting.key] ?? setting.value}
                    onChange={(e) => handleChange(setting.key, e.target.value)}
                    className="w-full px-4 py-2 rounded-lg border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C]"
                  />
                )}
                <p className="text-xs text-[#5E6B6B]">Chave: {setting.key}</p>
              </div>
            ))}
          </div>
        </Card>
      ))}
    </div>
  )
}
