"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import {
  Users,
  DollarSign,
  Activity,
  Search,
  Filter,
  Download,
  CheckCircle,
  XCircle,
  ArrowLeft,
  Edit,
  TrendingUp,
  TrendingDown,
} from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { WhitelabelSettings } from "@/components/admin/whitelabel-settings"

interface User {
  id: string
  name: string
  email: string
  balance: number
  withdrawal_balance: number
  role: string
  created_at: string
}

interface Investment {
  id: string
  user_id: string
  product_name: string
  investment_amount: number
  status: string
  created_at: string
  profiles: { name: string; email: string }
  daily_return?: number // Adicionado para o histórico de investimentos
}

interface Deposit {
  id: string
  user_id: string
  amount: number
  status: string
  created_at: string
  payment_method: string
  profiles: { name: string; email: string }
}

interface Withdrawal {
  id: string
  user_id: string
  amount: number
  status: string
  created_at: string
  pix_key: string
  pix_key_type: string
  profiles: { name: string; email: string }
}

interface AdminDashboardProps {
  initialUsers: User[]
  initialInvestments: Investment[]
  initialDeposits: Deposit[]
  initialWithdrawals: Withdrawal[]
}

export function AdminDashboard({
  initialUsers,
  initialInvestments,
  initialDeposits,
  initialWithdrawals,
}: AdminDashboardProps) {
  const [activeSection, setActiveSection] = useState<
    "dashboard" | "users" | "investments" | "deposits" | "withdrawals" | "settings"
  >("dashboard")
  const [searchTerm, setSearchTerm] = useState("")

  const [users, setUsers] = useState<User[]>(initialUsers)
  const [investments, setInvestments] = useState<Investment[]>(initialInvestments)
  const [deposits, setDeposits] = useState<Deposit[]>(initialDeposits)
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>(initialWithdrawals)

  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [editName, setEditName] = useState("")
  const [editBalance, setEditBalance] = useState("")
  const [editWithdrawalBalance, setEditWithdrawalBalance] = useState("")
  const [isRefreshing, setIsRefreshing] = useState(false)

  useEffect(() => {
    console.log("[v0 Admin Dashboard] Investimentos carregados:", investments.length)
    console.log("[v0 Admin Dashboard] Depósitos carregados:", deposits.length)
    console.log("[v0 Admin Dashboard] Saques carregados:", withdrawals.length)
    console.log("[v0 Admin Dashboard] Usuários carregados:", users.length)
  }, [investments, deposits, withdrawals, users])

  // Calculate stats
  const stats = {
    totalUsers: users.length,
    activeInvestments: investments.filter((i) => i.status === "active").length,
    totalInvestments: investments.length,
    totalInvested: investments.reduce((sum, i) => sum + Number(i.investment_amount), 0),
    pendingWithdrawals: withdrawals.filter((w) => w.status === "pending").length,
    pendingDeposits: deposits.filter((d) => d.status === "pending").length,
    approvedDeposits: deposits.filter((d) => d.status === "completed").length,
    totalDeposits: deposits.reduce((sum, d) => sum + Number(d.amount), 0),
    totalBalance: users.reduce((sum, u) => sum + Number(u.balance || 0), 0),
    totalWithdrawalBalance: users.reduce((sum, u) => sum + Number(u.withdrawal_balance || 0), 0),
  }

  const refreshData = async () => {
    setIsRefreshing(true)
    const supabase = createClient()

    try {
      const [usersRes, investmentsRes, depositsRes, withdrawalsRes] = await Promise.all([
        supabase.from("profiles").select("*").order("created_at", { ascending: false }),
        supabase.from("investments").select("*, profiles(name, email)").order("created_at", { ascending: false }),
        supabase.from("deposits").select("*, profiles(name, email)").order("created_at", { ascending: false }),
        supabase.from("withdrawals").select("*, profiles(name, email)").order("created_at", { ascending: false }),
      ])

      if (usersRes.data) setUsers(usersRes.data)
      if (investmentsRes.data) setInvestments(investmentsRes.data)
      if (depositsRes.data) setDeposits(depositsRes.data)
      if (withdrawalsRes.data) setWithdrawals(withdrawalsRes.data)

      console.log("[v0 Admin] Dados atualizados com sucesso")
    } catch (error) {
      console.error("[v0 Admin] Erro ao atualizar dados:", error)
      alert("Erro ao atualizar dados")
    } finally {
      setIsRefreshing(false)
    }
  }

  const handleApproveDeposit = async (id: string, userId: string, amount: number) => {
    const supabase = createClient()

    const { error: depositError } = await supabase.from("deposits").update({ status: "completed" }).eq("id", id)

    if (depositError) {
      alert("Erro ao aprovar depósito")
      return
    }

    const { data: userData } = await supabase.from("profiles").select("balance").eq("id", userId).single()

    if (userData) {
      const newBalance = Number(userData.balance || 0) + Number(amount)
      await supabase.from("profiles").update({ balance: newBalance }).eq("id", userId)
    }

    setDeposits(deposits.map((d) => (d.id === id ? { ...d, status: "completed" } : d)))
    alert("Depósito aprovado e saldo atualizado!")
  }

  const handleRejectDeposit = async (id: string) => {
    const supabase = createClient()

    const { error } = await supabase.from("deposits").update({ status: "cancelled" }).eq("id", id)

    if (!error) {
      setDeposits(deposits.map((d) => (d.id === id ? { ...d, status: "cancelled" } : d)))
      alert("Depósito rejeitado")
    } else {
      alert("Erro ao rejeitar depósito")
    }
  }

  const handleApproveWithdrawal = async (id: string, userId: string, amount: number) => {
    const supabase = createClient()

    const { error: withdrawalError } = await supabase.from("withdrawals").update({ status: "completed" }).eq("id", id)

    if (withdrawalError) {
      alert("Erro ao aprovar saque")
      return
    }

    const { data: userData } = await supabase.from("profiles").select("withdrawal_balance").eq("id", userId).single()

    if (userData) {
      const newBalance = Number(userData.withdrawal_balance || 0) - Number(amount)
      await supabase
        .from("profiles")
        .update({ withdrawal_balance: Math.max(0, newBalance) })
        .eq("id", userId)
    }

    setWithdrawals(withdrawals.map((w) => (w.id === id ? { ...w, status: "completed" } : w)))
    alert("Saque aprovado!")
  }

  const handleRejectWithdrawal = async (id: string, userId: string, amount: number) => {
    const supabase = createClient()

    const { error: withdrawalError } = await supabase.from("withdrawals").update({ status: "cancelled" }).eq("id", id)

    if (withdrawalError) {
      alert("Erro ao rejeitar saque")
      return
    }

    const { data: userData } = await supabase.from("profiles").select("withdrawal_balance").eq("id", userId).single()

    if (userData) {
      const newBalance = Number(userData.withdrawal_balance || 0) + Number(amount)
      await supabase.from("profiles").update({ withdrawal_balance: newBalance }).eq("id", userId)
    }

    setWithdrawals(withdrawals.map((w) => (w.id === id ? { ...w, status: "cancelled" } : w)))
    alert("Saque rejeitado e valor devolvido")
  }

  const handleUpdateBalance = async () => {
    if (!editingUser) return

    const supabase = createClient()

    const newBalance = Number.parseFloat(editBalance)
    const newWithdrawalBalance = Number.parseFloat(editWithdrawalBalance)

    if (isNaN(newBalance) || isNaN(newWithdrawalBalance)) {
      alert("Valores inválidos")
      return
    }

    if (!editName.trim()) {
      alert("Nome não pode estar vazio")
      return
    }

    const { error } = await supabase
      .from("profiles")
      .update({
        name: editName.trim(),
        balance: newBalance,
        withdrawal_balance: newWithdrawalBalance,
      })
      .eq("id", editingUser.id)

    if (!error) {
      setUsers(
        users.map((u) =>
          u.id === editingUser.id
            ? { ...u, name: editName.trim(), balance: newBalance, withdrawal_balance: newWithdrawalBalance }
            : u,
        ),
      )
      setEditingUser(null)
      setEditName("")
      setEditBalance("")
      setEditWithdrawalBalance("")
      alert("Dados atualizados com sucesso!")
    } else {
      alert("Erro ao atualizar dados")
    }
  }

  const pendingWithdrawals = withdrawals.filter((w) => w.status === "pending")
  const pendingDeposits = deposits.filter((d) => d.status === "pending")

  return (
    <div className="min-h-screen bg-[#C1D7D7]">
      <header className="bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] px-4 md:px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-xl md:text-2xl font-bold text-white">Painel Administrativo</h1>
          </div>
          <div className="flex items-center gap-4">
            <Button
              onClick={refreshData}
              disabled={isRefreshing}
              variant="ghost"
              className="text-white hover:bg-white/10"
            >
              <Activity className={`w-5 h-5 ${isRefreshing ? "animate-spin" : ""}`} />
            </Button>
            <div className="text-white text-sm">
              Admin: <span className="font-semibold">Sistema</span>
            </div>
          </div>
        </div>
      </header>

      <div className="bg-white border-b border-[#8BA3A3]/20 px-4 md:px-8">
        <div className="flex gap-1 overflow-x-auto">
          <button
            onClick={() => setActiveSection("dashboard")}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeSection === "dashboard"
                ? "border-[#0A3C3C] text-[#0A3C3C]"
                : "border-transparent text-[#5E6B6B] hover:text-[#0A3C3C]"
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveSection("users")}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeSection === "users"
                ? "border-[#0A3C3C] text-[#0A3C3C]"
                : "border-transparent text-[#5E6B6B] hover:text-[#0A3C3C]"
            }`}
          >
            Usuários
          </button>
          <button
            onClick={() => setActiveSection("deposits")}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeSection === "deposits"
                ? "border-[#0A3C3C] text-[#0A3C3C]"
                : "border-transparent text-[#5E6B6B] hover:text-[#0A3C3C]"
            }`}
          >
            Depósitos
            {pendingDeposits.length > 0 && (
              <span className="ml-2 px-2 py-0.5 bg-blue-500 text-white text-xs rounded-full">
                {pendingDeposits.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveSection("investments")}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeSection === "investments"
                ? "border-[#0A3C3C] text-[#0A3C3C]"
                : "border-transparent text-[#5E6B6B] hover:text-[#0A3C3C]"
            }`}
          >
            Investimentos
          </button>
          <button
            onClick={() => setActiveSection("withdrawals")}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeSection === "withdrawals"
                ? "border-[#0A3C3C] text-[#0A3C3C]"
                : "border-transparent text-[#5E6B6B] hover:text-[#0A3C3C]"
            }`}
          >
            Saques
            {pendingWithdrawals.length > 0 && (
              <span className="ml-2 px-2 py-0.5 bg-red-500 text-white text-xs rounded-full">
                {pendingWithdrawals.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveSection("settings")}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeSection === "settings"
                ? "border-[#0A3C3C] text-[#0A3C3C]"
                : "border-transparent text-[#5E6B6B] hover:text-[#0A3C3C]"
            }`}
          >
            Configurações
          </button>
        </div>
      </div>

      <div className="px-4 md:px-8 py-6">
        {activeSection === "dashboard" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-[#5E6B6B]">Total de Usuários</p>
                    <p className="text-2xl font-bold text-[#1E1E1E] mt-1">{stats.totalUsers}</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </Card>

              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-[#5E6B6B]">Investimentos Ativos</p>
                    <p className="text-2xl font-bold text-[#1E1E1E] mt-1">{stats.activeInvestments}</p>
                    <p className="text-xs text-[#5E6B6B] mt-1">de {stats.totalInvestments} total</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                    <Activity className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </Card>

              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-[#5E6B6B]">Total Investido</p>
                    <p className="text-2xl font-bold text-[#1E1E1E] mt-1">
                      R$ {stats.totalInvested.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-[#0A3C3C]/10 flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-[#0A3C3C]" />
                  </div>
                </div>
              </Card>

              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-[#5E6B6B]">Saldo Total Plataforma</p>
                    <p className="text-2xl font-bold text-[#1E1E1E] mt-1">
                      R$ {stats.totalBalance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
              </Card>

              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-[#5E6B6B]">Depósitos Pendentes</p>
                    <p className="text-2xl font-bold text-[#1E1E1E] mt-1">{stats.pendingDeposits}</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </Card>

              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-[#5E6B6B]">Depósitos Aprovados</p>
                    <p className="text-2xl font-bold text-[#1E1E1E] mt-1">{stats.approvedDeposits}</p>
                    <p className="text-xs text-green-600 mt-1">
                      R$ {stats.totalDeposits.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </Card>

              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-[#5E6B6B]">Saques Pendentes</p>
                    <p className="text-2xl font-bold text-[#1E1E1E] mt-1">{stats.pendingWithdrawals}</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center">
                    <TrendingDown className="w-6 h-6 text-orange-600" />
                  </div>
                </div>
              </Card>

              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-[#5E6B6B]">Saldo de Saque Total</p>
                    <p className="text-2xl font-bold text-[#1E1E1E] mt-1">
                      R$ {stats.totalWithdrawalBalance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-emerald-600" />
                  </div>
                </div>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <h3 className="text-lg font-semibold text-[#1E1E1E] mb-4">Usuários Recentes</h3>
                <div className="space-y-3">
                  {users.slice(0, 5).map((user) => (
                    <div
                      key={user.id}
                      className="flex items-center justify-between py-2 border-b border-[#8BA3A3]/20 last:border-0"
                    >
                      <div>
                        <p className="text-sm font-medium text-[#1E1E1E]">{user.name || "Sem nome"}</p>
                        <p className="text-xs text-[#5E6B6B]">{user.email || "Sem email"}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold text-[#0A3C3C]">R$ {(user.balance || 0).toFixed(2)}</p>
                        <p className="text-xs text-[#5E6B6B]">{user.role || "user"}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <h3 className="text-lg font-semibold text-[#1E1E1E] mb-4">Investimentos Recentes</h3>
                <div className="space-y-3">
                  {investments.slice(0, 5).map((investment) => (
                    <div
                      key={investment.id}
                      className="flex items-center justify-between py-2 border-b border-[#8BA3A3]/20 last:border-0"
                    >
                      <div>
                        <p className="text-sm font-medium text-[#1E1E1E]">{investment.profiles?.name || "Usuário"}</p>
                        <p className="text-xs text-[#5E6B6B]">{investment.product_name}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold text-[#0A3C3C]">
                          R$ {Number(investment.investment_amount).toFixed(2)}
                        </p>
                        <p className="text-xs text-[#5E6B6B]">
                          {new Date(investment.created_at).toLocaleDateString("pt-BR")}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>

            <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
              <h3 className="text-lg font-semibold text-[#1E1E1E] mb-4">Histórico de Investimentos</h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-[#8BA3A3]/10">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Usuário</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Produto</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Valor</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">
                        Retorno Diário
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Status</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Data</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#8BA3A3]/20">
                    {investments.slice(0, 10).map((investment) => (
                      <tr key={investment.id} className="hover:bg-[#8BA3A3]/5">
                        <td className="px-4 py-3 text-sm font-medium text-[#1E1E1E]">
                          {investment.profiles?.name || "Usuário"}
                        </td>
                        <td className="px-4 py-3 text-sm text-[#5E6B6B]">{investment.product_name}</td>
                        <td className="px-4 py-3 text-sm font-semibold text-[#0A3C3C]">
                          R$ {Number(investment.investment_amount).toFixed(2)}
                        </td>
                        <td className="px-4 py-3 text-sm text-green-600">
                          R$ {Number(investment.daily_return || 0).toFixed(2)}
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-medium ${
                              investment.status === "active"
                                ? "bg-green-100 text-green-800"
                                : investment.status === "completed"
                                  ? "bg-blue-100 text-blue-800"
                                  : "bg-gray-100 text-gray-800"
                            }`}
                          >
                            {investment.status === "active"
                              ? "Ativo"
                              : investment.status === "completed"
                                ? "Concluído"
                                : investment.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm text-[#5E6B6B]">
                          {new Date(investment.created_at).toLocaleDateString("pt-BR")}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {activeSection === "users" && (
          <div className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5E6B6B]" />
                <input
                  type="text"
                  placeholder="Buscar usuários..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-xl border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C]"
                />
              </div>
              <div className="flex gap-2">
                <Button className="bg-white text-[#0A3C3C] border border-[#8BA3A3]/20 hover:bg-[#8BA3A3]/10">
                  <Filter className="w-4 h-4 mr-2" />
                  Filtrar
                </Button>
                <Button className="bg-[#0A3C3C] text-white hover:bg-[#0C5050]">
                  <Download className="w-4 h-4 mr-2" />
                  Exportar
                </Button>
              </div>
            </div>

            <Card className="bg-white rounded-xl border-0 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-[#8BA3A3]/10">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Usuário</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Email</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Saldo</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Saldo Saque</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Função</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">
                        Data de Cadastro
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#8BA3A3]/20">
                    {users
                      .filter(
                        (u) =>
                          (u.name?.toLowerCase() || "").includes(searchTerm.toLowerCase()) ||
                          (u.email?.toLowerCase() || "").includes(searchTerm.toLowerCase()),
                      )
                      .map((user) => (
                        <tr key={user.id} className="hover:bg-[#8BA3A3]/5">
                          <td className="px-6 py-4 text-sm font-medium text-[#1E1E1E]">{user.name || "Sem nome"}</td>
                          <td className="px-6 py-4 text-sm text-[#5E6B6B]">{user.email || "Sem email"}</td>
                          <td className="px-6 py-4 text-sm font-semibold text-[#0A3C3C]">
                            R$ {(user.balance || 0).toFixed(2)}
                          </td>
                          <td className="px-6 py-4 text-sm font-semibold text-green-600">
                            R$ {(user.withdrawal_balance || 0).toFixed(2)}
                          </td>
                          <td className="px-6 py-4 text-sm">
                            <span
                              className={`px-2 py-1 rounded-full text-xs font-medium ${
                                user.role === "admin" ? "bg-purple-100 text-purple-800" : "bg-blue-100 text-blue-800"
                              }`}
                            >
                              {user.role || "user"}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm text-[#5E6B6B]">
                            {new Date(user.created_at).toLocaleDateString("pt-BR")}
                          </td>
                          <td className="px-6 py-4 text-sm">
                            <div className="flex gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-[#0A3C3C] hover:bg-[#0A3C3C]/10"
                                onClick={() => {
                                  setEditingUser(user)
                                  setEditName(user.name || "")
                                  setEditBalance((user.balance || 0).toString())
                                  setEditWithdrawalBalance((user.withdrawal_balance || 0).toString())
                                }}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {activeSection === "deposits" && (
          <div className="space-y-4">
            <div className="flex gap-2 mb-4">
              <Button
                onClick={() => setSearchTerm("")}
                className={`${searchTerm === "" ? "bg-[#0A3C3C] text-white" : "bg-white text-[#0A3C3C] border border-[#8BA3A3]/20"}`}
              >
                Todos ({deposits.length})
              </Button>
              <Button
                onClick={() => setSearchTerm("pending")}
                className={`${searchTerm === "pending" ? "bg-blue-600 text-white" : "bg-white text-blue-600 border border-blue-200"}`}
              >
                Pendentes ({deposits.filter((d) => d.status === "pending").length})
              </Button>
              <Button
                onClick={() => setSearchTerm("completed")}
                className={`${searchTerm === "completed" ? "bg-green-600 text-white" : "bg-white text-green-600 border border-green-200"}`}
              >
                Aprovados ({deposits.filter((d) => d.status === "completed").length})
              </Button>
              <Button
                onClick={() => setSearchTerm("cancelled")}
                className={`${searchTerm === "cancelled" ? "bg-red-600 text-white" : "bg-white text-red-600 border border-red-200"}`}
              >
                Cancelados ({deposits.filter((d) => d.status === "cancelled").length})
              </Button>
            </div>

            <Card className="bg-white rounded-xl border-0 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-[#8BA3A3]/10">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Usuário</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Email</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Valor</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Método</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Data/Hora</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#8BA3A3]/20">
                    {deposits
                      .filter((d) => searchTerm === "" || d.status === searchTerm)
                      .map((deposit) => (
                        <tr key={deposit.id} className="hover:bg-[#8BA3A3]/5">
                          <td className="px-6 py-4 text-sm font-medium text-[#1E1E1E]">
                            {deposit.profiles?.name || "Usuário"}
                          </td>
                          <td className="px-6 py-4 text-sm text-[#5E6B6B]">{deposit.profiles?.email || "Sem email"}</td>
                          <td className="px-6 py-4 text-sm font-semibold text-[#0A3C3C]">
                            R$ {Number(deposit.amount).toFixed(2)}
                          </td>
                          <td className="px-6 py-4 text-sm text-[#5E6B6B]">{deposit.payment_method || "PIX"}</td>
                          <td className="px-6 py-4 text-sm text-[#5E6B6B]">
                            {new Date(deposit.created_at).toLocaleString("pt-BR")}
                          </td>
                          <td className="px-6 py-4 text-sm">
                            <span
                              className={`px-2 py-1 rounded-full text-xs font-medium ${
                                deposit.status === "completed"
                                  ? "bg-green-100 text-green-800"
                                  : deposit.status === "pending"
                                    ? "bg-blue-100 text-blue-800"
                                    : "bg-red-100 text-red-800"
                              }`}
                            >
                              {deposit.status === "completed"
                                ? "Aprovado"
                                : deposit.status === "pending"
                                  ? "Pendente"
                                  : "Cancelado"}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm">
                            {deposit.status === "pending" ? (
                              <div className="flex gap-2">
                                <Button
                                  onClick={() => handleApproveDeposit(deposit.id, deposit.user_id, deposit.amount)}
                                  size="sm"
                                  className="bg-green-600 hover:bg-green-700 text-white"
                                >
                                  <CheckCircle className="w-4 h-4 mr-1" />
                                  Aprovar
                                </Button>
                                <Button
                                  onClick={() => handleRejectDeposit(deposit.id)}
                                  size="sm"
                                  className="bg-red-600 hover:bg-red-700 text-white"
                                >
                                  <XCircle className="w-4 h-4 mr-1" />
                                  Rejeitar
                                </Button>
                              </div>
                            ) : (
                              <span className="text-xs text-[#5E6B6B]">
                                {deposit.status === "completed" ? "Processado" : "Cancelado"}
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {activeSection === "investments" && (
          <div className="space-y-4">
            <Card className="bg-white rounded-xl border-0 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-[#8BA3A3]/10">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Usuário</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Email</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Produto</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Valor</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Data</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#8BA3A3]/20">
                    {investments.map((investment) => (
                      <tr key={investment.id} className="hover:bg-[#8BA3A3]/5">
                        <td className="px-6 py-4 text-sm font-medium text-[#1E1E1E]">
                          {investment.profiles?.name || "Usuário"}
                        </td>
                        <td className="px-6 py-4 text-sm text-[#5E6B6B]">
                          {investment.profiles?.email || "Sem email"}
                        </td>
                        <td className="px-6 py-4 text-sm text-[#5E6B6B]">{investment.product_name}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-[#0A3C3C]">
                          R$ {Number(investment.investment_amount).toFixed(2)}
                        </td>
                        <td className="px-6 py-4 text-sm text-[#5E6B6B]">
                          {new Date(investment.created_at).toLocaleDateString("pt-BR")}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-medium ${
                              investment.status === "active"
                                ? "bg-green-100 text-green-800"
                                : "bg-gray-100 text-gray-800"
                            }`}
                          >
                            {investment.status === "active" ? "Ativo" : investment.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {activeSection === "withdrawals" && (
          <div className="space-y-4">
            <div className="flex gap-2 mb-4">
              <Button
                onClick={() => setSearchTerm("")}
                className={`${searchTerm === "" ? "bg-[#0A3C3C] text-white" : "bg-white text-[#0A3C3C] border border-[#8BA3A3]/20"}`}
              >
                Todos ({withdrawals.length})
              </Button>
              <Button
                onClick={() => setSearchTerm("pending")}
                className={`${searchTerm === "pending" ? "bg-orange-600 text-white" : "bg-white text-orange-600 border border-orange-200"}`}
              >
                Pendentes ({withdrawals.filter((w) => w.status === "pending").length})
              </Button>
              <Button
                onClick={() => setSearchTerm("completed")}
                className={`${searchTerm === "completed" ? "bg-green-600 text-white" : "bg-white text-green-600 border border-green-200"}`}
              >
                Aprovados ({withdrawals.filter((w) => w.status === "completed").length})
              </Button>
              <Button
                onClick={() => setSearchTerm("cancelled")}
                className={`${searchTerm === "cancelled" ? "bg-red-600 text-white" : "bg-white text-red-600 border border-red-200"}`}
              >
                Cancelados ({withdrawals.filter((w) => w.status === "cancelled").length})
              </Button>
            </div>

            <Card className="bg-white rounded-xl border-0 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-[#8BA3A3]/10">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Usuário</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Email</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Valor</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Chave Pix</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Data/Hora</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#8BA3A3]/20">
                    {withdrawals
                      .filter((w) => searchTerm === "" || w.status === searchTerm)
                      .map((withdrawal) => (
                        <tr key={withdrawal.id} className="hover:bg-[#8BA3A3]/5">
                          <td className="px-6 py-4 text-sm font-medium text-[#1E1E1E]">
                            {withdrawal.profiles?.name || "Usuário"}
                          </td>
                          <td className="px-6 py-4 text-sm text-[#5E6B6B]">
                            {withdrawal.profiles?.email || "Sem email"}
                          </td>
                          <td className="px-6 py-4 text-sm font-semibold text-[#0A3C3C]">
                            R$ {Number(withdrawal.amount).toFixed(2)}
                          </td>
                          <td className="px-6 py-4 text-sm text-[#5E6B6B]">
                            {withdrawal.pix_key_type}: {withdrawal.pix_key}
                          </td>
                          <td className="px-6 py-4 text-sm text-[#5E6B6B]">
                            {new Date(withdrawal.created_at).toLocaleString("pt-BR")}
                          </td>
                          <td className="px-6 py-4 text-sm">
                            <span
                              className={`px-2 py-1 rounded-full text-xs font-medium ${
                                withdrawal.status === "completed"
                                  ? "bg-green-100 text-green-800"
                                  : withdrawal.status === "pending"
                                    ? "bg-orange-100 text-orange-800"
                                    : "bg-red-100 text-red-800"
                              }`}
                            >
                              {withdrawal.status === "completed"
                                ? "Aprovado"
                                : withdrawal.status === "pending"
                                  ? "Pendente"
                                  : "Cancelado"}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm">
                            {withdrawal.status === "pending" ? (
                              <div className="flex gap-2">
                                <Button
                                  onClick={() =>
                                    handleApproveWithdrawal(withdrawal.id, withdrawal.user_id, withdrawal.amount)
                                  }
                                  size="sm"
                                  className="bg-green-600 hover:bg-green-700 text-white"
                                >
                                  <CheckCircle className="w-4 h-4 mr-1" />
                                  Aprovar
                                </Button>
                                <Button
                                  onClick={() =>
                                    handleRejectWithdrawal(withdrawal.id, withdrawal.user_id, withdrawal.amount)
                                  }
                                  size="sm"
                                  className="bg-red-600 hover:bg-red-700 text-white"
                                >
                                  <XCircle className="w-4 h-4 mr-1" />
                                  Rejeitar
                                </Button>
                              </div>
                            ) : (
                              <span className="text-xs text-[#5E6B6B]">
                                {withdrawal.status === "completed" ? "Processado" : "Cancelado"}
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {activeSection === "settings" && <WhitelabelSettings />}
      </div>

      {editingUser && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-[#1E1E1E] mb-4">Editar Dados do Usuário</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-[#5E6B6B] mb-1">Email</p>
                <p className="text-base font-medium text-[#1E1E1E]">{editingUser.email || "Sem email"}</p>
              </div>
              <div>
                <label className="text-sm text-[#5E6B6B] mb-1 block">Nome Completo</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-4 py-2 rounded-xl border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C]"
                  placeholder="Nome do usuário"
                />
              </div>
              <div>
                <p className="text-sm text-[#5E6B6B] mb-1">Saldo Atual</p>
                <p className="text-base font-medium text-[#1E1E1E]">R$ {(editingUser.balance || 0).toFixed(2)}</p>
              </div>
              <div>
                <label className="text-sm text-[#5E6B6B] mb-1 block">Novo Saldo</label>
                <input
                  type="number"
                  step="0.01"
                  value={editBalance}
                  onChange={(e) => setEditBalance(e.target.value)}
                  className="w-full px-4 py-2 rounded-xl border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C]"
                  placeholder="0.00"
                />
              </div>
              <div>
                <p className="text-sm text-[#5E6B6B] mb-1">Saldo de Saque Atual</p>
                <p className="text-base font-medium text-[#1E1E1E]">
                  R$ {(editingUser.withdrawal_balance || 0).toFixed(2)}
                </p>
              </div>
              <div>
                <label className="text-sm text-[#5E6B6B] mb-1 block">Novo Saldo de Saque</label>
                <input
                  type="number"
                  step="0.01"
                  value={editWithdrawalBalance}
                  onChange={(e) => setEditWithdrawalBalance(e.target.value)}
                  className="w-full px-4 py-2 rounded-xl border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C]"
                  placeholder="0.00"
                />
              </div>
              <div className="flex gap-3">
                <Button
                  onClick={() => {
                    setEditingUser(null)
                    setEditName("")
                    setEditBalance("")
                    setEditWithdrawalBalance("")
                  }}
                  className="flex-1 bg-gray-200 text-gray-800 hover:bg-gray-300"
                >
                  Cancelar
                </Button>
                <Button onClick={handleUpdateBalance} className="flex-1 bg-[#0A3C3C] text-white hover:bg-[#0C5050]">
                  Salvar
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}
