# Integração SafiraCash - Configuração Correta

## ✅ Configuração Necessária

Você precisa configurar APENAS uma variável de ambiente:

### PIX_API_KEY (OBRIGATÓRIA)
- **Valor**: Sua chave secreta da SafiraCash (começa com `sk_`)
- **Onde configurar**: Seção "Vars" na barra lateral do v0
- **Exemplo**: `sk_e4e5831240f17ecdff1fe570b5c9bcf9e463195be310b23f17a6c8371ade25c2`

## 🔗 Endpoint da API

O sistema usa automaticamente o endpoint correto da documentação SafiraCash:
\`\`\`
https://api.safira.cash/api/pagamentos/depósito
\`\`\`

**IMPORTANTE**: Você NÃO precisa configurar `PIX_API_ENDPOINT`. Se essa variável existir, remova-a!

## 📋 Estrutura da Requisição

Baseado na documentação oficial da SafiraCash:

**Headers:**
- `x-api-chave`: Sua chave secreta (PIX_API_KEY)
- `Content-Type`: application/json

**Body (JSON):**
\`\`\`json
{
  "quantia": 10,
  "método_depagamento": "PIX",
  "dados_do_Cliente": {
    "nome": "João Silva",
    "e-mail": "joao@email.com",
    "documento": "12345678901",
    "telefone": "+5511999999999"
  },
  "metadados": {
    "ordenarId": "ORDER_123",
    "descrição": "Teste de depósito via Carteiro"
  }
}
\`\`\`

## 🔔 Webhook para Receber Notificações

Quando um pagamento PIX for confirmado, a SafiraCash enviará uma notificação para:
\`\`\`
https://investimentoaltoo.vercel.app/api/safiracash/webhook
\`\`\`

**Configure esta URL no painel da SafiraCash** para receber notificações automáticas de pagamentos confirmados.

## ⚠️ Diferença entre Endpoint e Webhook

### Endpoint da API
- **URL**: `https://api.safira.cash/api/pagamentos/depósito`
- **Direção**: Você CHAMA este endpoint para CRIAR um pagamento PIX
- **Quando**: Usuário clica em "Depositar"
- **Configuração**: Não precisa configurar, já está no código
  
### Webhook
- **URL**: `https://investimentoaltoo.vercel.app/api/safiracash/webhook`
- **Direção**: A SafiraCash CHAMA este endpoint para NOTIFICAR que um pagamento foi confirmado
- **Quando**: Usuário paga o PIX
- **Configuração**: Configure no painel da SafiraCash

## 🔄 Fluxo Completo

\`\`\`
1. Usuário clica "Depositar R$ 50"
   ↓
2. Seu app chama SafiraCash API
   POST https://api.safira.cash/api/pagamentos/depósito
   Headers: x-api-chave: {PIX_API_KEY}
   ↓
3. SafiraCash retorna QR Code PIX
   ↓
4. Usuário escaneia e paga
   ↓
5. SafiraCash chama seu webhook
   POST https://investimentoaltoo.vercel.app/api/safiracash/webhook
   ↓
6. Saldo atualizado automaticamente
\`\`\`

## 🐛 Troubleshooting

### ❌ Erro 401/403 - Não autorizado
**Causa**: PIX_API_KEY incorreta  
**Solução**:
- Verifique se a chave começa com `sk_`
- Copie novamente do painel da SafiraCash
- Use a SECRET KEY, não a PUBLIC KEY

### ❌ Erro 404 - Endpoint não encontrado
**Causa**: O endpoint da SafiraCash pode estar diferente  
**Solução**:
- O sistema já usa o endpoint da documentação oficial
- Se persistir, entre em contato com o suporte da SafiraCash
- Confirme que sua conta SafiraCash está ativa

### ❌ Erro 500 - Erro interno
**Causa**: Problema na comunicação com a API  
**Solução**:
- Verifique os logs do console (F12 no navegador)
- Confirme que todos os dados do cliente estão corretos
- Verifique se a API da SafiraCash está online

### ❌ Pagamento não atualiza automaticamente
**Causa**: Webhook não configurado no painel da SafiraCash  
**Solução**:
1. Acesse o painel da SafiraCash
2. Vá em Configurações → Webhooks
3. Adicione: `https://investimentoaltoo.vercel.app/api/safiracash/webhook`
4. Selecione eventos de pagamento confirmado

## 📝 Checklist de Configuração

### Passo 1: Configurar no v0
- [ ] Abra a seção **Vars** na barra lateral
- [ ] Adicione `PIX_API_KEY` com sua secret key da SafiraCash
- [ ] **NÃO** adicione `PIX_API_ENDPOINT` (já está no código)

### Passo 2: Configurar no Painel SafiraCash
- [ ] Acesse o painel da SafiraCash
- [ ] Configure o webhook: `https://investimentoaltoo.vercel.app/api/safiracash/webhook`
- [ ] Ative notificações de pagamento confirmado

### Passo 3: Testar
- [ ] Faça um depósito de teste
- [ ] Verifique se o QR Code é gerado
- [ ] Pague o PIX e veja se o saldo atualiza

## 🆘 Suporte

Se os problemas persistirem após seguir este guia:
1. Verifique os logs do console (F12 no navegador) para detalhes do erro
2. Entre em contato com o suporte da SafiraCash
3. Confirme que sua conta SafiraCash está ativa e configurada corretamente
4. Verifique se você está usando a chave de API correta (SECRET KEY)
