# Configuração da API PIX

## Variáveis de Ambiente Necessárias

Para integrar com a API PIX, você precisa configurar as seguintes variáveis de ambiente no seu projeto Vercel:

### PIX_API_KEY (OBRIGATÓRIO)
**Esta deve ser a SECRET KEY (chave secreta) do seu provedor PIX, NÃO a chave pública.**

A SECRET KEY é usada para:
- Criar cobranças PIX
- Processar pagamentos
- Acessar dados sensíveis

⚠️ **IMPORTANTE**: Nunca exponha a SECRET KEY no código cliente ou em repositórios públicos.

### PIX_API_URL (OPCIONAL)
URL base da API do seu provedor PIX.

Exemplos de provedores:
- Mercado Pago: `https://api.mercadopago.com/v1/payments`
- Asaas: `https://www.asaas.com/api/v3/payments`
- PagSeguro: `https://api.pagseguro.com/charges`
- Outro provedor: Consulte a documentação do seu provedor

Se não configurada, usa: `https://api.seuprovedor.com/v1/payments`

## Como Adicionar as Variáveis

1. Acesse o painel do Vercel
2. Vá em Settings > Environment Variables
3. Adicione:
   - `PIX_API_KEY` = Sua SECRET KEY do provedor PIX
   - `PIX_API_URL` = URL da API do seu provedor (opcional)

## Diferença entre SECRET KEY e PUBLIC KEY

### SECRET KEY (Use esta!)
- Usada no servidor (backend)
- Permite criar cobranças e processar pagamentos
- Deve ser mantida em segredo
- **Esta é a chave que você deve usar em PIX_API_KEY**

### PUBLIC KEY (NÃO use para depósitos)
- Usada no cliente (frontend)
- Apenas para operações públicas
- Não permite criar cobranças
- Não é necessária para este sistema

## Formato da Requisição

A API envia os dados no seguinte formato:

\`\`\`json
{
  "quantia": 100,
  "metodoDePagamento": "PIX",
  "dadosDoCliente": {
    "nome": "João Silva",
    "email": "joao@email.com",
    "documento": "12345678901",
    "telefone": "+5511999999999"
  },
  "metadados": {
    "ordenarId": "ORDER_123",
    "descrição": "Depósito via PIX"
  }
}
\`\`\`

## Resposta Esperada

A API deve retornar:

\`\`\`json
{
  "transactionId": "txn_123456",
  "pixKey": "chave@pix.com",
  "pixCode": "00020126580014br.gov.bcb.pix...",
  "qrCode": "00020126580014br.gov.bcb.pix...",
  "status": "pending"
}
\`\`\`

## Testando

Sem as variáveis configuradas, o sistema funciona em modo de simulação para testes.
\`\`\`
