"use client"

import { useEffect, useState } from "react"
import { createBrowserClient } from "@supabase/ssr"
import { setCurrentUserAsAdmin } from "@/app/actions/set-admin"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function DebugProfilePage() {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [settingAdmin, setSettingAdmin] = useState(false)
  const [adminResult, setAdminResult] = useState<any>(null)

  async function loadData() {
    const supabase = createBrowserClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    )

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      setData({ error: "Usuário não está logado" })
      setLoading(false)
      return
    }

    // Get profile
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single()

    setData({
      user: {
        id: user.id,
        email: user.email,
        created_at: user.created_at,
      },
      profile: profile,
      profileError: profileError,
      isAdmin: profile?.role === "admin",
    })
    setLoading(false)
  }

  useEffect(() => {
    loadData()
  }, [])

  async function handleSetAdmin() {
    setSettingAdmin(true)
    setAdminResult(null)

    const result = await setCurrentUserAsAdmin()
    setAdminResult(result)
    setSettingAdmin(false)

    if (result.success) {
      // Reload data to show updated status
      setTimeout(() => {
        loadData()
      }, 1000)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando...</p>
      </div>
    )
  }

  if (data?.error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="bg-white rounded-lg shadow-lg p-8 max-w-md">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Erro</h1>
          <p className="text-gray-700 mb-6">{data.error}</p>
          <Link href="/auth/login">
            <Button className="w-full">Fazer Login</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Debug - Informações do Perfil</h1>

        <div className="bg-white rounded-lg shadow p-6 mb-4">
          <h2 className="text-xl font-semibold mb-4">Status Admin</h2>
          <div className={`text-2xl font-bold mb-4 ${data?.isAdmin ? "text-green-600" : "text-red-600"}`}>
            {data?.isAdmin ? "✓ VOCÊ É ADMIN" : "✗ VOCÊ NÃO É ADMIN"}
          </div>

          {!data?.isAdmin && (
            <Button onClick={handleSetAdmin} disabled={settingAdmin} className="w-full" size="lg">
              {settingAdmin ? "Configurando..." : "🔧 Tornar-me Admin Agora"}
            </Button>
          )}

          {adminResult && (
            <div
              className={`mt-4 p-4 rounded ${adminResult.success ? "bg-green-50 text-green-800" : "bg-red-50 text-red-800"}`}
            >
              <p className="font-semibold">{adminResult.success ? "✓ Sucesso!" : "✗ Erro"}</p>
              <p>{adminResult.message || adminResult.error}</p>
              {adminResult.success && (
                <p className="mt-2 text-sm">
                  Faça logout e login novamente, depois acesse <strong>/admin</strong>
                </p>
              )}
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg shadow p-6 mb-4">
          <h2 className="text-xl font-semibold mb-4">Dados do Usuário (Auth)</h2>
          <pre className="bg-gray-100 p-4 rounded overflow-auto">{JSON.stringify(data?.user, null, 2)}</pre>
        </div>

        <div className="bg-white rounded-lg shadow p-6 mb-4">
          <h2 className="text-xl font-semibold mb-4">Dados do Perfil (Profiles Table)</h2>
          <pre className="bg-gray-100 p-4 rounded overflow-auto">{JSON.stringify(data?.profile, null, 2)}</pre>
        </div>

        {data?.profileError && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-4">
            <h2 className="text-xl font-semibold text-red-800 mb-4">Erro ao buscar perfil</h2>
            <pre className="bg-red-100 p-4 rounded overflow-auto text-red-900">
              {JSON.stringify(data?.profileError, null, 2)}
            </pre>
          </div>
        )}

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h2 className="text-xl font-semibold text-blue-800 mb-4">Instruções Alternativas (Manual)</h2>
          <ol className="list-decimal list-inside space-y-2 text-blue-900">
            <li>
              Copie o <strong>ID</strong> mostrado acima
            </li>
            <li>Vá no Supabase SQL Editor</li>
            <li>
              Execute:{" "}
              <code className="bg-blue-100 px-2 py-1 rounded">
                UPDATE profiles SET role = 'admin' WHERE id = 'SEU-ID-AQUI';
              </code>
            </li>
            <li>Faça logout e login novamente</li>
            <li>Volte nesta página para verificar</li>
          </ol>
        </div>
      </div>
    </div>
  )
}
