import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import bcrypt from "bcryptjs"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    if (!supabase) {
      return NextResponse.json({ error: "Supabase não configurado" }, { status: 500 })
    }

    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Não autenticado" }, { status: 401 })
    }

    const body = await request.json()
    const { password } = body

    if (!password || password.length < 4) {
      return NextResponse.json({ error: "Senha deve ter no mínimo 4 caracteres" }, { status: 400 })
    }

    if (!/^\d+$/.test(password)) {
      return NextResponse.json({ error: "Senha deve conter apenas números" }, { status: 400 })
    }

    const hashedPassword = await bcrypt.hash(password, 10)

    const { error } = await supabase.from("profiles").update({ withdrawal_password: hashedPassword }).eq("id", user.id)

    if (error) throw error

    return NextResponse.json({
      success: true,
      message: "Senha de saque configurada com sucesso",
    })
  } catch (error: any) {
    console.error("[v0] Error setting withdrawal password:", error)
    return NextResponse.json({ error: error.message || "Erro ao configurar senha de saque" }, { status: 500 })
  }
}
