import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase/server"
import bcrypt from "bcryptjs"

export async function POST(request: NextRequest) {
  try {
    const { password } = await request.json()

    if (!password || password.length !== 4) {
      return NextResponse.json({ error: "Senha inválida" }, { status: 400 })
    }

    const supabase = await createServerClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Não autenticado" }, { status: 401 })
    }

    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("withdrawal_password")
      .eq("id", user.id)
      .single()

    if (profileError || !profile) {
      return NextResponse.json({ error: "Perfil não encontrado" }, { status: 404 })
    }

    if (!profile.withdrawal_password) {
      return NextResponse.json({ error: "Senha de saque não configurada" }, { status: 400 })
    }

    const isValid = await bcrypt.compare(password, profile.withdrawal_password)

    if (!isValid) {
      return NextResponse.json({ error: "Senha incorreta" }, { status: 401 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("[v0] Erro ao verificar senha de saque:", error)
    return NextResponse.json({ error: "Erro ao verificar senha" }, { status: 500 })
  }
}
