import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import bcrypt from "bcryptjs"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    if (!supabase) {
      return NextResponse.json({ error: "Supabase não configurado" }, { status: 500 })
    }

    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Não autenticado" }, { status: 401 })
    }

    const body = await request.json()
    const { amount, pixKey, pixKeyType, withdrawalPassword } = body

    const { data: userData } = await supabase
      .from("profiles")
      .select("withdrawal_balance, withdrawal_password")
      .eq("id", user.id)
      .single()

    if (!userData) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    if (!userData.withdrawal_password) {
      return NextResponse.json({ error: "Senha de saque não configurada" }, { status: 400 })
    }

    const passwordMatch = await bcrypt.compare(withdrawalPassword, userData.withdrawal_password)
    if (!passwordMatch) {
      return NextResponse.json({ error: "Senha de saque incorreta" }, { status: 401 })
    }

    if (userData.withdrawal_balance < amount) {
      return NextResponse.json({ error: "Saldo de rendimentos insuficiente" }, { status: 400 })
    }

    const fee = amount * 0.025
    const netAmount = amount - fee

    const { data: withdrawal, error: withdrawalError } = await supabase
      .from("withdrawals")
      .insert({
        user_id: user.id,
        amount,
        amount_net: netAmount,
        amount_fee: fee,
        pix_key: pixKey,
        pix_key_type: pixKeyType,
        status: "pending",
      })
      .select()
      .single()

    if (withdrawalError) throw withdrawalError

    const newWithdrawalBalance = userData.withdrawal_balance - amount
    await supabase.from("profiles").update({ withdrawal_balance: newWithdrawalBalance }).eq("id", user.id)

    await supabase.from("transactions").insert({
      user_id: user.id,
      type: "withdrawal",
      amount: amount,
      status: "pending",
      method: "pix",
      description: `Saque via PIX - ${pixKeyType}: ${pixKey}`,
      reference_id: withdrawal.id,
    })

    return NextResponse.json({
      success: true,
      withdrawal,
      newWithdrawalBalance,
    })
  } catch (error: any) {
    console.error("[v0] Error creating withdrawal:", error)
    return NextResponse.json({ error: error.message || "Erro ao criar saque" }, { status: 500 })
  }
}
