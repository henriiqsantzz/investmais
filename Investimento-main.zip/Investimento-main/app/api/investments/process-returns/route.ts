import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    if (!supabase) {
      return NextResponse.json({ error: "Supabase não configurado" }, { status: 500 })
    }

    // Get all active investments
    const { data: investments, error: investmentsError } = await supabase
      .from("investments")
      .select("*")
      .eq("status", "active")

    if (investmentsError) throw investmentsError

    if (!investments || investments.length === 0) {
      return NextResponse.json({ message: "Nenhum investimento ativo encontrado", processed: 0 })
    }

    let processedCount = 0
    const now = new Date()

    for (const investment of investments) {
      const createdAt = new Date(investment.created_at)
      const daysSinceCreation = Math.floor((now.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24))

      // Check if investment period has ended
      if (daysSinceCreation >= investment.total_days) {
        // Mark investment as completed
        await supabase
          .from("investments")
          .update({
            status: "completed",
            completed_at: now.toISOString(),
          })
          .eq("id", investment.id)

        // Add final return to withdrawal balance
        const { data: userData } = await supabase
          .from("profiles")
          .select("withdrawal_balance")
          .eq("id", investment.user_id)
          .single()

        if (userData) {
          const newWithdrawalBalance = (userData.withdrawal_balance || 0) + investment.daily_return

          await supabase
            .from("profiles")
            .update({ withdrawal_balance: newWithdrawalBalance })
            .eq("id", investment.user_id)

          // Create transaction record for the return
          await supabase.from("transactions").insert({
            user_id: investment.user_id,
            type: "return",
            amount: investment.daily_return,
            status: "completed",
            method: "investment_return",
            description: `Retorno diário do investimento em ${investment.product_name} (Dia ${daysSinceCreation}/${investment.total_days})`,
            reference_id: investment.id,
          })

          processedCount++
        }
      } else if (daysSinceCreation > 0) {
        // Process daily return for active investments
        const { data: userData } = await supabase
          .from("profiles")
          .select("withdrawal_balance")
          .eq("id", investment.user_id)
          .single()

        if (userData) {
          const newWithdrawalBalance = (userData.withdrawal_balance || 0) + investment.daily_return

          await supabase
            .from("profiles")
            .update({ withdrawal_balance: newWithdrawalBalance })
            .eq("id", investment.user_id)

          // Create transaction record for the return
          await supabase.from("transactions").insert({
            user_id: investment.user_id,
            type: "return",
            amount: investment.daily_return,
            status: "completed",
            method: "investment_return",
            description: `Retorno diário do investimento em ${investment.product_name} (Dia ${daysSinceCreation}/${investment.total_days})`,
            reference_id: investment.id,
          })

          processedCount++
        }
      }
    }

    return NextResponse.json({
      success: true,
      message: `Processados ${processedCount} retornos de investimento`,
      processed: processedCount,
      total: investments.length,
    })
  } catch (error: any) {
    console.error("[v0] Error processing returns:", error)
    return NextResponse.json({ error: error.message || "Erro ao processar retornos" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  return POST(request)
}
