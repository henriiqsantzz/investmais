import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    if (!supabase) {
      return NextResponse.json({ error: "Supabase não configurado" }, { status: 500 })
    }

    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Não autenticado" }, { status: 401 })
    }

    const body = await request.json()
    const { amount, productName, productType, totalDays } = body

    console.log("[v0] Dados do investimento:", { amount, productName, productType, totalDays, userId: user.id })

    const investmentAmount = Number(amount)
    if (!investmentAmount || investmentAmount <= 0 || isNaN(investmentAmount)) {
      return NextResponse.json({ error: "Valor de investimento inválido" }, { status: 400 })
    }

    const { data: userData, error: userError } = await supabase
      .from("profiles")
      .select("balance")
      .eq("id", user.id)
      .single()

    console.log("[v0] Dados do usuário na API:", userData)
    console.log("[v0] Erro ao buscar usuário:", userError)

    if (userError) {
      console.error("[v0] Erro ao buscar perfil do usuário:", userError)
      return NextResponse.json({ error: "Erro ao buscar dados do usuário" }, { status: 500 })
    }

    if (!userData) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    const currentBalance = Number(userData.balance) || 0
    console.log("[v0] Verificação de saldo:", {
      currentBalance,
      investmentAmount,
      hasEnough: currentBalance >= investmentAmount,
      balanceType: typeof currentBalance,
      amountType: typeof investmentAmount,
    })

    if (currentBalance < investmentAmount) {
      console.log("[v0] Saldo insuficiente na API")
      return NextResponse.json(
        {
          error: "Saldo insuficiente",
          details: {
            currentBalance,
            required: investmentAmount,
            missing: investmentAmount - currentBalance,
          },
        },
        { status: 400 },
      )
    }

    const dailyReturn = investmentAmount * 0.02 // 2% daily return
    const totalExpectedReturn = dailyReturn * totalDays

    const { data: investment, error: investmentError } = await supabase
      .from("investments")
      .insert({
        user_id: user.id,
        investment_amount: investmentAmount,
        product_name: productName,
        product_type: productType,
        total_days: totalDays,
        daily_return: dailyReturn,
        total_expected_return: totalExpectedReturn,
        status: "active",
        payment_method: "balance",
      })
      .select()
      .single()

    if (investmentError) {
      console.error("[v0] Erro ao criar investimento:", investmentError)
      throw investmentError
    }

    console.log("[v0] Investimento criado:", investment)

    const newBalance = currentBalance - investmentAmount
    console.log("[v0] Atualizando saldo:", { currentBalance, investmentAmount, newBalance })

    const { error: updateError } = await supabase.from("profiles").update({ balance: newBalance }).eq("id", user.id)

    if (updateError) {
      console.error("[v0] Erro ao atualizar saldo:", updateError)
      await supabase.from("investments").delete().eq("id", investment.id)
      throw new Error("Erro ao atualizar saldo. Investimento cancelado.")
    }

    await supabase.from("transactions").insert({
      user_id: user.id,
      type: "investment",
      amount: -investmentAmount,
      status: "completed",
      method: "balance",
      description: `Investimento em ${productName}`,
      reference_id: investment.id,
    })

    console.log("[v0] Investimento concluído com sucesso")

    return NextResponse.json({
      success: true,
      investment,
      newBalance,
    })
  } catch (error: any) {
    console.error("[v0] Error creating investment:", error)
    return NextResponse.json({ error: error.message || "Erro ao criar investimento" }, { status: 500 })
  }
}
