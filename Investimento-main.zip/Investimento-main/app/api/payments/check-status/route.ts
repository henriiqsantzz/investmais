import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const transactionId = searchParams.get("transactionId")

    if (!transactionId) {
      return NextResponse.json(
        { success: false, message: "ID da transação não fornecido" },
        { status: 400 },
      )
    }

    const supabase = await createClient()

    console.log("[v0] 🔍 Buscando depósito com transactionId:", transactionId)

    // 🔹 Busca depósito pelo transaction_id ou external_transaction_id
    const { data: deposits, error: depositError } = await supabase
      .from("deposits")
      .select("*")
      .or(`transaction_id.eq.${transactionId},external_transaction_id.eq.${transactionId}`)
      .limit(1)

    if (depositError) {
      console.error("[v0] ❌ Erro ao buscar depósito:", depositError)
      return NextResponse.json(
        { success: false, message: "Erro ao buscar depósito" },
        { status: 500 },
      )
    }

    if (!deposits || deposits.length === 0) {
      console.warn("[v0] ⚠️ Depósito não encontrado para ID:", transactionId)
      return NextResponse.json(
        { success: false, message: "Depósito não encontrado" },
        { status: 404 },
      )
    }

    const deposit = deposits[0]
    console.log("[v0] 💰 Depósito encontrado:", deposit.id, "Status:", deposit.status)

    // 🔹 Se o depósito estiver concluído, busca o saldo atualizado
    let updatedBalance = null
    if (deposit.status === "completed") {
      const { data: profile } = await supabase
        .from("profiles")
        .select("balance")
        .eq("id", deposit.user_id)
        .single()

      if (profile) {
        updatedBalance = profile.balance
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        transactionId:
          deposit.external_transaction_id || deposit.transaction_id,
        status: deposit.status,
        amount: deposit.amount,
        createdAt: deposit.created_at,
        expiresAt: deposit.expires_at,
        updatedBalance,
      },
    })
  } catch (error) {
    console.error("[v0] ❌ Erro ao buscar status:", error)
    return NextResponse.json(
      { success: false, message: "Erro ao buscar status" },
      { status: 500 },
    )
  }
}
