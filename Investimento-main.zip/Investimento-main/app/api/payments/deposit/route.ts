import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    console.log("🟢 [SafiraCash] Requisição recebida:")
    console.log(JSON.stringify(body, null, 2))

    const { quantia, metodoDePagamento, dadosDoCliente } = body

    if (!quantia || quantia < 5 || quantia > 50000) {
      console.log("🚫 Valor inválido:", quantia)
      return NextResponse.json(
        { success: false, message: "Valor inválido. Mínimo: R$5, Máximo: R$50.000" },
        { status: 400 },
      )
    }

    if (metodoDePagamento !== "PIX") {
      console.log("🚫 Método não suportado:", metodoDePagamento)
      return NextResponse.json(
        { success: false, message: "Método de pagamento não suportado" },
        { status: 400 },
      )
    }

    if (!dadosDoCliente?.nome || !dadosDoCliente?.email || !dadosDoCliente?.documento) {
      console.log("🚫 Dados do cliente incompletos:", dadosDoCliente)
      return NextResponse.json(
        { success: false, message: "Dados do cliente incompletos" },
        { status: 400 },
      )
    }

    const safiraApiKey = "sk_c6e57cfca184b61dbf09a628831e6103ab06a7bdfc4fe0eeb6f8f835cc60ed1f"
    const safiraEndpoint = "https://api.safira.cash/api/payments/deposit"

    // Corrigido conforme documentação: usar customerData em vez de payer
    const requestBody = {
      amount: quantia,
      paymentMethod: "PIX",
      customerData: {
        name: dadosDoCliente.nome,
        email: dadosDoCliente.email,
        document: dadosDoCliente.documento,
        phone: dadosDoCliente.telefone || "+5511999999999",
      },
      metadata: {
        orderId: `ORDER_${Date.now()}`,
        description: `Depósito via PIX - R$ ${quantia.toFixed(2)}`,
      },
      callbackUrl: "https://investimentoaltoo.vercel.app/api/safiracash/webhook",
    }

    console.log("📤 Enviando requisição para SafiraCash:", JSON.stringify(requestBody, null, 2))

    const response = await fetch(safiraEndpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": safiraApiKey,
      },
      body: JSON.stringify(requestBody),
    })

    const responseText = await response.text()
    console.log("🔍 Resposta SafiraCash (RAW):", responseText)

    if (!response.ok) {
      console.error("❌ Erro HTTP SafiraCash:", response.status)
      return NextResponse.json(
        { success: false, message: "Erro ao gerar PIX SafiraCash", responseText },
        { status: 400 },
      )
    }

    const pixData = JSON.parse(responseText)
    console.log("🧩 Parsed SafiraCash response:", JSON.stringify(pixData, null, 2))

    // Extrai pixCode de TODOS os formatos possíveis
    const pixCode =
      pixData?.data?.pixQrCode ||
      pixData?.data?.qrCode ||
      pixData?.pixQrCode ||
      pixData?.qrCode ||
      pixData?.data?.pixCode ||
      pixData?.pixCode ||
      ""

    console.log("🔍 [DEPOSIT] Extração de pixCode:")
    console.log("   - pixData?.data?.pixQrCode:", pixData?.data?.pixQrCode ? pixData.data.pixQrCode.substring(0, 50) + "..." : "NULL")
    console.log("   - pixData?.data?.qrCode:", pixData?.data?.qrCode ? pixData.data.qrCode.substring(0, 50) + "..." : "NULL")
    console.log("   - pixData?.pixQrCode:", pixData?.pixQrCode ? pixData.pixQrCode.substring(0, 50) + "..." : "NULL")
    console.log("   - pixData?.qrCode:", pixData?.qrCode ? pixData.qrCode.substring(0, 50) + "..." : "NULL")
    console.log("   - pixCode FINAL:", pixCode ? pixCode.substring(0, 50) + "..." : "NULL")

    // 🧠 Testa os dois formatos possíveis
    const transactionId =
      pixData?.data?.transactionId ||
      pixData?.transactionId ||
      pixData?.externalTransactionId ||
      pixData?.data?.externalTransactionId ||
      null

    const externalTransactionId =
      pixData?.data?.externalTransactionId ||
      pixData?.externalTransactionId ||
      null

    const extractedData = {
      transactionId,
      externalTransactionId,
      pixKey: pixData?.data?.pixKey || pixData?.pixKey || "",
      pixCode,
      amount: quantia,
      status: pixData?.data?.status || pixData?.status || "pending",
      expiresAt: pixData?.data?.expiresAt || new Date(Date.now() + 30 * 60 * 1000).toISOString(),
    }

    console.log("📦 [DEPOSIT] Dados extraídos:", extractedData)
    console.log("📦 [DEPOSIT] transactionId:", extractedData.transactionId || "NULL")
    console.log("📦 [DEPOSIT] externalTransactionId:", extractedData.externalTransactionId || "NULL")
    console.log("📦 [DEPOSIT] pixCode:", extractedData.pixCode ? extractedData.pixCode.substring(0, 50) + "..." : "NULL")

    // Permite criar depósito mesmo sem transactionId, desde que tenha pixCode
    // O transactionId será atualizado quando o webhook chegar
    const hasTransactionId = extractedData.transactionId && String(extractedData.transactionId).trim() !== ""
    const hasExternalTransactionId = extractedData.externalTransactionId && String(extractedData.externalTransactionId).trim() !== ""
    const hasPixCode = extractedData.pixCode && String(extractedData.pixCode).trim() !== ""

    if (!hasTransactionId && !hasExternalTransactionId && !hasPixCode) {
      console.log("⚠️ [DEPOSIT] Nenhum transactionId nem pixCode retornado — NÃO VAI SALVAR no Supabase.")
      return NextResponse.json({
        success: true,
        message: "PIX gerado sem dados suficientes — aguardando callback SafiraCash.",
        data: extractedData,
      })
    }

    if (!hasTransactionId && !hasExternalTransactionId) {
      console.log("⚠️ [DEPOSIT] Nenhum transactionId retornado, mas tem pixCode — criando depósito sem ID.")
      console.log("⚠️ [DEPOSIT] O transactionId será atualizado quando o webhook chegar.")
    } else {
      console.log("✅ [DEPOSIT] Transaction ID válido detectado, salvando...")
    }

    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      console.log("⚠️ Usuário não autenticado — não será salvo.")
      return NextResponse.json(
        { success: false, message: "Usuário não autenticado" },
        { status: 401 },
      )
    }

    // Evita duplicar - verifica por transaction_id, external_transaction_id OU pix_qr_code/pix_copy_paste
    const duplicateConditions = []
    if (extractedData.transactionId) {
      duplicateConditions.push(`transaction_id.eq.${extractedData.transactionId}`)
    }
    if (extractedData.externalTransactionId) {
      duplicateConditions.push(`external_transaction_id.eq.${extractedData.externalTransactionId}`)
    }
    if (extractedData.pixCode) {
      duplicateConditions.push(`pix_qr_code.eq.${extractedData.pixCode}`)
      duplicateConditions.push(`pix_copy_paste.eq.${extractedData.pixCode}`)
    }

    let existingDeposit = null
    if (duplicateConditions.length > 0) {
      const { data: existing } = await supabase
        .from("deposits")
        .select("id, transaction_id, external_transaction_id, pix_qr_code, pix_copy_paste")
        .or(duplicateConditions.join(","))
        .eq("user_id", user.id)
        .eq("status", "pending")
        .maybeSingle()

      if (existing) {
        console.log("⚠️ [DEPOSIT] Depósito duplicado detectado:", existing.id)
        console.log("⚠️ [DEPOSIT] Depósito existente tem:")
        console.log("   - transaction_id:", existing.transaction_id || "NULL")
        console.log("   - external_transaction_id:", existing.external_transaction_id || "NULL")
        console.log("   - pix_qr_code:", existing.pix_qr_code ? existing.pix_qr_code.substring(0, 50) + "..." : "NULL")
        
        // Se o depósito existente não tem transaction_id mas temos agora, atualiza
        if (extractedData.transactionId && !existing.transaction_id) {
          console.log("📝 [DEPOSIT] Atualizando transaction_id do depósito existente...")
          await supabase
            .from("deposits")
            .update({
              transaction_id: extractedData.transactionId,
              external_transaction_id: extractedData.externalTransactionId || existing.external_transaction_id,
              updated_at: new Date().toISOString()
            })
            .eq("id", existing.id)
        }
        
        return NextResponse.json({
          success: true,
          message: "Depósito já existente.",
          data: extractedData,
        })
      }
    }

    // Garante que pixCode não seja vazio antes de salvar
    const finalPixCode = extractedData.pixCode && String(extractedData.pixCode).trim() !== "" 
      ? String(extractedData.pixCode).trim() 
      : null
    
    console.log("🔍 [DEPOSIT] Validação final de pixCode:")
    console.log("   - extractedData.pixCode:", extractedData.pixCode ? extractedData.pixCode.substring(0, 50) + "..." : "NULL")
    console.log("   - finalPixCode:", finalPixCode ? finalPixCode.substring(0, 50) + "..." : "NULL")
    
    if (!finalPixCode) {
      console.error("❌ [DEPOSIT] ERRO CRÍTICO: pixCode está vazio! Não será possível salvar.")
      console.error("❌ [DEPOSIT] Resposta completa da SafiraCash:", JSON.stringify(pixData, null, 2))
    }

    const depositData: any = {
      user_id: user.id,
      amount: quantia,
      payment_method: metodoDePagamento,
      status: "pending",
      pix_key: extractedData.pixKey && String(extractedData.pixKey).trim() !== "" ? String(extractedData.pixKey).trim() : null,
      pix_qr_code: finalPixCode,
      pix_copy_paste: finalPixCode, // Salva também em pix_copy_paste
      expires_at: extractedData.expiresAt,
    }

    // Só adiciona transaction_id se existir
    if (extractedData.transactionId) {
      depositData.transaction_id = extractedData.transactionId
    }
    if (extractedData.externalTransactionId) {
      depositData.external_transaction_id = extractedData.externalTransactionId
    }

    console.log("💾 [DEPOSIT] Inserindo depósito com dados:")
    console.log("   - user_id:", depositData.user_id)
    console.log("   - amount:", depositData.amount)
    console.log("   - transaction_id:", depositData.transaction_id || "NULL")
    console.log("   - external_transaction_id:", depositData.external_transaction_id || "NULL")
    console.log("   - pix_key:", depositData.pix_key ? depositData.pix_key.substring(0, 50) + "..." : "NULL")
    console.log("   - pix_qr_code:", depositData.pix_qr_code ? depositData.pix_qr_code.substring(0, 50) + "..." : "NULL")
    console.log("   - pix_copy_paste:", depositData.pix_copy_paste ? depositData.pix_copy_paste.substring(0, 50) + "..." : "NULL")
    console.log("   - pixCode original (extractedData.pixCode):", extractedData.pixCode ? extractedData.pixCode.substring(0, 50) + "..." : "NULL")

    const { data: insertedDeposit, error: depositError } = await supabase
      .from("deposits")
      .insert(depositData)
      .select()
      .single()

    if (depositError) {
      console.error("❌ [DEPOSIT] Erro ao salvar depósito:", depositError)
      console.error("❌ [DEPOSIT] Dados que tentou salvar:", JSON.stringify(depositData, null, 2))
      return NextResponse.json(
        { success: false, message: "Erro ao salvar depósito", depositError },
        { status: 500 },
      )
    }

    console.log("\n✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅")
    console.log("✅ [DEPOSIT] ========== DEPÓSITO SALVO COM SUCESSO! ==========")
    console.log("✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅\n")
    
    console.log("📋 [DEPOSIT] ID do depósito criado:", insertedDeposit?.id)
    console.log("📋 [DEPOSIT] Verificando dados salvos no banco:")
    console.log("   - transaction_id salvo:", insertedDeposit?.transaction_id || "❌ NULL")
    console.log("   - external_transaction_id salvo:", insertedDeposit?.external_transaction_id || "❌ NULL")
    console.log("   - pix_qr_code salvo:", insertedDeposit?.pix_qr_code ? "✅ SIM (" + insertedDeposit.pix_qr_code.substring(0, 50) + "...)" : "❌ NULL")
    console.log("   - pix_copy_paste salvo:", insertedDeposit?.pix_copy_paste ? "✅ SIM (" + insertedDeposit.pix_copy_paste.substring(0, 50) + "...)" : "❌ NULL")
    console.log("   - pix_key salvo:", insertedDeposit?.pix_key ? "✅ SIM (" + insertedDeposit.pix_key + ")" : "❌ NULL")
    console.log("   - status salvo:", insertedDeposit?.status || "NULL")
    console.log("   - amount salvo:", insertedDeposit?.amount || "NULL")
    console.log("   - user_id salvo:", insertedDeposit?.user_id || "NULL")
    console.log("   - created_at salvo:", insertedDeposit?.created_at || "NULL")
    
    // Verifica se os dados foram salvos corretamente
    if (!insertedDeposit?.pix_qr_code && !insertedDeposit?.pix_copy_paste) {
      console.error("\n❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌")
      console.error("❌ [DEPOSIT] ERRO CRÍTICO: pix_qr_code E pix_copy_paste estão NULL!")
      console.error("❌ [DEPOSIT] extractedData.pixCode original:", extractedData.pixCode ? extractedData.pixCode.substring(0, 50) + "..." : "NULL")
      console.error("❌ [DEPOSIT] finalPixCode usado:", finalPixCode ? finalPixCode.substring(0, 50) + "..." : "NULL")
      console.error("❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌\n")
    }
    
    // Se não salvou pix_copy_paste mas tem pix_qr_code, atualiza manualmente
    if (!insertedDeposit?.pix_copy_paste && insertedDeposit?.pix_qr_code) {
      console.log("\n⚠️ [DEPOSIT] pix_copy_paste está NULL mas pix_qr_code tem valor. Atualizando...")
      const { error: updateError } = await supabase
        .from("deposits")
        .update({ pix_copy_paste: insertedDeposit.pix_qr_code })
        .eq("id", insertedDeposit.id)
      
      if (updateError) {
        console.error("❌ [DEPOSIT] Erro ao atualizar pix_copy_paste:", updateError)
      } else {
        console.log("✅ [DEPOSIT] pix_copy_paste atualizado com sucesso!")
      }
    }
    
    // Busca o depósito novamente para confirmar
    console.log("\n🔍 [DEPOSIT] Buscando depósito novamente para confirmar dados salvos...")
    const { data: verifyDeposit, error: verifyError } = await supabase
      .from("deposits")
      .select("*")
      .eq("id", insertedDeposit.id)
      .single()
    
    if (verifyError) {
      console.error("❌ [DEPOSIT] Erro ao verificar depósito:", verifyError)
    } else {
      console.log("✅ [DEPOSIT] Depósito verificado:")
      console.log("   - transaction_id:", verifyDeposit?.transaction_id || "NULL")
      console.log("   - external_transaction_id:", verifyDeposit?.external_transaction_id || "NULL")
      console.log("   - pix_qr_code:", verifyDeposit?.pix_qr_code ? verifyDeposit.pix_qr_code.substring(0, 50) + "..." : "NULL")
      console.log("   - pix_copy_paste:", verifyDeposit?.pix_copy_paste ? verifyDeposit.pix_copy_paste.substring(0, 50) + "..." : "NULL")
    }
    
    console.log("\n✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅")
    console.log("✅ [DEPOSIT] ========== FIM DO PROCESSAMENTO ==========")
    console.log("✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅\n")

    return NextResponse.json({
      success: true,
      data: extractedData,
      message: "PIX gerado com sucesso via SafiraCash",
    })
  } catch (error) {
    console.error("🔥 Erro geral SafiraCash:", error)
    return NextResponse.json(
      { success: false, message: "Erro ao processar depósito", error },
      { status: 500 },
    )
  }
}
