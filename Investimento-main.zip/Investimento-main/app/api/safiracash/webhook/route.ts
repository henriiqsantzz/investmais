import { NextRequest, NextResponse } from "next/server"
import { createAdminClient } from "@/lib/supabase/admin"

export async function POST(req: NextRequest) {
  const timestamp = new Date().toISOString()
  console.log(`\n\n\n`)
  console.log(`🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀`)
  console.log(`🚀 [${timestamp}] [WEBHOOK] ========== INÍCIO DA REQUISIÇÃO ==========`)
  console.log(`🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀🚀`)

  try {
    console.log(`📥 [${timestamp}] [WEBHOOK] Lendo body da requisição...`)
    const rawBody = await req.text()
    console.log(`📦 [${timestamp}] [WEBHOOK] RAW BODY recebido (${rawBody.length} caracteres):`)
    console.log(rawBody)

    let body: any
    try {
      console.log(`🔄 [${timestamp}] [WEBHOOK] Tentando parsear JSON...`)
      body = JSON.parse(rawBody)
      console.log(`✅ [${timestamp}] [WEBHOOK] JSON parseado com sucesso!`)
    } catch (parseError) {
      console.error(`❌ [${timestamp}] [WEBHOOK] ERRO ao parsear JSON:`, parseError)
      return NextResponse.json(
        { ok: false, message: "Erro ao interpretar JSON" },
        { status: 400 }
      )
    }

    console.log(`📋 [${timestamp}] [WEBHOOK] JSON completo parseado:`)
    console.log(JSON.stringify(body, null, 2))

    // ========== EXTRAÇÃO DE DADOS ==========
    console.log(`\n🔍 [${timestamp}] [WEBHOOK] ========== EXTRAINDO DADOS ==========`)
    
    const transactionId = body?.data?.transactionId || body?.transactionId || null
    const externalTransactionId = body?.data?.externalTransactionId || body?.externalTransactionId || null
    const rawStatus = body?.data?.status || body?.status || ""
    const status = String(rawStatus).toLowerCase().trim()
    const amount = body?.data?.amount || body?.amount || null
    const pixCode = body?.data?.pixQrCode || body?.data?.qrCode || body?.pixQrCode || body?.qrCode || ""

    console.log(`🔍 [${timestamp}] [WEBHOOK] Dados extraídos:`)
    console.log(`   - transactionId: ${transactionId || "NULL"}`)
    console.log(`   - externalTransactionId: ${externalTransactionId || "NULL"}`)
    console.log(`   - status (raw): ${rawStatus}`)
    console.log(`   - status (normalizado): ${status}`)
    console.log(`   - amount: ${amount || "NULL"}`)
    console.log(`   - pixCode: ${pixCode ? pixCode.substring(0, 50) + "..." : "NULL"}`)
    console.log(`   - pixCode completo: ${pixCode || "NULL"}`)

    // Valida se tem pelo menos um ID ou pixCode
    if (!transactionId && !externalTransactionId && !pixCode) {
      console.error(`❌ [${timestamp}] [WEBHOOK] NENHUM identificador encontrado!`)
      return NextResponse.json(
        { ok: false, message: "Missing identifiers" },
        { status: 400 }
      )
    }

    // Verifica se é status de pagamento confirmado
    console.log(`\n🔎 [${timestamp}] [WEBHOOK] ========== VERIFICANDO STATUS ==========`)
    const isPaidStatus = 
      status === "paid" || 
      status === "confirmed" || 
      status === "approved" ||
      status === "pago" || 
      status === "confirmado" ||
      status === "aprovado" ||
      status === "completed"

    console.log(`🔎 [${timestamp}] [WEBHOOK] Status recebido: "${status}"`)
    console.log(`🔎 [${timestamp}] [WEBHOOK] É status de pagamento? ${isPaidStatus ? "✅ SIM" : "❌ NÃO"}`)

    if (!isPaidStatus) {
      console.log(`ℹ️ [${timestamp}] [WEBHOOK] Status "${status}" não é de pagamento confirmado. Ignorando.`)
      return NextResponse.json(
        { ok: true, message: `Status ${status} ignorado` },
        { status: 200 }
      )
    }

    console.log(`\n💰 [${timestamp}] [WEBHOOK] ========== PROCESSANDO PAGAMENTO CONFIRMADO ==========`)

    // Usa cliente admin para bypassar RLS (webhooks não têm autenticação de usuário)
    console.log(`🔑 [${timestamp}] [WEBHOOK] Verificando variáveis de ambiente...`)
    console.log(`🔑 [${timestamp}] [WEBHOOK] SUPABASE_URL: ${process.env.SUPABASE_URL ? "✅ DEFINIDA" : "❌ NÃO DEFINIDA"}`)
    console.log(`🔑 [${timestamp}] [WEBHOOK] NEXT_PUBLIC_SUPABASE_URL: ${process.env.NEXT_PUBLIC_SUPABASE_URL ? "✅ DEFINIDA" : "❌ NÃO DEFINIDA"}`)
    console.log(`🔑 [${timestamp}] [WEBHOOK] SUPABASE_SERVICE_ROLE_KEY: ${process.env.SUPABASE_SERVICE_ROLE_KEY ? "✅ DEFINIDA (" + process.env.SUPABASE_SERVICE_ROLE_KEY.substring(0, 10) + "...)" : "❌ NÃO DEFINIDA"}`)
    
    try {
      const supabase = createAdminClient()
      console.log(`🔑 [${timestamp}] [WEBHOOK] ✅ Cliente admin criado com sucesso!`)
      console.log(`🔑 [${timestamp}] [WEBHOOK] Usando cliente admin (bypass RLS)`)
      
      // Testa se consegue acessar a tabela
      const { data: testData, error: testError } = await supabase
        .from("deposits")
        .select("id")
        .limit(1)
      
      if (testError) {
        console.error(`❌ [${timestamp}] [WEBHOOK] ERRO ao testar acesso à tabela deposits:`, testError)
        console.error(`❌ [${timestamp}] [WEBHOOK] Mensagem:`, testError.message)
        console.error(`❌ [${timestamp}] [WEBHOOK] Código:`, testError.code)
        console.error(`❌ [${timestamp}] [WEBHOOK] Detalhes:`, testError.details)
      } else {
        console.log(`✅ [${timestamp}] [WEBHOOK] Acesso à tabela deposits OK! (${testData?.length || 0} registros encontrados no teste)`)
      }
    } catch (error) {
      console.error(`❌ [${timestamp}] [WEBHOOK] ERRO ao criar cliente admin:`, error)
      return NextResponse.json(
        { ok: false, message: "Erro ao criar cliente Supabase", error: String(error) },
        { status: 500 }
      )
    }
    
    const supabase = createAdminClient()
    let deposit: any = null

    // ========== ESTRATÉGIA 1: Busca por transaction_id ==========
    console.log(`\n🔍 [${timestamp}] [WEBHOOK] ========== ESTRATÉGIA 1: Busca por transaction_id ==========`)
    if (transactionId) {
      console.log(`🔍 [${timestamp}] [WEBHOOK] Buscando depósito com transaction_id = "${transactionId}"`)
      const { data, error } = await supabase
        .from("deposits")
        .select("*")
        .eq("transaction_id", transactionId)
        .maybeSingle()
      
      console.log(`🔍 [${timestamp}] [WEBHOOK] Resultado da busca 1:`)
      console.log(`   - data:`, data ? `ENCONTRADO (ID: ${data.id})` : "NULL")
      console.log(`   - error:`, error || "NULL")
      if (data) {
        console.log(`   - Status do depósito: ${data.status}`)
        console.log(`   - transaction_id no banco: ${data.transaction_id || "NULL"}`)
        console.log(`   - external_transaction_id no banco: ${data.external_transaction_id || "NULL"}`)
      }
      
      if (error) {
        console.error(`❌ [${timestamp}] [WEBHOOK] Erro na busca 1:`, error)
      }
      if (data) {
        deposit = data
        console.log(`✅ [${timestamp}] [WEBHOOK] ENCONTRADO na Estratégia 1!`)
      }
    } else {
      console.log(`⚠️ [${timestamp}] [WEBHOOK] transactionId é NULL, pulando Estratégia 1`)
    }

    // ========== ESTRATÉGIA 2: Busca por external_transaction_id ==========
    if (!deposit) {
      console.log(`\n🔍 [${timestamp}] [WEBHOOK] ========== ESTRATÉGIA 2: Busca por external_transaction_id ==========`)
      if (externalTransactionId) {
        console.log(`🔍 [${timestamp}] [WEBHOOK] Buscando depósito com external_transaction_id = "${externalTransactionId}"`)
        const { data, error } = await supabase
          .from("deposits")
          .select("*")
          .eq("external_transaction_id", externalTransactionId)
          .maybeSingle()
        
        console.log(`🔍 [${timestamp}] [WEBHOOK] Resultado da busca 2:`)
        console.log(`   - data:`, data ? `ENCONTRADO (ID: ${data.id})` : "NULL")
        console.log(`   - error:`, error || "NULL")
        if (data) {
          console.log(`   - Status do depósito: ${data.status}`)
          console.log(`   - transaction_id no banco: ${data.transaction_id || "NULL"}`)
          console.log(`   - external_transaction_id no banco: ${data.external_transaction_id || "NULL"}`)
        }
        
        if (error) {
          console.error(`❌ [${timestamp}] [WEBHOOK] Erro na busca 2:`, error)
        }
        if (data) {
          deposit = data
          console.log(`✅ [${timestamp}] [WEBHOOK] ENCONTRADO na Estratégia 2!`)
        }
      } else {
        console.log(`⚠️ [${timestamp}] [WEBHOOK] externalTransactionId é NULL, pulando Estratégia 2`)
      }
    }

    // ========== ESTRATÉGIA 2.5: Busca por transaction_id usando externalTransactionId (caso estejam trocados) ==========
    if (!deposit && externalTransactionId && externalTransactionId !== transactionId) {
      console.log(`\n🔍 [${timestamp}] [WEBHOOK] ========== ESTRATÉGIA 2.5: Busca por transaction_id usando externalTransactionId ==========`)
      console.log(`🔍 [${timestamp}] [WEBHOOK] Tentando buscar transaction_id = "${externalTransactionId}" (caso estejam trocados)`)
      const { data, error } = await supabase
        .from("deposits")
        .select("*")
        .eq("transaction_id", externalTransactionId)
        .maybeSingle()
      
      console.log(`🔍 [${timestamp}] [WEBHOOK] Resultado da busca 2.5:`)
      console.log(`   - data:`, data ? `ENCONTRADO (ID: ${data.id})` : "NULL")
      console.log(`   - error:`, error || "NULL")
      if (data) {
        console.log(`   - Status do depósito: ${data.status}`)
        console.log(`   - transaction_id no banco: ${data.transaction_id || "NULL"}`)
        console.log(`   - external_transaction_id no banco: ${data.external_transaction_id || "NULL"}`)
      }
      
      if (error) {
        console.error(`❌ [${timestamp}] [WEBHOOK] Erro na busca 2.5:`, error)
      }
      if (data) {
        deposit = data
        console.log(`✅ [${timestamp}] [WEBHOOK] ENCONTRADO na Estratégia 2.5!`)
      }
    }

    // ========== ESTRATÉGIA 2.6: Busca por external_transaction_id usando transactionId (caso estejam trocados) ==========
    if (!deposit && transactionId && transactionId !== externalTransactionId) {
      console.log(`\n🔍 [${timestamp}] [WEBHOOK] ========== ESTRATÉGIA 2.6: Busca por external_transaction_id usando transactionId ==========`)
      console.log(`🔍 [${timestamp}] [WEBHOOK] Tentando buscar external_transaction_id = "${transactionId}" (caso estejam trocados)`)
      const { data, error } = await supabase
        .from("deposits")
        .select("*")
        .eq("external_transaction_id", transactionId)
        .maybeSingle()
      
      console.log(`🔍 [${timestamp}] [WEBHOOK] Resultado da busca 2.6:`)
      console.log(`   - data:`, data ? `ENCONTRADO (ID: ${data.id})` : "NULL")
      console.log(`   - error:`, error || "NULL")
      if (data) {
        console.log(`   - Status do depósito: ${data.status}`)
        console.log(`   - transaction_id no banco: ${data.transaction_id || "NULL"}`)
        console.log(`   - external_transaction_id no banco: ${data.external_transaction_id || "NULL"}`)
      }
      
      if (error) {
        console.error(`❌ [${timestamp}] [WEBHOOK] Erro na busca 2.6:`, error)
      }
      if (data) {
        deposit = data
        console.log(`✅ [${timestamp}] [WEBHOOK] ENCONTRADO na Estratégia 2.6!`)
      }
    }

    // ========== ESTRATÉGIA 3: Busca usando OR (como check-status) ==========
    if (!deposit && (transactionId || externalTransactionId)) {
      console.log(`\n🔍 [${timestamp}] [WEBHOOK] ========== ESTRATÉGIA 3: Busca com OR ==========`)
      const idsToSearch = []
      if (transactionId) idsToSearch.push(transactionId)
      if (externalTransactionId) idsToSearch.push(externalTransactionId)
      
      console.log(`🔍 [${timestamp}] [WEBHOOK] IDs para buscar com OR:`, idsToSearch)
      
      for (const id of idsToSearch) {
        console.log(`🔍 [${timestamp}] [WEBHOOK] Buscando com OR para ID = "${id}"`)
        const query = `transaction_id.eq.${id},external_transaction_id.eq.${id}`
        console.log(`🔍 [${timestamp}] [WEBHOOK] Query OR: ${query}`)
        
        const { data: deposits, error } = await supabase
          .from("deposits")
          .select("*")
          .or(query)
          .limit(1)
        
        console.log(`🔍 [${timestamp}] [WEBHOOK] Resultado da busca 3 (ID: ${id}):`)
        console.log(`   - deposits:`, deposits ? `${deposits.length} encontrado(s)` : "NULL")
        console.log(`   - error:`, error || "NULL")
        if (deposits && deposits.length > 0) {
          console.log(`   - Primeiro depósito:`)
          console.log(`     - ID: ${deposits[0].id}`)
          console.log(`     - Status: ${deposits[0].status}`)
          console.log(`     - transaction_id: ${deposits[0].transaction_id || "NULL"}`)
          console.log(`     - external_transaction_id: ${deposits[0].external_transaction_id || "NULL"}`)
        }
        
        if (error) {
          console.error(`❌ [${timestamp}] [WEBHOOK] Erro na busca 3:`, error)
        }
        if (deposits && deposits.length > 0) {
          deposit = deposits[0]
          console.log(`✅ [${timestamp}] [WEBHOOK] ENCONTRADO na Estratégia 3!`)
          break
        }
      }
    }

    // ========== ESTRATÉGIA 3.5: Busca combinando AMBOS os IDs em uma única query OR ==========
    if (!deposit && transactionId && externalTransactionId && transactionId !== externalTransactionId) {
      console.log(`\n🔍 [${timestamp}] [WEBHOOK] ========== ESTRATÉGIA 3.5: Busca combinando ambos IDs ==========`)
      console.log(`🔍 [${timestamp}] [WEBHOOK] Buscando com OR combinando transactionId e externalTransactionId`)
      const query = `transaction_id.eq.${transactionId},external_transaction_id.eq.${transactionId},transaction_id.eq.${externalTransactionId},external_transaction_id.eq.${externalTransactionId}`
      console.log(`🔍 [${timestamp}] [WEBHOOK] Query OR combinada: ${query}`)
      
      const { data: deposits, error } = await supabase
        .from("deposits")
        .select("*")
        .or(query)
        .limit(1)
      
      console.log(`🔍 [${timestamp}] [WEBHOOK] Resultado da busca 3.5:`)
      console.log(`   - deposits:`, deposits ? `${deposits.length} encontrado(s)` : "NULL")
      console.log(`   - error:`, error || "NULL")
      if (deposits && deposits.length > 0) {
        console.log(`   - Primeiro depósito:`)
        console.log(`     - ID: ${deposits[0].id}`)
        console.log(`     - Status: ${deposits[0].status}`)
        console.log(`     - transaction_id: ${deposits[0].transaction_id || "NULL"}`)
        console.log(`     - external_transaction_id: ${deposits[0].external_transaction_id || "NULL"}`)
      }
      
      if (error) {
        console.error(`❌ [${timestamp}] [WEBHOOK] Erro na busca 3.5:`, error)
      }
      if (deposits && deposits.length > 0) {
        deposit = deposits[0]
        console.log(`✅ [${timestamp}] [WEBHOOK] ENCONTRADO na Estratégia 3.5!`)
      }
    }

    // ========== ESTRATÉGIA 4: Busca por pix_qr_code ==========
    if (!deposit && pixCode) {
      console.log(`\n🔍 [${timestamp}] [WEBHOOK] ========== ESTRATÉGIA 4: Busca por pix_qr_code ==========`)
      console.log(`🔍 [${timestamp}] [WEBHOOK] Buscando depósito com pix_qr_code = "${pixCode.substring(0, 50)}..."`)
      const { data, error } = await supabase
        .from("deposits")
        .select("*")
        .eq("pix_qr_code", pixCode)
        .maybeSingle()
      
      console.log(`🔍 [${timestamp}] [WEBHOOK] Resultado da busca 4:`)
      console.log(`   - data:`, data ? `ENCONTRADO (ID: ${data.id})` : "NULL")
      console.log(`   - error:`, error || "NULL")
      if (data) {
        console.log(`   - pix_qr_code no banco: ${data.pix_qr_code ? data.pix_qr_code.substring(0, 50) + "..." : "NULL"}`)
      }
      
      if (error) {
        console.error(`❌ [${timestamp}] [WEBHOOK] Erro na busca 4:`, error)
      }
      if (data) {
        deposit = data
        console.log(`✅ [${timestamp}] [WEBHOOK] ENCONTRADO na Estratégia 4!`)
      }
    }

    // ========== ESTRATÉGIA 5: Busca por pix_copy_paste ==========
    if (!deposit && pixCode) {
      console.log(`\n🔍 [${timestamp}] [WEBHOOK] ========== ESTRATÉGIA 5: Busca por pix_copy_paste ==========`)
      console.log(`🔍 [${timestamp}] [WEBHOOK] Buscando depósito com pix_copy_paste = "${pixCode.substring(0, 50)}..."`)
      const { data, error } = await supabase
        .from("deposits")
        .select("*")
        .eq("pix_copy_paste", pixCode)
        .maybeSingle()
      
      console.log(`🔍 [${timestamp}] [WEBHOOK] Resultado da busca 5:`)
      console.log(`   - data:`, data ? `ENCONTRADO (ID: ${data.id})` : "NULL")
      console.log(`   - error:`, error || "NULL")
      if (data) {
        console.log(`   - pix_copy_paste no banco: ${data.pix_copy_paste ? data.pix_copy_paste.substring(0, 50) + "..." : "NULL"}`)
      }
      
      if (error) {
        console.error(`❌ [${timestamp}] [WEBHOOK] Erro na busca 5:`, error)
      }
      if (data) {
        deposit = data
        console.log(`✅ [${timestamp}] [WEBHOOK] ENCONTRADO na Estratégia 5!`)
      }
    }

    // ========== ESTRATÉGIA 6: Busca por pix_qr_code OU pix_copy_paste ==========
    if (!deposit && pixCode) {
      console.log(`\n🔍 [${timestamp}] [WEBHOOK] ========== ESTRATÉGIA 6: Busca por pix_qr_code OU pix_copy_paste ==========`)
      const query = `pix_qr_code.eq.${pixCode},pix_copy_paste.eq.${pixCode}`
      console.log(`🔍 [${timestamp}] [WEBHOOK] Query OR: ${query}`)
      const { data, error } = await supabase
        .from("deposits")
        .select("*")
        .or(query)
        .maybeSingle()
      
      console.log(`🔍 [${timestamp}] [WEBHOOK] Resultado da busca 6:`)
      console.log(`   - data:`, data ? `ENCONTRADO (ID: ${data.id})` : "NULL")
      console.log(`   - error:`, error || "NULL")
      
      if (error) {
        console.error(`❌ [${timestamp}] [WEBHOOK] Erro na busca 6:`, error)
      }
      if (data) {
        deposit = data
        console.log(`✅ [${timestamp}] [WEBHOOK] ENCONTRADO na Estratégia 6!`)
      }
    }

    // ========== ESTRATÉGIA 7: Busca depósitos recentes pendentes e compara pixCode ==========
    if (!deposit && pixCode) {
      console.log(`\n🔍 [${timestamp}] [WEBHOOK] ========== ESTRATÉGIA 7: Busca em depósitos recentes ==========`)
      const thirtyMinutesAgo = new Date(Date.now() - 30 * 60 * 1000).toISOString()
      console.log(`🔍 [${timestamp}] [WEBHOOK] Buscando depósitos criados após: ${thirtyMinutesAgo}`)
      
      const { data: recentDeposits, error } = await supabase
        .from("deposits")
        .select("*")
        .eq("status", "pending")
        .gte("created_at", thirtyMinutesAgo)
        .order("created_at", { ascending: false })
        .limit(20)
      
      console.log(`🔍 [${timestamp}] [WEBHOOK] Resultado da busca 7:`)
      console.log(`   - recentDeposits:`, recentDeposits ? `${recentDeposits.length} encontrado(s)` : "NULL")
      console.log(`   - error:`, error || "NULL")
      
      if (error) {
        console.error(`❌ [${timestamp}] [WEBHOOK] Erro na busca 7:`, error)
      }
      
      if (recentDeposits && recentDeposits.length > 0) {
        console.log(`📋 [${timestamp}] [WEBHOOK] Analisando ${recentDeposits.length} depósitos recentes...`)
        
        for (let i = 0; i < recentDeposits.length; i++) {
          const dep = recentDeposits[i]
          console.log(`\n   [${i + 1}/${recentDeposits.length}] Depósito ID: ${dep.id}`)
          console.log(`      - Status: ${dep.status}`)
          console.log(`      - Amount: R$ ${dep.amount}`)
          console.log(`      - transaction_id: ${dep.transaction_id || "NULL"}`)
          console.log(`      - external_transaction_id: ${dep.external_transaction_id || "NULL"}`)
          console.log(`      - pix_qr_code: ${dep.pix_qr_code ? dep.pix_qr_code.substring(0, 50) + "..." : "NULL"}`)
          console.log(`      - pix_copy_paste: ${dep.pix_copy_paste ? dep.pix_copy_paste.substring(0, 50) + "..." : "NULL"}`)
          console.log(`      - created_at: ${dep.created_at}`)
          
          const depPixCode = dep.pix_qr_code || dep.pix_copy_paste
          console.log(`      - depPixCode (usado para comparação): ${depPixCode ? depPixCode.substring(0, 50) + "..." : "NULL"}`)
          
          if (depPixCode && pixCode) {
            const exactMatch = depPixCode === pixCode
            const partialMatch1 = depPixCode.includes(pixCode.substring(0, 40))
            const partialMatch2 = pixCode.includes(depPixCode.substring(0, 40))
            const webhookPixId = pixCode.match(/\/pix\/([A-Z0-9]+)/)?.[1]
            const depositPixId = depPixCode.match(/\/pix\/([A-Z0-9]+)/)?.[1]
            const pixIdMatch = webhookPixId && depositPixId && webhookPixId === depositPixId
            
            console.log(`      🔍 Comparação:`)
            console.log(`         - Exato: ${exactMatch ? "✅" : "❌"}`)
            console.log(`         - Parcial 1: ${partialMatch1 ? "✅" : "❌"}`)
            console.log(`         - Parcial 2: ${partialMatch2 ? "✅" : "❌"}`)
            console.log(`         - Pix ID: ${pixIdMatch ? "✅" : "❌"} (webhook: ${webhookPixId || "N/A"}, deposit: ${depositPixId || "N/A"})`)
            
            const matches = exactMatch || partialMatch1 || partialMatch2 || pixIdMatch
            console.log(`      - MATCH: ${matches ? "✅ SIM" : "❌ NÃO"}`)
            
            if (matches) {
              deposit = dep
              console.log(`\n✅ [${timestamp}] [WEBHOOK] ENCONTRADO na Estratégia 7!`)
              console.log(`✅ [${timestamp}] [WEBHOOK] Depósito ID: ${dep.id}`)
              break
            }
          } else {
            console.log(`      ⚠️ Sem pixCode para comparar`)
          }
        }
      } else {
        console.log(`⚠️ [${timestamp}] [WEBHOOK] Nenhum depósito recente encontrado`)
      }
    }

    // ========== SE NÃO ENCONTROU, RETORNA ERRO ==========
    if (!deposit || !deposit.id) {
      console.error(`\n❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌`)
      console.error(`❌ [${timestamp}] [WEBHOOK] DEPÓSITO NÃO ENCONTRADO APÓS TODAS AS 7 ESTRATÉGIAS!`)
      console.error(`❌ [${timestamp}] [WEBHOOK] IDs procurados:`)
      console.error(`   - transactionId: ${transactionId || "NULL"}`)
      console.error(`   - externalTransactionId: ${externalTransactionId || "NULL"}`)
      console.error(`❌ [${timestamp}] [WEBHOOK] pixCode procurado: ${pixCode ? pixCode.substring(0, 50) + "..." : "NULL"}`)
      console.error(`❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌`)
      
      // Busca TODOS os depósitos pendentes para debug
      console.log(`\n🔍 [${timestamp}] [WEBHOOK] Buscando TODOS os depósitos pendentes para debug...`)
      const { data: allPending, error: allPendingError } = await supabase
        .from("deposits")
        .select("*")
        .eq("status", "pending")
        .order("created_at", { ascending: false })
        .limit(50)
      
      if (allPendingError) {
        console.error(`❌ [${timestamp}] [WEBHOOK] Erro ao buscar todos pendentes:`, allPendingError)
      } else {
        console.log(`📋 [${timestamp}] [WEBHOOK] Total de depósitos pendentes: ${allPending?.length || 0}`)
        if (allPending && allPending.length > 0) {
          console.log(`📋 [${timestamp}] [WEBHOOK] Listando todos os depósitos pendentes:`)
          allPending.forEach((dep: any, idx: number) => {
            console.log(`\n   [${idx + 1}] Depósito ID: ${dep.id}`)
            console.log(`      - transaction_id: ${dep.transaction_id || "NULL"}`)
            console.log(`      - external_transaction_id: ${dep.external_transaction_id || "NULL"}`)
            console.log(`      - pix_qr_code: ${dep.pix_qr_code ? dep.pix_qr_code.substring(0, 50) + "..." : "NULL"}`)
            console.log(`      - pix_copy_paste: ${dep.pix_copy_paste ? dep.pix_copy_paste.substring(0, 50) + "..." : "NULL"}`)
            console.log(`      - created_at: ${dep.created_at}`)
          })
        }
      }
      
      return NextResponse.json(
        { ok: false, message: "Depósito não encontrado" },
        { status: 404 }
      )
    }

    console.log(`\n✅ [${timestamp}] [WEBHOOK] ========== DEPÓSITO ENCONTRADO! ==========`)
    console.log(`✅ [${timestamp}] [WEBHOOK] Depósito ID: ${deposit.id}`)
    console.log(`✅ [${timestamp}] [WEBHOOK] Status atual: ${deposit.status}`)
    console.log(`✅ [${timestamp}] [WEBHOOK] User ID: ${deposit.user_id}`)
    console.log(`✅ [${timestamp}] [WEBHOOK] Amount: R$ ${deposit.amount}`)
    console.log(`✅ [${timestamp}] [WEBHOOK] transaction_id no banco: ${deposit.transaction_id || "NULL"}`)
    console.log(`✅ [${timestamp}] [WEBHOOK] external_transaction_id no banco: ${deposit.external_transaction_id || "NULL"}`)

    // ========== VERIFICA SE JÁ FOI PROCESSADO ==========
    console.log(`\n🔍 [${timestamp}] [WEBHOOK] ========== VERIFICANDO SE JÁ FOI PROCESSADO ==========`)
    if (deposit.status === "paid" || deposit.status === "completed") {
      console.log(`ℹ️ [${timestamp}] [WEBHOOK] Depósito já foi processado anteriormente (status: ${deposit.status})`)
      return NextResponse.json(
        { ok: true, message: "Depósito já processado", transactionId: transactionId || externalTransactionId },
        { status: 200 }
      )
    }
    console.log(`✅ [${timestamp}] [WEBHOOK] Depósito ainda não foi processado, continuando...`)

    // ========== ATUALIZA OS IDs SE NECESSÁRIO ==========
    console.log(`\n📝 [${timestamp}] [WEBHOOK] ========== ATUALIZANDO IDs SE NECESSÁRIO ==========`)
    const updateData: any = {
      updated_at: new Date().toISOString()
    }

    if (transactionId && deposit.transaction_id !== transactionId) {
      console.log(`📝 [${timestamp}] [WEBHOOK] Atualizando transaction_id: ${deposit.transaction_id} -> ${transactionId}`)
      updateData.transaction_id = transactionId
    } else {
      console.log(`ℹ️ [${timestamp}] [WEBHOOK] transaction_id não precisa ser atualizado`)
    }
    
    if (externalTransactionId && deposit.external_transaction_id !== externalTransactionId) {
      console.log(`📝 [${timestamp}] [WEBHOOK] Atualizando external_transaction_id: ${deposit.external_transaction_id} -> ${externalTransactionId}`)
      updateData.external_transaction_id = externalTransactionId
    } else {
      console.log(`ℹ️ [${timestamp}] [WEBHOOK] external_transaction_id não precisa ser atualizado`)
    }

    // ========== ATUALIZA STATUS PARA "paid" ==========
    console.log(`\n📝 [${timestamp}] [WEBHOOK] ========== ATUALIZANDO STATUS PARA "paid" ==========`)
    updateData.status = "paid"
    console.log(`📝 [${timestamp}] [WEBHOOK] Dados para atualizar:`, JSON.stringify(updateData, null, 2))

    const { error: updateError } = await supabase
      .from("deposits")
      .update(updateData)
      .eq("id", deposit.id)

    if (updateError) {
      console.error(`❌ [${timestamp}] [WEBHOOK] ERRO ao atualizar depósito:`, updateError)
      return NextResponse.json(
        { ok: false, message: "Erro ao atualizar depósito", error: updateError },
        { status: 500 }
      )
    }

    console.log(`✅ [${timestamp}] [WEBHOOK] Depósito atualizado para "paid" com sucesso!`)

    // ========== CREDITA O SALDO DO USUÁRIO ==========
    console.log(`\n💰 [${timestamp}] [WEBHOOK] ========== CREDITANDO SALDO ==========`)
    console.log(`💰 [${timestamp}] [WEBHOOK] Buscando perfil do usuário ID: ${deposit.user_id}`)
    
    const { data: userProfile, error: profileError } = await supabase
      .from("profiles")
      .select("balance")
      .eq("id", deposit.user_id)
      .single()

    if (profileError) {
      console.error(`❌ [${timestamp}] [WEBHOOK] ERRO ao buscar perfil:`, profileError)
      return NextResponse.json(
        { ok: false, message: "Erro ao buscar perfil", error: profileError },
        { status: 500 }
      )
    }

    if (!userProfile) {
      console.error(`❌ [${timestamp}] [WEBHOOK] Perfil não encontrado para user_id: ${deposit.user_id}`)
      return NextResponse.json(
        { ok: false, message: "Perfil não encontrado" },
        { status: 404 }
      )
    }

    const currentBalance = Number(userProfile.balance || 0)
    const depositAmount = Number(deposit.amount || amount || 0)
    const newBalance = currentBalance + depositAmount

    console.log(`💰 [${timestamp}] [WEBHOOK] Saldo atual: R$ ${currentBalance.toFixed(2)}`)
    console.log(`💰 [${timestamp}] [WEBHOOK] Depósito: R$ ${depositAmount.toFixed(2)}`)
    console.log(`💰 [${timestamp}] [WEBHOOK] Novo saldo: R$ ${newBalance.toFixed(2)}`)

    console.log(`💰 [${timestamp}] [WEBHOOK] Atualizando saldo no banco...`)
    const { error: balanceUpdateError } = await supabase
      .from("profiles")
      .update({ balance: newBalance, updated_at: new Date().toISOString() })
      .eq("id", deposit.user_id)

    if (balanceUpdateError) {
      console.error(`❌ [${timestamp}] [WEBHOOK] ERRO ao atualizar saldo:`, balanceUpdateError)
      return NextResponse.json(
        { ok: false, message: "Erro ao creditar saldo", error: balanceUpdateError },
        { status: 500 }
      )
    }

    console.log(`✅ [${timestamp}] [WEBHOOK] Saldo creditado com sucesso!`)

    // ========== ATUALIZA TRANSACTIONS ==========
    console.log(`\n📝 [${timestamp}] [WEBHOOK] ========== ATUALIZANDO TRANSACTIONS ==========`)
    const { error: transactionUpdateError } = await supabase
      .from("transactions")
      .update({ status: "completed", updated_at: new Date().toISOString() })
      .eq("user_id", deposit.user_id)
      .eq("type", "deposit")
      .eq("amount", deposit.amount)
      .eq("status", "pending")

    if (transactionUpdateError) {
      console.warn(`⚠️ [${timestamp}] [WEBHOOK] Erro ao atualizar transactions:`, transactionUpdateError)
    } else {
      console.log(`✅ [${timestamp}] [WEBHOOK] Transactions atualizado para "completed"`)
    }

    // ========== ATUALIZA STATUS PARA "completed" ==========
    console.log(`\n📝 [${timestamp}] [WEBHOOK] ========== ATUALIZANDO STATUS PARA "completed" ==========`)
    const { error: completeUpdateError } = await supabase
      .from("deposits")
      .update({ status: "completed", updated_at: new Date().toISOString() })
      .eq("id", deposit.id)

    if (completeUpdateError) {
      console.error(`❌ [${timestamp}] [WEBHOOK] ERRO ao atualizar para completed:`, completeUpdateError)
    } else {
      console.log(`✅ [${timestamp}] [WEBHOOK] Status atualizado para "completed"`)
    }

    console.log(`\n✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅`)
    console.log(`✅ [${timestamp}] [WEBHOOK] ========== PROCESSAMENTO CONCLUÍDO COM SUCESSO! ==========`)
    console.log(`✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅✅\n\n\n`)

    return NextResponse.json(
      { 
        ok: true, 
        message: "Depósito processado e saldo creditado com sucesso", 
        transactionId: transactionId || externalTransactionId 
      },
      { status: 200 }
    )
  } catch (error) {
    console.error(`\n🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥`)
    console.error(`🔥 [${timestamp}] [WEBHOOK] ERRO INESPERADO:`)
    console.error(error)
    console.error(`🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥\n\n\n`)
    return NextResponse.json(
      { ok: false, message: "Erro interno no webhook", error: String(error) },
      { status: 500 }
    )
  }
}
