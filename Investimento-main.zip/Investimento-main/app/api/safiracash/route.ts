import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    console.log("[v0] Gerando QR code para valor:", body.quantia)

    const { quantia, metodoDePagamento, dadosDoCliente } = body

    if (!quantia || quantia < 5 || quantia > 50000) {
      return NextResponse.json(
        { success: false, message: "Valor inválido. Mínimo: R$5, Máximo: R$50.000" },
        { status: 400 }
      )
    }

    if (metodoDePagamento !== "PIX") {
      return NextResponse.json(
        { success: false, message: "Método de pagamento não suportado" },
        { status: 400 }
      )
    }

    if (!dadosDoCliente?.nome || !dadosDoCliente?.email || !dadosDoCliente?.documento) {
      return NextResponse.json(
        { success: false, message: "Dados do cliente incompletos" },
        { status: 400 }
      )
    }

    const safiraApiKey = "sk_c6e57cfca184b61dbf09a628831e6103ab06a7bdfc4fe0eeb6f8f835cc60ed1f"
    const safiraEndpoint = "https://api.safira.cash/api/payments/deposit"

    // Corrigido conforme documentação: usar customerData em vez de payer
    const requestBody = {
      amount: quantia,
      paymentMethod: "PIX",
      customerData: {
        name: dadosDoCliente.nome,
        email: dadosDoCliente.email,
        document: dadosDoCliente.documento,
        phone: dadosDoCliente.telefone || "+5511999999999",
      },
      metadata: {
        orderId: `ORDER_${Date.now()}`,
        description: `Depósito via PIX - R$ ${quantia.toFixed(2)}`,
      },
      callbackUrl: "https://investimentoaltoo.vercel.app/api/safiracash/webhook",
    }

    console.log("[v0] Chamando SafiraCash API...")

    const response = await fetch(safiraEndpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": safiraApiKey,
      },
      body: JSON.stringify(requestBody),
    })

    const responseText = await response.text()
    console.log("[v0] 🔍 Resposta SafiraCash:", responseText)

    if (!response.ok) {
      return NextResponse.json(
        { success: false, message: "Erro ao gerar PIX SafiraCash", responseText },
        { status: 400 }
      )
    }

    const pixData = JSON.parse(responseText)

    const extractedData = {
      transactionId: pixData.data?.transactionId || null,
      externalTransactionId: pixData.data?.externalTransactionId || null,
      pixKey: pixData.data?.pixKey || "",
      pixCode: pixData.data?.pixQrCode || pixData.data?.qrCode || "",
      amount: quantia,
      status: pixData.data?.status || "pending",
      expiresAt:
        pixData.data?.expiresAt ||
        new Date(Date.now() + 30 * 60 * 1000).toISOString(),
    }

    console.log("[v0] Dados extraídos para salvar:", extractedData)

    await saveToSupabase(extractedData, quantia, metodoDePagamento)

    return NextResponse.json({
      success: true,
      data: extractedData,
      message: "PIX gerado com sucesso via SafiraCash",
    })
  } catch (error) {
    console.error("[v0] ❌ Erro no POST:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Erro ao processar depósito",
        error: error instanceof Error ? error.message : String(error),
      },
      { status: 500 }
    )
  }
}

// 🔹 Função que salva o depósito na Supabase
async function saveToSupabase(
  pixData: any,
  quantia: number,
  metodoDePagamento: string
) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      console.log("[v0] Usuário não autenticado - depósito não será salvo.")
      return
    }

    // 🔹 Verifica se o PIX tem IDs válidos antes de salvar
    if (!pixData?.transactionId && !pixData?.externalTransactionId) {
      console.log("[v0] PIX sem IDs - aguardando retorno da SafiraCash, não será salvo ainda.")
      return
    }

    console.log("[v0] Salvando depósito no Supabase...")
    console.log("[DEBUG PIXDATA AO SALVAR]:", JSON.stringify(pixData, null, 2))

    // 🔹 Evita salvar duplicado
    const { data: existingDeposit } = await supabase
      .from("deposits")
      .select("id")
      .or(
        `transaction_id.eq.${pixData.transactionId},external_transaction_id.eq.${pixData.externalTransactionId}`
      )
      .eq("user_id", user.id)
      .maybeSingle()

    if (existingDeposit) {
      console.log("[v0] Depósito já existente, pulando inserção duplicada:", existingDeposit.id)
      return
    }

    const { error: depositError } = await supabase.from("deposits").insert({
      user_id: user.id,
      amount: quantia,
      payment_method: metodoDePagamento,
      status: "pending",
      pix_key: pixData.pixKey || null,
      pix_qr_code: pixData.pixCode || null,
      pix_copy_paste: pixData.pixCode || null, // Salva também em pix_copy_paste
      transaction_id: pixData.transactionId || null,
      external_transaction_id: pixData.externalTransactionId || null,
      expires_at: pixData.expiresAt,
    })

    if (depositError) {
      console.error("[v0] Erro ao salvar depósito:", depositError)
      return
    }

    console.log("[v0] Depósito salvo com sucesso no Supabase!")

    // 🔹 Cria o registro na tabela "transactions"
    const { error: transactionError } = await supabase.from("transactions").insert({
      user_id: user.id,
      type: "deposit",
      amount: quantia,
      status: "pending",
      method: "pix",
      description: `Depósito via PIX - R$ ${quantia.toFixed(2)}`,
    })

    if (transactionError) {
      console.error("[v0] Erro ao salvar transação:", transactionError)
      return
    }

    console.log("[v0] Depósito e transação salvos com sucesso!")
  } catch (error) {
    console.error("[v0] Erro no saveToSupabase:", error)
  }
}
