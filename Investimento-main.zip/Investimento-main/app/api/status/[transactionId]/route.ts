import { type NextRequest, NextResponse } from "next/server"
import { createAdminClient } from "@/lib/supabase/admin"

export async function GET(request: NextRequest) {
  const timestamp = new Date().toISOString()
  console.log(`\n📡 [${timestamp}] [STATUS] ========== NOVA REQUISIÇÃO ==========`)
  
  try {
    // Pega o transactionId de forma segura, seja por rota ou query
    const { searchParams, pathname } = new URL(request.url)
    const transactionId =
      searchParams.get("transactionId") ||
      pathname.split("/").pop()

    console.log(`🔍 [${timestamp}] [STATUS] transactionId recebido:`, transactionId)

    if (!transactionId) {
      console.error(`❌ [${timestamp}] [STATUS] Nenhum transactionId fornecido`)
      return NextResponse.json({ success: false, message: "ID da transação não fornecido" }, { status: 400 })
    }

    // Verifica se as variáveis de ambiente estão configuradas
    console.log(`🔑 [${timestamp}] [STATUS] Verificando variáveis de ambiente...`)
    console.log(`🔑 [${timestamp}] [STATUS] SUPABASE_URL: ${process.env.SUPABASE_URL ? "✅" : "❌"}`)
    console.log(`🔑 [${timestamp}] [STATUS] NEXT_PUBLIC_SUPABASE_URL: ${process.env.NEXT_PUBLIC_SUPABASE_URL ? "✅" : "❌"}`)
    console.log(`🔑 [${timestamp}] [STATUS] SUPABASE_SERVICE_ROLE_KEY: ${process.env.SUPABASE_SERVICE_ROLE_KEY ? "✅ (" + process.env.SUPABASE_SERVICE_ROLE_KEY.substring(0, 10) + "...)" : "❌ NÃO DEFINIDA"}`)

    // Usa cliente admin para bypassar RLS e garantir acesso aos dados
    let supabase
    try {
      supabase = createAdminClient()
      console.log(`✅ [${timestamp}] [STATUS] Cliente admin criado com sucesso`)
    } catch (adminError) {
      console.error(`❌ [${timestamp}] [STATUS] ERRO ao criar cliente admin:`, adminError)
      // Fallback para cliente normal
      const { createClient } = await import("@/lib/supabase/server")
      supabase = await createClient()
      console.log(`⚠️ [${timestamp}] [STATUS] Usando cliente normal (fallback)`)
    }

    // Busca por transaction_id
    console.log(`🔍 [${timestamp}] [STATUS] Buscando por transaction_id = "${transactionId}"`)
    let deposit: any = null
    let depositError: any = null

    const { data: deposit1, error: error1 } = await supabase
      .from("deposits")
      .select("*")
      .eq("transaction_id", transactionId)
      .maybeSingle()

    console.log(`🔍 [${timestamp}] [STATUS] Busca 1 (transaction_id):`, deposit1 ? `✅ ENCONTRADO (ID: ${deposit1.id})` : "❌ NÃO ENCONTRADO")
    if (error1) console.error(`❌ [${timestamp}] [STATUS] Erro na busca 1:`, error1)

    if (deposit1) {
      deposit = deposit1
      console.log(`✅ [${timestamp}] [STATUS] Depósito encontrado na busca 1!`)
    } else {
      // Busca por external_transaction_id
      console.log(`🔍 [${timestamp}] [STATUS] Buscando por external_transaction_id = "${transactionId}"`)
      const { data: deposit2, error: error2 } = await supabase
        .from("deposits")
        .select("*")
        .eq("external_transaction_id", transactionId)
        .maybeSingle()

      console.log(`🔍 [${timestamp}] [STATUS] Busca 2 (external_transaction_id):`, deposit2 ? `✅ ENCONTRADO (ID: ${deposit2.id})` : "❌ NÃO ENCONTRADO")
      if (error2) console.error(`❌ [${timestamp}] [STATUS] Erro na busca 2:`, error2)

      if (deposit2) {
        deposit = deposit2
        console.log(`✅ [${timestamp}] [STATUS] Depósito encontrado na busca 2!`)
      } else {
        // Tenta busca com OR
        console.log(`🔍 [${timestamp}] [STATUS] Buscando com OR para "${transactionId}"`)
        const { data: deposits, error: error3 } = await supabase
          .from("deposits")
          .select("*")
          .or(`transaction_id.eq.${transactionId},external_transaction_id.eq.${transactionId}`)
          .limit(1)

        console.log(`🔍 [${timestamp}] [STATUS] Busca 3 (OR):`, deposits && deposits.length > 0 ? `✅ ENCONTRADO (${deposits.length} resultado(s))` : "❌ NÃO ENCONTRADO")
        if (error3) console.error(`❌ [${timestamp}] [STATUS] Erro na busca 3:`, error3)

        if (deposits && deposits.length > 0) {
          deposit = deposits[0]
          console.log(`✅ [${timestamp}] [STATUS] Depósito encontrado na busca 3!`)
        } else {
          depositError = error3 || error2 || error1
          
          // Busca TODOS os depósitos recentes para debug
          console.log(`🔍 [${timestamp}] [STATUS] Buscando TODOS os depósitos recentes para debug...`)
          const { data: allDeposits, error: allError } = await supabase
            .from("deposits")
            .select("id, transaction_id, external_transaction_id, status, created_at")
            .order("created_at", { ascending: false })
            .limit(10)
          
          if (allError) {
            console.error(`❌ [${timestamp}] [STATUS] Erro ao buscar todos:`, allError)
          } else {
            console.log(`📋 [${timestamp}] [STATUS] Total de depósitos encontrados: ${allDeposits?.length || 0}`)
            if (allDeposits && allDeposits.length > 0) {
              console.log(`📋 [${timestamp}] [STATUS] Últimos depósitos:`)
              allDeposits.forEach((d: any, idx: number) => {
                console.log(`   [${idx + 1}] ID: ${d.id}`)
                console.log(`       transaction_id: ${d.transaction_id || "NULL"}`)
                console.log(`       external_transaction_id: ${d.external_transaction_id || "NULL"}`)
                console.log(`       status: ${d.status}`)
                console.log(`       created_at: ${d.created_at}`)
              })
            }
          }
        }
      }
    }

    if (!deposit) {
      console.error(`\n❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌`)
      console.error(`❌ [${timestamp}] [STATUS] DEPÓSITO NÃO ENCONTRADO!`)
      console.error(`❌ [${timestamp}] [STATUS] transactionId procurado: ${transactionId}`)
      console.error(`❌ [${timestamp}] [STATUS] Erro:`, depositError)
      console.error(`❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌❌\n`)
      return NextResponse.json({ success: false, message: "Depósito não encontrado" }, { status: 404 })
    }

    console.log(`✅ [${timestamp}] [STATUS] Depósito encontrado!`)
    console.log(`   - ID: ${deposit.id}`)
    console.log(`   - Status: ${deposit.status}`)
    console.log(`   - transaction_id: ${deposit.transaction_id || "NULL"}`)
    console.log(`   - external_transaction_id: ${deposit.external_transaction_id || "NULL"}`)

    // Se o depósito foi pago/completado, busca o saldo atualizado do usuário
    let updatedBalance = null
    if (deposit.status === "paid" || deposit.status === "completed") {
      const { data: profile } = await supabase
        .from("profiles")
        .select("balance")
        .eq("id", deposit.user_id)
        .single()
      
      if (profile) {
        updatedBalance = Number(profile.balance || 0)
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        transactionId: deposit.transaction_id || deposit.external_transaction_id,
        status: deposit.status,
        amount: deposit.amount,
        createdAt: deposit.created_at,
        updatedAt: deposit.updated_at,
        expiresAt: deposit.expires_at,
        updatedBalance,
      },
    })
  } catch (error) {
    console.error("[STATUS] Erro:", error)
    return NextResponse.json(
      { success: false, message: "Erro ao verificar status do pagamento" },
      { status: 500 },
    )
  }
}
