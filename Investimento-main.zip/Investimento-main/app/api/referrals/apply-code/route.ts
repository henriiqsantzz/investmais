import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    if (!supabase) {
      return NextResponse.json({ error: "Supabase não configurado" }, { status: 500 })
    }

    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Não autenticado" }, { status: 401 })
    }

    const body = await request.json()
    const { referralCode } = body

    const { data: referrer } = await supabase
      .from("users")
      .select("id, name")
      .eq("referral_code", referralCode.toUpperCase())
      .single()

    if (!referrer) {
      return NextResponse.json({ error: "Código de convite inválido" }, { status: 404 })
    }

    if (referrer.id === user.id) {
      return NextResponse.json({ error: "Você não pode usar seu próprio código" }, { status: 400 })
    }

    const { data: currentUser } = await supabase.from("users").select("referred_by").eq("id", user.id).single()

    if (currentUser?.referred_by) {
      return NextResponse.json({ error: "Você já usou um código de convite" }, { status: 400 })
    }

    await supabase.from("users").update({ referred_by: referrer.id }).eq("id", user.id)

    const bonusAmount = 10
    await supabase.rpc("increment_balance", {
      user_id: referrer.id,
      amount: bonusAmount,
    })

    await supabase.from("commissions").insert({
      user_id: referrer.id,
      referred_user_id: user.id,
      amount: bonusAmount,
      type: "signup_bonus",
    })

    await supabase.from("transactions").insert({
      user_id: referrer.id,
      type: "commission",
      amount: bonusAmount,
      status: "completed",
      method: "referral",
      description: `Bônus de indicação - Novo usuário`,
    })

    return NextResponse.json({
      success: true,
      message: `Código aplicado! ${referrer.name} recebeu R$ ${bonusAmount.toFixed(2)} de bônus`,
      referrerName: referrer.name,
    })
  } catch (error: any) {
    console.error("[v0] Error applying referral code:", error)
    return NextResponse.json({ error: error.message || "Erro ao aplicar código de convite" }, { status: 500 })
  }
}
