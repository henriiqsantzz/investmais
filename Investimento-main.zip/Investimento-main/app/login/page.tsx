"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { signIn } from "@/lib/auth"
import { Wallet, Eye, EyeOff } from "lucide-react"
import { useSiteSettings } from "@/lib/use-site-settings"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()
  const { settings, loading: settingsLoading } = useSiteSettings()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      await signIn(email, password)
      router.push("/")
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro ao fazer login")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A3C3C] to-[#0C5050] flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-6 md:p-8 border-0 shadow-lg">
        <div className="flex items-center gap-2 mb-8">
          {settingsLoading ? (
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#0A3C3C] to-[#0C5050] flex items-center justify-center">
              <Wallet className="w-6 h-6 text-white" />
            </div>
          ) : settings.login_logo && settings.login_logo.trim() !== "" ? (
            <img
              src={settings.login_logo || "/placeholder.svg"}
              alt={settings.site_name}
              className="h-10 w-auto object-contain max-w-[200px]"
              onError={(e) => {
                // Fallback para ícone se a imagem falhar ao carregar
                e.currentTarget.style.display = "none"
              }}
            />
          ) : (
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#0A3C3C] to-[#0C5050] flex items-center justify-center">
              <Wallet className="w-6 h-6 text-white" />
            </div>
          )}
          {!settingsLoading && (!settings.login_logo || settings.login_logo.trim() === "") && (
            <h1 className="text-2xl font-bold text-[#1E1E1E]">{settings.site_name}</h1>
          )}
        </div>

        <h2 className="text-2xl font-semibold text-[#1E1E1E] mb-2">Bem-vindo de volta</h2>
        <p className="text-sm text-[#5E6B6B] mb-6">Faça login para continuar</p>

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200">
            <p className="text-sm text-red-800">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-1.5">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full px-4 py-2.5 rounded-lg border border-[#8BA3A3]/30 focus:outline-none focus:border-[#0A3C3C] transition-colors"
              placeholder="seu@email.com"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-1.5">Senha</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full px-4 py-2.5 rounded-lg border border-[#8BA3A3]/30 focus:outline-none focus:border-[#0A3C3C] transition-colors"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#5E6B6B] hover:text-[#1E1E1E]"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <Button
            type="submit"
            disabled={loading}
            className="w-full bg-[#0A3C3C] hover:bg-[#0C5050] text-white py-2.5 rounded-lg font-medium transition-colors"
          >
            {loading ? "Entrando..." : "Entrar"}
          </Button>
        </form>

        <p className="text-center text-sm text-[#5E6B6B] mt-6">
          Não tem uma conta?{" "}
          <Link href="/register" className="text-[#0A3C3C] font-semibold hover:underline">
            Criar conta
          </Link>
        </p>
      </Card>
    </div>
  )
}
