"use client"

import { useState } from "react"
import {
  Wallet,
  RefreshCw,
  User,
  BarChart3,
  Home,
  Users,
  BookOpen,
  Info,
  Coins,
  Copy,
  Check,
  Share2,
  X,
} from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function ClubePage() {
  const [showInviteModal, setShowInviteModal] = useState(false)
  const [copied, setCopied] = useState(false)

  const userId = "25531"
  const inviteLink = `https://sonangol.live/register?ref=${userId}`
  const inviteCode = `SONG${userId}`

  const copyInviteLink = () => {
    navigator.clipboard.writeText(inviteLink)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const copyInviteCode = () => {
    navigator.clipboard.writeText(inviteCode)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const inviteLevels = [
    { level: 1, percentage: "30%", total: 0, active: 0, badge: "1" },
    { level: 2, percentage: "4%", total: 0, active: 0, badge: "2" },
    { level: 3, percentage: "1%", total: 0, active: 0, badge: "3" },
  ]

  const activations = [
    { name: "Ativação 5", reward: 10, completed: 5, required: 0 },
    { name: "Ativação 10", reward: 30, completed: 10, required: 0 },
    { name: "Ativação 30", reward: 50, completed: 30, required: 0 },
    { name: "Ativação 50", reward: 80, completed: 50, required: 0 },
    { name: "Ativação 100", reward: 130, completed: 100, required: 0 },
    { name: "Ativação 200", reward: 400, completed: 200, required: 0 },
  ]

  return (
    <div className="min-h-screen bg-[#C1D7D7]">
      {/* Header */}
      <header className="flex items-center justify-between px-4 md:px-8 py-4 backdrop-blur-sm">
        <div className="flex items-center gap-2">
          <Wallet className="w-4 h-4 md:w-5 md:h-5 text-[#0A3C3C]" />
          <div>
            <p className="text-xs text-[#5E6B6B]">Carteira de depósito</p>
            <p className="text-base md:text-lg font-semibold text-[#1E1E1E]">≈ 0 BRL</p>
          </div>
        </div>
        <div className="flex items-center gap-2 md:gap-3">
          <button className="w-9 h-9 md:w-10 md:h-10 rounded-full bg-white/80 flex items-center justify-center hover:bg-white transition-colors">
            <User className="w-4 h-4 md:w-5 md:h-5 text-[#0A3C3C]" />
          </button>
          <button className="w-9 h-9 md:w-10 md:h-10 rounded-full bg-[#1E1E1E] flex items-center justify-center hover:bg-[#0A3C3C] transition-colors">
            <RefreshCw className="w-4 h-4 md:w-5 md:h-5 text-white" />
          </button>
        </div>
      </header>

      {/* Decorative Flags */}
      <div className="relative h-12 md:h-16 overflow-hidden">
        <svg className="absolute top-0 left-0 w-full h-full" viewBox="0 0 1200 80">
          {/* Party flags */}
          <path d="M0,20 L20,0 L20,40 Z" fill="#FF6B35" />
          <path d="M30,20 L50,0 L50,40 Z" fill="#004E89" />
          <path d="M60,20 L80,0 L80,40 Z" fill="#FF6B35" />
          <path d="M90,20 L110,0 L110,40 Z" fill="#004E89" />
          <path d="M120,20 L140,0 L140,40 Z" fill="#FF6B35" />
          <path d="M150,20 L170,0 L170,40 Z" fill="#004E89" />
          <path d="M180,20 L200,0 L200,40 Z" fill="#FF6B35" />
          <line x1="0" y1="20" x2="1200" y2="20" stroke="#E0E0E0" strokeWidth="2" />
        </svg>
      </div>

      {/* Game Cards */}
      <div className="px-4 md:px-8 py-4 md:py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 max-w-4xl mx-auto">
          {/* Lucky Wheel Card */}
          <Card className="bg-gradient-to-br from-[#FFD93D] to-[#FFA500] rounded-[24px] p-6 md:p-8 shadow-lg border-0 relative overflow-hidden">
            <div className="relative z-10">
              <p className="text-xs md:text-sm text-white/90 mb-2">winning rate is 100%</p>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Lucky
                <br />
                wheel
              </h2>
              <div className="w-24 h-24 md:w-32 md:h-32 mx-auto my-6 rounded-full bg-[#0A3C3C] flex items-center justify-center relative">
                <div className="absolute inset-2 rounded-full border-4 border-[#FFD93D] border-dashed"></div>
                <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-[#FFD93D] flex items-center justify-center">
                  <div className="w-0 h-0 border-l-8 border-r-8 border-b-12 border-transparent border-b-[#0A3C3C]"></div>
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-xs md:text-sm text-[#0A3C3C] font-medium">Método de Convite</p>
                <p className="text-[10px] md:text-xs text-[#0A3C3C]/80">
                  Você pode ganhar 1 chance para participar através...
                </p>
                <div className="flex gap-2 mt-4">
                  <button
                    onClick={() => setShowInviteModal(true)}
                    className="flex-1 bg-white text-[#0A3C3C] rounded-lg px-4 py-2 text-xs md:text-sm font-semibold hover:bg-white/90 transition-colors"
                  >
                    CódigoDeConvite
                  </button>
                  <button
                    onClick={() => setShowInviteModal(true)}
                    className="flex-1 bg-[#0A3C3C] text-white rounded-lg px-4 py-2 text-xs md:text-sm font-semibold hover:bg-[#0C5050] transition-colors"
                  >
                    Convidar
                  </button>
                </div>
              </div>
            </div>
          </Card>

          {/* Big Wingo Card */}
          <Card className="bg-gradient-to-br from-[#0A3C3C] to-[#0C5050] rounded-[24px] p-6 md:p-8 shadow-lg border-0 relative overflow-hidden">
            <div className="relative z-10">
              <div className="flex justify-center items-center gap-3 mb-6">
                <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-[#4CAF50] shadow-lg"></div>
                <div className="w-20 h-20 md:w-24 md:h-24 rounded-full bg-[#FF6B35] shadow-lg"></div>
                <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-[#8BC34A] shadow-lg"></div>
              </div>
              <div className="flex justify-center gap-2 mb-6">
                <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-[#FFD93D] shadow-md"></div>
                <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-[#FFA500] shadow-md"></div>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-2">THE BIG</h2>
              <h2 className="text-3xl md:text-4xl font-bold text-white text-center">WINGO</h2>
            </div>
          </Card>
        </div>
      </div>

      {/* Commission Section */}
      <div className="px-4 md:px-8 py-4">
        <Card className="bg-white rounded-[20px] p-4 md:p-6 shadow-sm border-0 max-w-4xl mx-auto">
          <div className="mb-4">
            <p className="text-xs text-[#5E6B6B]">Comissão</p>
            <p className="text-xl md:text-2xl font-bold text-[#1E1E1E]">BRL 0</p>
          </div>

          {/* Invite Levels */}
          <div className="space-y-3 mb-6">
            {inviteLevels.map((level) => (
              <div key={level.level} className="flex items-center gap-4 p-3 bg-[#F5F5F5] rounded-xl">
                <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-gradient-to-br from-[#FF6B35] to-[#FFA500] flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold text-lg">{level.badge}</span>
                </div>
                <div className="flex-1 grid grid-cols-3 gap-2 md:gap-4">
                  <div>
                    <p className="text-[10px] md:text-xs text-[#5E6B6B]">Nível de convite {level.level}</p>
                    <p className="text-sm md:text-base font-semibold text-[#1E1E1E]">{level.percentage}</p>
                  </div>
                  <div>
                    <p className="text-[10px] md:text-xs text-[#5E6B6B]">Total de convites</p>
                    <p className="text-sm md:text-base font-semibold text-[#1E1E1E]">{level.total}</p>
                  </div>
                  <div>
                    <p className="text-[10px] md:text-xs text-[#5E6B6B]">Ativo</p>
                    <p className="text-sm md:text-base font-semibold text-[#1E1E1E]">{level.active}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Activations */}
          <div className="space-y-3">
            {activations.map((activation, index) => (
              <div key={index} className="flex items-center gap-4 p-3 border-b border-[#E0E0E0] last:border-0">
                <div className="w-8 h-8 rounded-full bg-[#E0E0E0] flex items-center justify-center flex-shrink-0">
                  <span className="text-[#5E6B6B] font-semibold text-xs">{index + 1}</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm md:text-base font-semibold text-[#1E1E1E] mb-1">{activation.name}</p>
                  <div className="grid grid-cols-3 gap-2 md:gap-4">
                    <div>
                      <p className="text-[10px] md:text-xs text-[#5E6B6B]">Recompensa</p>
                      <div className="flex items-center gap-1">
                        <Coins className="w-3 h-3" />
                        <p className="text-xs md:text-sm font-semibold text-[#1E1E1E]">{activation.reward}</p>
                      </div>
                    </div>
                    <div>
                      <p className="text-[10px] md:text-xs text-[#5E6B6B]">Concluído</p>
                      <p className="text-xs md:text-sm font-semibold text-[#1E1E1E]">{activation.completed}</p>
                    </div>
                    <div>
                      <p className="text-[10px] md:text-xs text-[#5E6B6B]">Requisitos</p>
                      <p className="text-xs md:text-sm font-semibold text-[#1E1E1E]">{activation.required}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Clube dos Milionários */}
      <div className="px-4 md:px-8 py-4 pb-24 md:pb-28">
        <Card className="bg-white rounded-[20px] p-4 md:p-6 shadow-sm border-0 max-w-4xl mx-auto">
          <h3 className="text-lg md:text-xl font-bold text-[#1E1E1E] mb-4">Clube dos Milionários</h3>
          <div className="space-y-3 text-xs md:text-sm text-[#5E6B6B] leading-relaxed">
            <p>1. Você receberá recompensas com base no valor do investimento dos seus subordinados.</p>
            <ul className="list-none space-y-1 ml-4">
              <li>Nível de Comissão (Nível 1): 30%</li>
              <li>Nível de Comissão (Nível 2): 4%</li>
              <li>Nível de Comissão (Nível 3): 1%</li>
            </ul>
            <p>
              Supondo que você convide 100 usuários para participar e investir 10.000 rúpias na plataforma, sua renda
              seria: 1.000.000 * 35% = 35.000 rúpias
            </p>
            <p>Todo bom promotor pode ganhar pelo menos 100.000.000 BRL por mês</p>
            <p>
              Entre em contato com o atendimento ao cliente para se juntar à aliança de promotores e obter as últimas
              maneiras de ganhar dinheiro
            </p>
          </div>
        </Card>
      </div>

      {showInviteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-[#1E1E1E]">Convide Amigos</h3>
              <button onClick={() => setShowInviteModal(false)}>
                <X className="w-5 h-5 text-[#5E6B6B]" />
              </button>
            </div>

            {/* Invite Code Section */}
            <div className="mb-6">
              <label className="text-sm font-medium text-[#5E6B6B] mb-2 block">Código de Convite</label>
              <div className="flex gap-2">
                <div className="flex-1 bg-[#F5F5F5] rounded-xl px-4 py-3 flex items-center justify-between">
                  <span className="text-base font-semibold text-[#1E1E1E]">{inviteCode}</span>
                  <button onClick={copyInviteCode} className="text-[#0A3C3C] hover:text-[#0C5050] transition-colors">
                    {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                  </button>
                </div>
              </div>
              <p className="text-xs text-[#5E6B6B] mt-2">
                Compartilhe este código com seus amigos para que eles possam se registrar
              </p>
            </div>

            {/* Invite Link Section */}
            <div className="mb-6">
              <label className="text-sm font-medium text-[#5E6B6B] mb-2 block">Link de Convite</label>
              <div className="flex gap-2">
                <div className="flex-1 bg-[#F5F5F5] rounded-xl px-4 py-3 overflow-hidden">
                  <p className="text-sm text-[#1E1E1E] truncate">{inviteLink}</p>
                </div>
                <button
                  onClick={copyInviteLink}
                  className="bg-[#0A3C3C] hover:bg-[#0C5050] text-white rounded-xl px-4 py-3 transition-colors flex items-center gap-2"
                >
                  {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                  <span className="text-sm font-medium">Copiar</span>
                </button>
              </div>
              <p className="text-xs text-[#5E6B6B] mt-2">Compartilhe este link diretamente com seus amigos</p>
            </div>

            {/* Benefits Section */}
            <div className="bg-gradient-to-br from-[#FFD93D]/20 to-[#FFA500]/20 rounded-xl p-4 mb-6">
              <h4 className="text-sm font-semibold text-[#1E1E1E] mb-2 flex items-center gap-2">
                <Coins className="w-4 h-4 text-[#FFA500]" />
                Benefícios do Convite
              </h4>
              <ul className="space-y-1 text-xs text-[#5E6B6B]">
                <li>• Ganhe 30% de comissão no Nível 1</li>
                <li>• Ganhe 4% de comissão no Nível 2</li>
                <li>• Ganhe 1% de comissão no Nível 3</li>
                <li>• Recompensas por ativação de convites</li>
              </ul>
            </div>

            {/* Share Button */}
            <Button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({
                    title: "Junte-se a Sonangol",
                    text: `Use meu código de convite ${inviteCode} para se registrar!`,
                    url: inviteLink,
                  })
                } else {
                  copyInviteLink()
                }
              }}
              className="w-full bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] hover:from-[#0C5050] hover:to-[#0A3C3C] text-white rounded-xl py-3 text-sm font-semibold flex items-center justify-center gap-2"
            >
              <Share2 className="w-4 h-4" />
              Compartilhar Convite
            </Button>

            {copied && (
              <p className="text-center text-sm text-green-600 mt-3 font-medium">
                Copiado para a área de transferência!
              </p>
            )}
          </Card>
        </div>
      )}

      {/* Fixed Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] px-4 md:px-8 py-3 md:py-4 rounded-t-[30px] md:rounded-none">
        <div className="max-w-7xl mx-auto flex items-center justify-around">
          <Link
            href="/casa"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <Home className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-[10px] md:text-xs font-medium">casa</span>
          </Link>
          <Link
            href="/"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors">
              <BarChart3 className="w-5 h-5 md:w-6 md:h-6 text-white" />
            </div>
            <span className="text-[10px] md:text-xs font-medium">Investir</span>
          </Link>
          <Link
            href="/clube"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white hover:text-white transition-colors"
          >
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-white flex items-center justify-center hover:bg-white/90 transition-colors">
              <Users className="w-5 h-5 md:w-6 md:h-6 text-[#0A3C3C]" />
            </div>
            <span className="text-[10px] md:text-xs font-medium">Clube</span>
          </Link>
          <Link
            href="/blog"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <BookOpen className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-[10px] md:text-xs font-medium">Blog</span>
          </Link>
          <Link
            href="/nossa-historia"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <Info className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-[10px] md:text-xs font-medium">NossaHistória</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}
