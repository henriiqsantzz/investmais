"use client"

import { ArrowLeft, DollarSign, Calendar, TrendingUp } from "lucide-react"
import { Card } from "@/components/ui/card"
import Link from "next/link"
import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"

interface Transaction {
  id: string
  amount: number
  created_at: string
  type: string
  description: string | null
  status: string
}

export default function PagamentosPage() {
  const [payments, setPayments] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function loadPayments() {
      try {
        const supabase = createClient()

        // Get current user
        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser()

        if (userError || !user) {
          setError("Usuário não autenticado")
          setLoading(false)
          return
        }

        // Fetch transactions that are returns/payments (not deposits or withdrawals)
        const { data, error: fetchError } = await supabase
          .from("transactions")
          .select("*")
          .eq("user_id", user.id)
          .in("type", ["daily_return", "investment_return", "return", "payment"])
          .order("created_at", { ascending: false })

        if (fetchError) {
          console.error("Erro ao buscar pagamentos:", fetchError)
          setError("Erro ao carregar pagamentos")
        } else {
          setPayments(data || [])
        }
      } catch (err) {
        console.error("Erro:", err)
        setError("Erro ao carregar dados")
      } finally {
        setLoading(false)
      }
    }

    loadPayments()
  }, [])

  const getPaymentType = (type: string) => {
    if (type === "daily_return" || type === "investment_return") return "Rendimento Diário"
    if (type === "return") return "Retorno de Investimento"
    if (type === "payment") return "Pagamento"
    return type
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString("pt-BR", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="min-h-screen bg-[#C1D7D7]">
      {/* Header */}
      <header className="bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] px-4 py-4">
        <div className="flex items-center gap-3">
          <Link href="/casa">
            <button className="text-white">
              <ArrowLeft className="w-6 h-6" />
            </button>
          </Link>
          <h1 className="text-xl font-semibold text-white">Registros de Pagamento</h1>
        </div>
      </header>

      {/* Content */}
      <div className="px-4 py-6 space-y-4">
        {loading ? (
          <Card className="bg-white rounded-xl p-8 border-0 shadow-sm text-center">
            <p className="text-sm text-[#5E6B6B]">Carregando...</p>
          </Card>
        ) : error ? (
          <Card className="bg-white rounded-xl p-8 border-0 shadow-sm text-center">
            <p className="text-sm text-red-600">{error}</p>
          </Card>
        ) : payments.length > 0 ? (
          payments.map((payment) => (
            <Card key={payment.id} className="bg-white rounded-xl p-4 border-0 shadow-sm">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                    <DollarSign className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-[#1E1E1E]">{getPaymentType(payment.type)}</p>
                    {payment.description && (
                      <div className="flex items-center gap-1 text-xs text-[#5E6B6B] mt-0.5">
                        <TrendingUp className="w-3 h-3" />
                        <span>{payment.description}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-1 text-xs text-[#5E6B6B] mt-0.5">
                      <Calendar className="w-3 h-3" />
                      <span>{formatDate(payment.created_at)}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-green-600">+{payment.amount.toFixed(2)} BRL</p>
                </div>
              </div>
            </Card>
          ))
        ) : (
          <Card className="bg-white rounded-xl p-8 border-0 shadow-sm text-center">
            <DollarSign className="w-12 h-12 text-[#8BA3A3] mx-auto mb-3" />
            <p className="text-sm text-[#5E6B6B]">Nenhum registro encontrado</p>
          </Card>
        )}
      </div>
    </div>
  )
}
