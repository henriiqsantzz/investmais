"use client"

import { useState, useEffect } from "react"
import { useUser } from "@/lib/hooks/use-user"
import { createClient } from "@/lib/supabase/client"
import {
  Wallet,
  Bell,
  User,
  CreditCard,
  FileText,
  RotateCcw,
  Receipt,
  Percent,
  DollarSign,
  MessageCircle,
  Send,
  ArrowRight,
  X,
  Home,
  BarChart3,
  Users,
  BookOpen,
  Info,
  LogOut,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { DepositModal } from "@/components/deposit-modal"
import { WithdrawModal } from "@/components/withdraw-modal-updated"
import { WithdrawalPasswordModal } from "@/components/withdrawal-password-modal"
import { WithdrawalVerifyPasswordModal } from "@/components/withdrawal-verify-password-modal"
import { PixDisplayModal } from "@/components/pix-display-modal"
import { DepositSuccessModal } from "@/components/deposit-success-modal"

export default function CasaPage() {
  const router = useRouter()
  const { user, userDetails, loading, refetch } = useUser()
  const [showRechargeModal, setShowRechargeModal] = useState(false)
  const [showWithdrawModal, setShowWithdrawModal] = useState(false)
  const [showOrdersModal, setShowOrdersModal] = useState(false)
  const [balance, setBalance] = useState(0)
  const [withdrawalBalance, setWithdrawalBalance] = useState(0)
  const [showWithdrawalPasswordModal, setShowWithdrawalPasswordModal] = useState(false)
  const [hasWithdrawalPassword, setHasWithdrawalPassword] = useState(false)
  const [showVerifyPasswordModal, setShowVerifyPasswordModal] = useState(false)
  const [pendingWithdrawal, setPendingWithdrawal] = useState<{
    amount: number
    pixKey: string
    pixKeyType: string
  } | null>(null)
  const [showPixModal, setShowPixModal] = useState(false)
  const [pixData, setPixData] = useState<{
    qrCode: string
    pixCode: string
    pixKey: string
    amount: number
    transactionId: string
    expiresAt: string
  } | null>(null)
  const [showSuccessModal, setShowSuccessModal] = useState(false)
  const [successData, setSuccessData] = useState<{ amount: number; newBalance: number } | null>(null)

  useEffect(() => {
    if (userDetails) {
      setBalance(userDetails.balance || 0)
      setWithdrawalBalance(userDetails.withdrawal_balance || 0)
      checkWithdrawalPassword()
    }
  }, [userDetails])

  const checkWithdrawalPassword = async () => {
    const supabase = createClient()
    if (!user) return

    const { data } = await supabase.from("profiles").select("withdrawal_password").eq("id", user.id).single()

    setHasWithdrawalPassword(!!data?.withdrawal_password)
  }

  const handleLogout = async () => {
    const supabase = createClient()
    if (!supabase) {
      router.push("/auth/login")
      return
    }

    await supabase.auth.signOut()
    router.push("/auth/login")
  }

  const handleDepositConfirm = async (amount: number) => {
    try {
      const supabase = createClient()

      if (!user) {
        alert("Usuário não autenticado")
        return
      }

      const { error: depositError } = await supabase.from("deposits").insert({
        user_id: user.id,
        amount,
        payment_method: "PIX",
        status: "pending",
      })

      if (depositError) throw depositError

      await supabase.from("transactions").insert({
        user_id: user.id,
        type: "deposit",
        amount,
        status: "pending",
        method: "pix",
        description: `Depósito via PIX - R$ ${amount.toFixed(2)}`,
      })
    } catch (error) {
      console.error("[v0] Erro ao processar depósito:", error)
      alert("Erro ao processar depósito")
    }
  }

  const handlePixGenerated = (data: {
    qrCode: string
    pixCode: string
    pixKey: string
    amount: number
    transactionId: string
    expiresAt: string
  }) => {
    setPixData(data)
    setShowPixModal(true)
  }

  const handleWithdrawConfirm = async (amount: number, pixKey: string, pixKeyType: string) => {
    setPendingWithdrawal({ amount, pixKey, pixKeyType })
    setShowWithdrawModal(false)
    setShowVerifyPasswordModal(true)
  }

  const processWithdrawal = async () => {
    if (!pendingWithdrawal) return

    const { amount, pixKey, pixKeyType } = pendingWithdrawal

    try {
      const supabase = createClient()

      if (!user) {
        alert("Usuário não autenticado")
        return
      }

      const fee = amount * 0.025
      const netAmount = amount - fee

      if (amount > balance) {
        alert("Saldo insuficiente")
        return
      }

      const { error: withdrawalError } = await supabase.from("withdrawals").insert({
        user_id: user.id,
        amount,
        amount_net: netAmount,
        amount_fee: fee,
        pix_key: pixKey,
        pix_key_type: pixKeyType,
        status: "pending",
      })

      if (withdrawalError) throw withdrawalError

      const newBalance = balance - amount
      await supabase.from("profiles").update({ balance: newBalance }).eq("id", user.id)

      await supabase.from("transactions").insert({
        user_id: user.id,
        type: "withdrawal",
        amount,
        status: "pending",
        method: "pix",
        description: `Saque via PIX - R$ ${amount.toFixed(2)}`,
      })

      setBalance(newBalance)
      await refetch()
      alert("Saque solicitado com sucesso! Aguarde a aprovação.")
      setPendingWithdrawal(null)
    } catch (error) {
      console.error("[v0] Erro ao processar saque:", error)
      alert("Erro ao processar saque")
    }
  }

  const handleWithdrawClick = () => {
    if (!hasWithdrawalPassword) {
      setShowWithdrawalPasswordModal(true)
    } else {
      setShowWithdrawModal(true)
    }
  }

  const handlePaymentCompleted = async (amount: number, newBalance: number) => {
    console.log("[v0] Pagamento concluído - Atualizando interface")

    // Fechar modal do PIX
    setShowPixModal(false)
    setPixData(null)

    // Atualizar saldo local
    setBalance(newBalance)

    // Recarregar dados do usuário
    await refetch()

    // Mostrar modal de sucesso
    setSuccessData({ amount, newBalance })
    setShowSuccessModal(true)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#C1D7D7] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 rounded-full border-4 border-[#8BA3A3]/20 border-t-[#0A3C3C] animate-spin mx-auto mb-4"></div>
          <p className="text-[#5E6B6B]">Carregando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#C1D7D7] pb-24">
      {/* Header */}
      <header className="px-4 py-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-400 to-pink-500 flex items-center justify-center">
              <span className="text-white font-semibold text-lg">
                {userDetails?.name?.charAt(0).toUpperCase() || "U"}
              </span>
            </div>
            <div>
              <p className="text-sm font-semibold text-[#1E1E1E]">{userDetails?.name || "Usuário"}</p>
              <p className="text-xs text-[#5E6B6B]">ID: {user?.id?.slice(0, 8) || "---"}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/perfil">
              <button className="w-10 h-10 rounded-full bg-white flex items-center justify-center hover:bg-white/90 transition-colors">
                <User className="w-5 h-5 text-[#0A3C3C]" />
              </button>
            </Link>
            <button className="w-10 h-10 rounded-full bg-white flex items-center justify-center hover:bg-white/90 transition-colors">
              <Bell className="w-5 h-5 text-[#0A3C3C]" />
            </button>
            <button
              onClick={handleLogout}
              className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center hover:bg-red-200 transition-colors"
            >
              <LogOut className="w-5 h-5 text-red-600" />
            </button>
          </div>
        </div>

        {/* Balance Cards */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <p className="text-xs text-[#5E6B6B] mb-1">Carteira de depósito (BRL)</p>
            <div className="flex items-center gap-1">
              <Wallet className="w-4 h-4 text-[#1E1E1E]" />
              <span className="text-lg font-bold text-[#1E1E1E]">{balance.toFixed(2)}</span>
            </div>
          </div>
          <div>
            <p className="text-xs text-[#5E6B6B] mb-1">Sacar Carteira (BRL)</p>
            <div className="flex items-center gap-1">
              <Wallet className="w-4 h-4 text-[#1E1E1E]" />
              <span className="text-lg font-bold text-[#1E1E1E]">{withdrawalBalance.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Action Buttons */}
      <div className="px-4 mb-6">
        <Card className="bg-white rounded-2xl p-6 shadow-sm border-0">
          <div className="grid grid-cols-3 gap-4">
            <button
              onClick={() => setShowRechargeModal(true)}
              className="flex flex-col items-center gap-2 hover:opacity-80 transition-opacity"
            >
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center">
                <CreditCard className="w-7 h-7 text-white" />
              </div>
              <span className="text-xs font-medium text-[#1E1E1E]">Recarregar</span>
            </button>
            <button
              onClick={handleWithdrawClick}
              className="flex flex-col items-center gap-2 hover:opacity-80 transition-opacity"
            >
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-orange-400 to-red-500 flex items-center justify-center">
                <DollarSign className="w-7 h-7 text-white" />
              </div>
              <span className="text-xs font-medium text-[#1E1E1E]">Retirar</span>
            </button>
            <button
              onClick={() => setShowOrdersModal(true)}
              className="flex flex-col items-center gap-2 hover:opacity-80 transition-opacity"
            >
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center">
                <FileText className="w-7 h-7 text-white" />
              </div>
              <span className="text-xs font-medium text-[#1E1E1E]">Pedidos</span>
            </button>
          </div>
        </Card>
      </div>

      {/* Registry Section */}
      <div className="px-4 mb-6">
        <Card className="bg-white rounded-2xl p-5 shadow-sm border-0">
          <h3 className="text-base font-semibold text-[#1E1E1E] mb-1">Registro de fundo</h3>
          <p className="text-xs text-[#5E6B6B] mb-4">Registre as alterações em seus fundos</p>
          <div className="grid grid-cols-5 gap-3">
            <Link
              href="/casa/historico/detalhes-fatura"
              className="flex flex-col items-center gap-2 hover:opacity-80 transition-opacity"
            >
              <FileText className="w-6 h-6 text-[#0A3C3C]" />
              <span className="text-[10px] text-center text-[#5E6B6B] leading-tight">Detalhes da fatura</span>
            </Link>
            <Link
              href="/casa/historico/retiradas"
              className="flex flex-col items-center gap-2 hover:opacity-80 transition-opacity"
            >
              <RotateCcw className="w-6 h-6 text-[#0A3C3C]" />
              <span className="text-[10px] text-center text-[#5E6B6B] leading-tight">Registros de Retirada</span>
            </Link>
            <Link
              href="/casa/historico/depositos"
              className="flex flex-col items-center gap-2 hover:opacity-80 transition-opacity"
            >
              <Receipt className="w-6 h-6 text-[#0A3C3C]" />
              <span className="text-[10px] text-center text-[#5E6B6B] leading-tight">Registros de depósito</span>
            </Link>
            <Link
              href="/casa/historico/comissoes"
              className="flex flex-col items-center gap-2 hover:opacity-80 transition-opacity"
            >
              <Percent className="w-6 h-6 text-[#0A3C3C]" />
              <span className="text-[10px] text-center text-[#5E6B6B] leading-tight">Registros de Comissão</span>
            </Link>
            <Link
              href="/casa/historico/pagamentos"
              className="flex flex-col items-center gap-2 hover:opacity-80 transition-opacity"
            >
              <DollarSign className="w-6 h-6 text-[#0A3C3C]" />
              <span className="text-[10px] text-center text-[#5E6B6B] leading-tight">Registros de Pagamento</span>
            </Link>
          </div>
        </Card>
      </div>

      {/* Customer Service */}
      <div className="px-4 mb-4">
        <Card className="bg-white rounded-2xl p-4 shadow-sm border-0 flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center flex-shrink-0">
            <MessageCircle className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-[#1E1E1E] mb-0.5">Atendimento ao Cliente Online</h4>
            <p className="text-xs text-[#5E6B6B]">
              Horário de atendimento ao cliente online a partir de 09:00:00 para 20:00:00.
            </p>
          </div>
          <ArrowRight className="w-5 h-5 text-[#5E6B6B] flex-shrink-0" />
        </Card>
      </div>

      {/* Telegram Channel */}
      <div className="px-4 mb-6">
        <Card className="bg-white rounded-2xl p-4 shadow-sm border-0 flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-[#0088cc] flex items-center justify-center flex-shrink-0">
            <Send className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-[#1E1E1E] mb-0.5">Canal do Telegram</h4>
            <p className="text-xs text-[#5E6B6B]">
              Últimas notificações e anúncios, novas informações sobre benefícios e, às vezes, presentes misteriosos!
            </p>
          </div>
          <ArrowRight className="w-5 h-5 text-[#5E6B6B] flex-shrink-0" />
        </Card>
      </div>

      {/* Invite Friends */}
      <div className="px-4">
        <Card className="bg-white rounded-2xl p-6 shadow-sm border-0">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center flex-shrink-0">
              <span className="text-2xl">!</span>
            </div>
            <div>
              <h3 className="text-xl font-bold text-[#1E1E1E] mb-1">Invite friends</h3>
              <p className="text-sm text-[#5E6B6B]">and get continuous rewards</p>
            </div>
          </div>
          <img
            src="/images/design-mode/image.png"
            alt="Invite friends illustration"
            className="w-full h-32 object-contain mb-4"
          />
          <Button className="w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white rounded-full py-3 text-sm font-semibold">
            Go immediately
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </Card>
      </div>

      {/* Modals */}
      <DepositModal
        isOpen={showRechargeModal}
        onClose={() => setShowRechargeModal(false)}
        onConfirm={handleDepositConfirm}
        onPixGenerated={handlePixGenerated}
      />
      {pixData && (
        <PixDisplayModal
          isOpen={showPixModal}
          onClose={() => {
            setShowPixModal(false)
            setPixData(null)
          }}
          qrCode={pixData.qrCode}
          pixCode={pixData.pixCode}
          pixKey={pixData.pixKey}
          amount={pixData.amount}
          transactionId={pixData.transactionId}
          expiresAt={pixData.expiresAt}
          onPaymentCompleted={handlePaymentCompleted}
        />
      )}
      {successData && (
        <DepositSuccessModal
          isOpen={showSuccessModal}
          onClose={() => {
            setShowSuccessModal(false)
            setSuccessData(null)
          }}
          amount={successData.amount}
          newBalance={successData.newBalance}
        />
      )}
      <WithdrawModal
        isOpen={showWithdrawModal}
        onClose={() => setShowWithdrawModal(false)}
        onConfirm={handleWithdrawConfirm}
        userBalance={balance}
      />
      <WithdrawalPasswordModal
        isOpen={showWithdrawalPasswordModal}
        onClose={() => setShowWithdrawalPasswordModal(false)}
        onSuccess={() => {
          setHasWithdrawalPassword(true)
          setShowWithdrawModal(true)
        }}
      />
      <WithdrawalVerifyPasswordModal
        isOpen={showVerifyPasswordModal}
        onClose={() => {
          setShowVerifyPasswordModal(false)
          setPendingWithdrawal(null)
        }}
        onVerified={processWithdrawal}
      />

      {showOrdersModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-[#1E1E1E]">Pedidos</h3>
              <button onClick={() => setShowOrdersModal(false)}>
                <X className="w-5 h-5 text-[#5E6B6B]" />
              </button>
            </div>
            <p className="text-sm text-[#5E6B6B] mb-4">Nenhum pedido encontrado.</p>
            <Button
              onClick={() => setShowOrdersModal(false)}
              className="w-full bg-[#0A3C3C] hover:bg-[#0C5050] text-white rounded-xl"
            >
              Fechar
            </Button>
          </Card>
        </div>
      )}

      {/* Fixed Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] px-4 py-3 rounded-t-[30px]">
        <div className="max-w-7xl mx-auto flex items-center justify-around">
          <Link href="/casa" className="flex flex-col items-center gap-1 text-white transition-colors">
            <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
              <Home className="w-5 h-5 text-[#0A3C3C]" />
            </div>
            <span className="text-[10px] font-medium">casa</span>
          </Link>
          <Link href="/" className="flex flex-col items-center gap-1 text-white/70 hover:text-white transition-colors">
            <BarChart3 className="w-5 h-5" />
            <span className="text-[10px] font-medium">Investir</span>
          </Link>
          <Link
            href="/clube"
            className="flex flex-col items-center gap-1 text-white/70 hover:text-white transition-colors"
          >
            <Users className="w-5 h-5" />
            <span className="text-[10px] font-medium">Clube</span>
          </Link>
          <Link
            href="/blog"
            className="flex flex-col items-center gap-1 text-white/70 hover:text-white transition-colors"
          >
            <BookOpen className="w-5 h-5" />
            <span className="text-[10px] font-medium">Blog</span>
          </Link>
          <Link
            href="/nossa-historia"
            className="flex flex-col items-center gap-1 text-white/70 hover:text-white transition-colors"
          >
            <Info className="w-5 h-5" />
            <span className="text-[10px] font-medium">NossaHistória</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}
