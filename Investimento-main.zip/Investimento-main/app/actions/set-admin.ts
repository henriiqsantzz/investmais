"use server"

import { createClient } from "@supabase/supabase-js"
import { cookies } from "next/headers"
import { createServerClient } from "@supabase/ssr"

export async function setCurrentUserAsAdmin() {
  try {
    const cookieStore = await cookies()

    // Create regular client to get current user
    const supabaseAuth = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            cookiesToSet.forEach(({ name, value, options }) => {
              cookieStore.set(name, value, options)
            })
          },
        },
      },
    )

    // Get current authenticated user
    const {
      data: { user },
      error: userError,
    } = await supabaseAuth.auth.getUser()

    if (userError || !user) {
      console.error("[v0] Error getting user:", userError)
      return { success: false, error: "Usuário não está logado" }
    }

    console.log("[v0] Setting admin for user:", user.id, user.email)

    const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    })

    // Update profile to admin using service role (bypasses RLS)
    const { error: updateError } = await supabaseAdmin.from("profiles").update({ role: "admin" }).eq("id", user.id)

    if (updateError) {
      console.error("[v0] Error setting admin:", updateError)
      return { success: false, error: updateError.message }
    }

    // Verify it worked
    const { data: profile } = await supabaseAdmin.from("profiles").select("role").eq("id", user.id).single()

    console.log("[v0] Admin set successfully. New role:", profile?.role)

    return {
      success: true,
      message: `Usuário ${user.email} agora é admin!`,
      role: profile?.role,
    }
  } catch (error: any) {
    console.error("[v0] Exception setting admin:", error)
    return { success: false, error: error.message }
  }
}
