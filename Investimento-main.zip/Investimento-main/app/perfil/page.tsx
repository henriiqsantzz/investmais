"use client"

import { useState, useEffect } from "react"
import { useUser } from "@/lib/hooks/use-user"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Mail, Calendar, Shield } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function PerfilPage() {
  const router = useRouter()
  const { user, userDetails, loading, refetch } = useUser()
  const [name, setName] = useState("")
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState("")

  useEffect(() => {
    if (userDetails) {
      setName(userDetails.name || "")
    }
  }, [userDetails])

  const handleSave = async () => {
    if (!user) return

    if (!name.trim()) {
      setMessage("Nome não pode estar vazio")
      return
    }

    setSaving(true)
    setMessage("")

    try {
      const supabase = createClient()

      const { error } = await supabase.from("profiles").update({ name: name.trim() }).eq("id", user.id)

      if (error) throw error

      await refetch()
      setMessage("Perfil atualizado com sucesso!")
    } catch (error) {
      console.error("[v0] Erro ao atualizar perfil:", error)
      setMessage("Erro ao atualizar perfil")
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#C1D7D7] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 rounded-full border-4 border-[#8BA3A3]/20 border-t-[#0A3C3C] animate-spin mx-auto mb-4"></div>
          <p className="text-[#5E6B6B]">Carregando...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    router.push("/auth/login")
    return null
  }

  return (
    <div className="min-h-screen bg-[#C1D7D7]">
      <header className="bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] px-4 py-4">
        <div className="flex items-center gap-4">
          <Link href="/casa">
            <Button variant="ghost" className="text-white hover:bg-white/10">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-white">Meu Perfil</h1>
        </div>
      </header>

      <div className="px-4 py-6 space-y-4">
        <Card className="bg-white rounded-2xl p-6 border-0 shadow-sm">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-orange-400 to-pink-500 flex items-center justify-center">
              <span className="text-white font-bold text-3xl">{userDetails?.name?.charAt(0).toUpperCase() || "U"}</span>
            </div>
            <div>
              <h2 className="text-xl font-bold text-[#1E1E1E]">{userDetails?.name || "Usuário"}</h2>
              <p className="text-sm text-[#5E6B6B]">{user.email}</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-[#1E1E1E] mb-1.5">Nome Completo</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg border border-[#8BA3A3]/30 focus:outline-none focus:border-[#0A3C3C] transition-colors"
                placeholder="Seu nome completo"
              />
            </div>

            {message && (
              <div
                className={`p-3 rounded-lg ${
                  message.includes("sucesso")
                    ? "bg-green-50 border border-green-200 text-green-800"
                    : "bg-red-50 border border-red-200 text-red-800"
                }`}
              >
                <p className="text-sm">{message}</p>
              </div>
            )}

            <Button
              onClick={handleSave}
              disabled={saving}
              className="w-full bg-[#0A3C3C] hover:bg-[#0C5050] text-white py-2.5 rounded-lg font-medium transition-colors"
            >
              {saving ? "Salvando..." : "Salvar Alterações"}
            </Button>
          </div>
        </Card>

        <Card className="bg-white rounded-2xl p-6 border-0 shadow-sm">
          <h3 className="text-lg font-semibold text-[#1E1E1E] mb-4">Informações da Conta</h3>
          <div className="space-y-3">
            <div className="flex items-center gap-3 py-2">
              <Mail className="w-5 h-5 text-[#5E6B6B]" />
              <div>
                <p className="text-xs text-[#5E6B6B]">Email</p>
                <p className="text-sm font-medium text-[#1E1E1E]">{user.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 py-2">
              <Calendar className="w-5 h-5 text-[#5E6B6B]" />
              <div>
                <p className="text-xs text-[#5E6B6B]">Membro desde</p>
                <p className="text-sm font-medium text-[#1E1E1E]">
                  {userDetails?.created_at
                    ? new Date(userDetails.created_at).toLocaleDateString("pt-BR")
                    : "Data não disponível"}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 py-2">
              <Shield className="w-5 h-5 text-[#5E6B6B]" />
              <div>
                <p className="text-xs text-[#5E6B6B]">Tipo de Conta</p>
                <p className="text-sm font-medium text-[#1E1E1E]">
                  {userDetails?.role === "admin" ? "Administrador" : "Usuário"}
                </p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
