import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { AlertCircle, Wallet } from "lucide-react"

export default async function ErrorPage({
  searchParams,
}: {
  searchParams: Promise<{ error: string }>
}) {
  const params = await searchParams

  return (
    <div className="min-h-screen bg-[#C1D7D7] flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="flex flex-col gap-6">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Wallet className="w-8 h-8 text-[#0A3C3C]" />
            <h1 className="text-2xl font-bold text-[#0A3C3C]">Investimento Alto</h1>
          </div>
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <div className="flex justify-center mb-4">
                <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center">
                  <AlertCircle className="w-10 h-10 text-red-600" />
                </div>
              </div>
              <CardTitle className="text-2xl text-center text-[#1E1E1E]">Ops! Algo deu errado</CardTitle>
            </CardHeader>
            <CardContent>
              {params?.error ? (
                <p className="text-sm text-[#5E6B6B] text-center mb-6">Erro: {params.error}</p>
              ) : (
                <p className="text-sm text-[#5E6B6B] text-center mb-6">Ocorreu um erro não especificado.</p>
              )}
              <Button asChild className="w-full bg-[#0A3C3C] hover:bg-[#0C5050] text-white">
                <Link href="/auth/login">Voltar para o Login</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
