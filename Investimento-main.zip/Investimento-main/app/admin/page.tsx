import { createServerClient } from "@/lib/supabase/server"
import { createAdminClient, isUserAdmin } from "@/lib/supabase/admin"
import { redirect } from "next/navigation"
import { AdminDashboard } from "@/components/admin/admin-dashboard"

interface User {
  id: string
  name: string
  email: string
  balance: number
  withdrawal_balance: number
  role: string
  created_at: string
}

interface Investment {
  id: string
  user_id: string
  product_name: string
  investment_amount: number
  status: string
  created_at: string
  profiles: { name: string; email: string }
}

interface Deposit {
  id: string
  user_id: string
  amount: number
  status: string
  created_at: string
  payment_method: string
  profiles: { name: string; email: string }
}

interface Withdrawal {
  id: string
  user_id: string
  amount: number
  status: string
  created_at: string
  pix_key: string
  pix_key_type: string
  profiles: { name: string; email: string }
}

export default async function AdminPage() {
  const supabase = await createServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const isAdmin = await isUserAdmin(user.id)

  if (!isAdmin) {
    redirect("/casa")
  }

  const adminClient = createAdminClient()

  const { data: usersData } = await adminClient.from("profiles").select("*").order("created_at", { ascending: false })

  const { data: investmentsData } = await adminClient
    .from("investments")
    .select("*, profiles(name, email)")
    .order("created_at", { ascending: false })
    .limit(50)

  const { data: depositsData } = await adminClient
    .from("deposits")
    .select("*, profiles(name, email)")
    .order("created_at", { ascending: false })

  const { data: withdrawalsData } = await adminClient
    .from("withdrawals")
    .select("*, profiles(name, email)")
    .order("created_at", { ascending: false })

  console.log("[v0 Admin] Total de investimentos encontrados:", investmentsData?.length || 0)
  console.log("[v0 Admin] Total de depósitos encontrados:", depositsData?.length || 0)
  console.log("[v0 Admin] Total de saques encontrados:", withdrawalsData?.length || 0)
  console.log("[v0 Admin] Total de usuários encontrados:", usersData?.length || 0)

  return (
    <AdminDashboard
      initialUsers={usersData || []}
      initialInvestments={investmentsData || []}
      initialDeposits={depositsData || []}
      initialWithdrawals={withdrawalsData || []}
    />
  )
}
